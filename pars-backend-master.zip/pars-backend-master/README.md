# pars-backend

Pars system Backend API

### Key Developers:

- Amir Tajik 
- Atousa Khanjani