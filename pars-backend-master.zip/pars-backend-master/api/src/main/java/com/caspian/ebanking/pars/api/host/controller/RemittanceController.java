package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.ach.dto.AchTransferReportRequestDto;
import com.caspian.ebanking.pars.api.service.business.ach.dto.AchTransferReportResponseDto;
import com.caspian.ebanking.pars.api.service.business.remitance.dto.*;
import com.caspian.ebanking.pars.api.service.business.remitance.service.RemittanceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۰۹:۵۶ قبل‌ازظهر
 */
@RestController
@RequestMapping("/remittance")
@Api(tags = "remittance")
@RequiredArgsConstructor
public class RemittanceController {
    private final RemittanceService remittanceService;

    @ApiOperation(httpMethod = "GET", value = "گزارش بروات ارزی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping
    public CurrencyRemittanceReportResponseDto currencyRemittanceReport(CurrencyRemittanceReportRequestDto requestDto) {
        return this.remittanceService.currencyRemittanceReport(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش اعتبارات اسنادی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/documentaryCredit")
    public DocumentaryCreditsReportResponseDto documentaryCreditsReport(DocumentaryCreditsReportRequestDto requestDto) {
        return this.remittanceService.documentaryCreditsReport(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش ضمانت نامه های ارزی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/guaranty")
    public GuarantyReportResponseDto guarantyReport(GuarantyReportRequestDto requestDto) {
        return this.remittanceService.guarantyReport(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش حواله های صادره ارزی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/Issued")
    public IssuedRemittanceReportResponseDto issuedRemittanceReport(IssuedRemittanceReportRequestDto requestDto) {
        return this.remittanceService.issuedRemittanceReport(requestDto);
    }
}