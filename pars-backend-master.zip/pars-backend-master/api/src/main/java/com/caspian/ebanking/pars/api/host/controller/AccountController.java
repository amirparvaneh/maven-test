package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.account.AccountService;
import com.caspian.ebanking.pars.api.service.business.account.dto.*;
import com.caspian.ebanking.pars.api.service.business.ach.dto.GetIbanFromAccountRequestDto;
import com.caspian.ebanking.pars.api.service.business.ach.dto.GetIbanFromAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.dto.GetDestinationAccountsResponseDto;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Atousa khanjani
 * @author Amir Tajik
 * @version 1.0
 * @since 12/28/2020 9:53 AM
 */
@RestController
@RequestMapping("/accounts")
@Api(tags = "account")
@RequiredArgsConstructor
public class AccountController extends BaseController {

    private final AccountService accountService;

    @ApiOperation(httpMethod = "GET", value = "Get user Accounts per Organization.", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/organizationAccounts")
    public GetUserAccountsResponseDto getUserAccounts(@RequestParam("serviceCode") String serviceCode) {
        return this.accountService.getUserAccounts(serviceCode);
    }

    @ApiOperation(httpMethod = "POST", value = "دریافت شماره شبا از روی شماره حساب", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/iban")
    public GetIbanFromAccountResponseDto getIbanFromUserAccount(@Valid @RequestBody GetIbanFromAccountRequestDto requestDto) {
        return this.accountService.getIbanFromUserAccount(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "Get Account Normal Statement", notes = "Account number is required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/normalStatement")
    public StatementResponseDto getNormalStatement(@RequestBody StatementRequestDto requestDto) {
        return this.accountService.getNormalStatement(requestDto);
    }

    @ApiOperation(httpMethod = "PATCH", value = "Set Comment for statement record", notes = "All fields are available from statement dto")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PatchMapping("/normalStatement/depositDetail")
    public ResultDto setCustomerDepositDetail(@RequestBody SetCustomerDepositDetailRequestDto requestDto) {
        return this.accountService.setCustomerDepositDetail(requestDto);
    }


    @ApiOperation(httpMethod = "GET", value = "Get organization's destination accounts.", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/destinationAccounts")
    public GetDestinationAccountsResponseDto getDestinationAccounts(@ApiParam(name = "Account Id", required = true, type = "Long", example = "12345") @RequestParam("accountId") Long accountId) {
        return this.accountService.getDestinationAccounts(accountId);
    }


    @ApiOperation(httpMethod = "GET", value = "Get summary statement.", notes = "Account number is required,PeriodType is required.")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/summaryStatement")
    public SummaryStatementResponseDto getSummaryStatement(SummaryStatementRequestDto requestDto) {
        return this.accountService.getSummaryStatement(requestDto);
    }


}