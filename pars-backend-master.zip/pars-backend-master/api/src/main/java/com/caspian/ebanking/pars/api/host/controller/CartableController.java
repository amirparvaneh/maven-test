package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.account.AccountService;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetDepositOwnerNameResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetWithdrawConditionsResponseDto;
import com.caspian.ebanking.pars.api.service.business.cartable.dto.*;
import com.caspian.ebanking.pars.api.service.business.cartable.service.CartableService;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @author Atousa Khanjani
 * @version 1.0
 * @since ۱۳/۰۱/۲۰۲۱ ۰۴:۰۶ قبل‌ازظهر
 */
@RestController
@RequestMapping("/cartable")
@Api(tags = "cartable")
@RequiredArgsConstructor
public class CartableController {
    private final CartableService cartableService;
    private final AccountService accountService;

    @ApiOperation(httpMethod = "GET", value = "Get Cartable Requests", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/requests")
    public CartableResponseDto getCartableRequests(CartableRequestDto requestDto) {
        return cartableService.getCartableReuquests(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت جزپیات درخواست انتقال وجه عادی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/request/normalTransfer/detail")
    public CartableNormalTransferDetailResponseDto getNormalTransferDetail(@RequestParam("requestCode") String requestCode) {
        return cartableService.getNormalTransferDetail(requestCode);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت جزپیات درخواست انتقال وجه گروهی عادی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/request/batchTransfer/detail")
    public CartableNormalBatchTransferDetailResponseDto getNormalBatchTransferDetail(@RequestParam("requestCode") String requestCode) {
        return cartableService.getNormalBatchTransferDetail(requestCode);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت جزپیات درخواست انتقال وجه گروهی فایلی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/request/fileGroupTransfer/detail")
    public CartableFileGroupTransferDetailResponseDto getFileGroupTransferDetail(@RequestParam("requestCode") String requestCode) {
        return cartableService.getFileGroupTransferDetail(requestCode);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت جزپیات درخواست انتقال وجه پایا گروهی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/request/achBatchTransfer/detail")
    public CartableAchBatchTransferDetailResponseDto getAchBatchTransferDetail(@RequestParam("requestCode") String requestCode) {
        return cartableService.getAchBatchTransferDetail(requestCode);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت جزپیات درخواست انتقال وجه پایا تکی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/request/achNormalTransfer/detail")
    public CartableAchNormalTransferDetailResponseDto getCartableAchNormalTransferDetail(@RequestParam("requestCode") String requestCode) {
        return cartableService.getAchNormalTransferDetail(requestCode);
    }

    @ApiOperation(httpMethod = "POST", value = "تایید درخواست کارتابل", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/request/approve")
    public ResultDto approveCartableRequest(@RequestBody ApproveCartableRequestDto requestDto) {
        return cartableService.approveCartableRequest(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = " کارتابل انتقال وجه تکی پایا")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/ach/single")
    public SingleCartableAchOrderTransferResponseDto singleCartableAchOrderTransfer(@RequestBody SingleCartableAchOrderTransferRequestDto requestDto) {
        return cartableService.singleCartableAchOrderTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = " کارتابل انتقال وجه گروهی پایا")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/ach/batch")
    public BatchCartableAchOrderTransferResponseDto batchCartableAchOrderTransfer(@RequestBody BatchCartableAchOrderTransferRequestDto requestDto) {
        return cartableService.batchCartableAchOrderTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت نام صاحب حساب", notes = "accountNo is Required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/ownerName")
    public GetDepositOwnerNameResponseDto getDepositOwnerName(@RequestParam("accountNo") String accountNo) {
        return accountService.getDepositOwnerName(accountNo);
    }


    @ApiOperation(httpMethod = "GET", value = "دریافت شرایط برداشت", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/withdrawConditions")
    public GetWithdrawConditionsResponseDto getWithdrawConditions(@RequestParam("accountNo") String accountNo, @RequestParam("amount") BigDecimal amount, @RequestParam @DateTimeFormat(pattern = "YYYY-MM-DD") Date expDate) {
        return cartableService.getWithdrawConditions(accountNo, amount, expDate);
    }

    @ApiOperation(httpMethod = "POST", value = "ریجکت درخواست کارتابل", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/request/reject")
    public ResultDto rejectCartableRequest(@RequestBody CartableRequestCodeDto requestDto) {
        return cartableService.rejectCartableRequest(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "تکمیل درخواست کارتابل", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/request/do")
    public ResultDto doCartableRequest(@RequestBody DoCartableRequestDto requestDto) {
        return cartableService.doCartableRequest(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "لغو درخواست کارتابل", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/request/cancel")
    public ResultDto cancelCartableRequest(@RequestBody CartableRequestCodeDto requestDto) {
        return cartableService.cancelCartableRequest(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "کارتابل انتقال وجه عادی تکی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/normalTransfer/single")
    public SingleCartableNormalFundTransferResponseDto singleCartableNormalFundTransfer(@RequestBody SingleCartableNormalFundTransferRequestDto requestDto) {
        return cartableService.singleCartableNormalFundTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "کارتابل انتقال وجه عادی گروهی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/normalTransfer/batch")
    public BatchCartableNormalFundTransferResponseDto batchCartableNormalFundTransfer(@RequestBody BatchCartableNormalFundTransferRequestDto requestDto) {
        return cartableService.batchCartableNormalFundTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = " کارتابل انتقال وجه تکی ساتنا")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/rtgs/single")
    public SingleCartableRtgsOrderTransferResponseDto singleCartableRtgsOrderTransfer(@RequestBody SingleCartableRtgsOrderTransferRequestDto requestDto) {
        return cartableService.singleCartableRtgsOrderTransfer(requestDto);
    }
}