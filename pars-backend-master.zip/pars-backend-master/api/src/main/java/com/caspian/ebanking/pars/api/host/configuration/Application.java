package com.caspian.ebanking.pars.api.host.configuration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/13/2020 10:25 AM
 */
@EnableScheduling
@EnableCaching
@PropertySource(value = {"classpath:application.properties", "classpath:gateway-jms.properties"})
@ImportResource("classpath:applicationContext-gateway-spi.xml")
@EnableJpaRepositories(basePackages = {"com.caspian.ebanking.pars.api.base.persistence"})
@EntityScan(basePackages = {"com.caspian.ebanking.pars.api.base.persistence"})
@SpringBootApplication(scanBasePackages = {"com.caspian.ebanking.pars.api"})
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }
}