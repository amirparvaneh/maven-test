package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.payment.dto.*;
import com.caspian.ebanking.pars.api.service.business.payment.service.PaymentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@RestController
@RequestMapping("/periodPayment")
@Api(tags = "periodPayment")
@RequiredArgsConstructor
public class PeriodPaymentController {

    private final PaymentService paymentService;


    @ApiOperation(httpMethod = "GET", value = "جستجو دوره پرداخت")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @GetMapping
    public LoadPeriodResponseDto loadPeriod(LoadPeriodRequestDto requestDto) {
        return this.paymentService.loadPeriod(requestDto);
    }

    @ApiOperation(httpMethod = "PUT", value = "ویرایش دوره پرداخت")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @PutMapping
    public ResultDto updatePeriod(@RequestBody PeriodRequestDto requestDto) {
        return this.paymentService.updatePeriod(requestDto);
    }

    @ApiOperation(httpMethod = "DELETE", value = "حذف دوره پرداخت", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @DeleteMapping
    public ResultDto removePeriod(@RequestParam(value = "id") Long id) {
        return this.paymentService.removePeriod(id);
    }

    @ApiOperation(httpMethod = "POST", value = "افزودن دوره پرداخت")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @PostMapping
    public Long addPeriod(@RequestBody PeriodRequestDto requestDto) {
        return paymentService.addPeriod(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "لود تاریخچه دوره پرداخت")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @GetMapping("/history")
    public LoadPeriodHistoryResponseDto loadPeriodHistory(@RequestParam(value = "id") Long id) {
        return this.paymentService.loadPeriodHistory(id);
    }

    @ApiOperation(httpMethod = "PUT", value = "ویرایش اشخاص دوره")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @PutMapping("/person")
    public ResultDto updatePeriodPerson(@RequestBody PeriodPersonRequestDto requestDto) {
        return paymentService.updatePeriodPerson(requestDto);
    }

    @ApiOperation(httpMethod = "DELETE", value = "حذف اشخاص دوره", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @DeleteMapping("/person")
    public ResultDto removePeriodPerson(@RequestParam(value = "id") Long id) {
        return paymentService.removePeriodPerson(id);
    }

    @ApiOperation(httpMethod = "POST", value = "افزودن اشخاص دوره")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @PostMapping("/person")
    public AddPeriodPersonResponseDto addPeriodPerson(@RequestBody AddPeriodPersonRequestDto requestDto) {
        return paymentService.addPeriodPerson(requestDto);
    }

    @ApiOperation(httpMethod = "PATCH", value = "غیر فعالسازی اشخاص دوره")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @PatchMapping("/person")
    public ResultDto inactivePeriodPerson(@RequestParam(value = "id") Long id) {
        return paymentService.inactivePeriodPerson(id);
    }

    @ApiOperation(httpMethod = "GET", value = "مشاهده اشخاص دوره")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @GetMapping("/person")
    public LoadPeriodPersonResponseDto loadPeriodPerson(LoadPeriodPersonRequestDto requestDto) {
        return this.paymentService.loadPeriodPerson(requestDto);
    }
}
