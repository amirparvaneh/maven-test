package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.UserDepartmentsDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.GetUserOrganizationsResponseDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.OrganizationUsersResponseDto;
import com.caspian.ebanking.pars.api.service.business.organization.service.OrganizationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/6/2021 10:11 AM
 */
@RestController
@RequestMapping("/organization")
@Api(tags = "organization")
@RequiredArgsConstructor
public class OrganizationController {

    private final OrganizationService organizationService;


    @ApiOperation(httpMethod = "GET", value = "Get organizations", notes = "This Api should be called after login,The user's Organizaton Must be selected.")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @GetMapping
    public GetUserOrganizationsResponseDto getOrganizations() {
        return this.organizationService.getUserOrganizations();
    }

    @ApiOperation(httpMethod = "PUT", value = "Set user Current Organization")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @PutMapping("/{organizationId}")
    public ResultDto setOrganization(@PathVariable("organizationId") Long organizationId) {
        return this.organizationService.setOrganization(organizationId);
    }

    @ApiOperation(httpMethod = "GET", value = "Get userList of Organization", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @GetMapping("/users")
    public OrganizationUsersResponseDto getOrganizationUsers() {
        return this.organizationService.getOrganizationUsers();
    }

    @ApiOperation(httpMethod = "GET", value = "Get User Departments Info", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @GetMapping("/departments")
    public UserDepartmentsDto getUserDepartments() {
        return this.organizationService.getUserDepartments();
    }

}
