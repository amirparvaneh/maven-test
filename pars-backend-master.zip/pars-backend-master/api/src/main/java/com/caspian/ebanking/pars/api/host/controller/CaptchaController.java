package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.captcha.CaptchaService;
import com.caspian.ebanking.pars.api.service.business.captcha.dto.LoginCaptchaResponseDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import nl.captcha.servlet.CaptchaServletUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 11:32 AM
 */
@RestController
@RequestMapping("/captcha")
@Api(tags = "captcha")
public class CaptchaController extends BaseController {

    private static final Logger logger = LoggerFactory.getLogger(CaptchaController.class);

    private final CaptchaService captchaService;

    @Autowired
    public CaptchaController(CaptchaService captchaService) {
        this.captchaService = captchaService;
    }

    @ApiOperation(httpMethod = "GET", value = "Generates captcha for login", notes = "This Api should be called only before login and does not need any Authorization.")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 500, message = "Internal Server Error")})
    @GetMapping(value = "/forLogin")
    public LoginCaptchaResponseDto generateCaptchaForLogin(HttpServletRequest request, HttpServletResponse response) {
        return this.captchaService.generateCaptchaForLogin(request.getSession().getId());
    }

    @GetMapping(value = "/forVerification")
    public void generateCaptchaForVerification(HttpServletResponse response) {
        CaptchaServletUtil.writeImage(response, this.captchaService.generateCaptchaForVerification().getImage());
    }
}
