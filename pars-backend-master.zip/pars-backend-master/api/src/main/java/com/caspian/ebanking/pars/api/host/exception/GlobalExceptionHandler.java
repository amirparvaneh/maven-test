package com.caspian.ebanking.pars.api.host.exception;

import com.caspian.ebanking.pars.api.base.exception.BadRequestException;
import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.service.business.general.GeneralService;
import com.caspian.ebanking.pars.api.service.business.general.dto.ExceptionTranslationResponseDto;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.util.Map;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 12:55 PM
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private final GeneralService generalService;
    private final CurrentUserService currentUserService;

    @Value("${server.exception-handling-debug-mode}")
    private Boolean debugMode;

    @Autowired
    public GlobalExceptionHandler(GeneralService generalService, CurrentUserService currentUserService) {
        this.generalService = generalService;
        this.currentUserService = currentUserService;
    }

    @ExceptionHandler(BadRequestException.class)
    public void handleBadRequestException(HttpServletResponse res, BadRequestException ex) throws IOException {
        res.sendError(HttpStatus.BAD_REQUEST.value(), ex.getMessage());
    }

    @ExceptionHandler(GatewayException.class)
    public void handleCustomException(HttpServletResponse res, GatewayException ex) throws IOException {
        final Throwable cause = ex.getCause();
        if (cause instanceof ChannelManagerException) {
            try {
                final ExceptionTranslationResponseDto exceptionTranslation = generalService.getExceptionTranslation(currentUserService.getClientDataControl().getLocale(), cause.getClass().getName());
                String err = exceptionTranslation.getTranslation() + (debugMode ? ("\n" + cause.getMessage()) : "");
                res.sendError(ex.getStatus(), err);
            } catch (Exception e) {
                logger.warn("Exception in Get Exception translation: " + e.getMessage());
                e.printStackTrace();
                res.sendError(ex.getStatus(), ex.getMessage());
            }
        } else {
            res.sendError(ex.getStatus(), ex.getMessage());
        }
    }

    @ExceptionHandler(AccessDeniedException.class)
    public void handleAccessDeniedException(HttpServletResponse res, AccessDeniedException ex) throws IOException {
        res.sendError(HttpStatus.FORBIDDEN.value(), ex.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public void handleException(HttpServletResponse res, Exception e) throws IOException {
        logger.warn("Unhandled Exception : " + e.getMessage());
        res.sendError(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Internal Server Error");
    }

    @Bean
    public ErrorAttributes errorAttributes() {
        // Hide exception field in the return object
        return new DefaultErrorAttributes() {
            @Override
            public Map<String, Object> getErrorAttributes(WebRequest webRequest, boolean includeStackTrace) {
                Map<String, Object> errorAttributes = super.getErrorAttributes(webRequest, includeStackTrace);
//                errorAttributes.remove("exception");
                return errorAttributes;
            }
        };
    }
}
