package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementReportResponseDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementRequestDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementResponseDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.service.OfflineStatementService;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChOfflineStatementType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۴/۰۱/۲۰۲۱ ۰۸:۴۹ قبل‌ازظهر
 */
@RestController
@RequestMapping("/offlineStatement")
@RequiredArgsConstructor
@Api(tags = "offlineStatement")
public class OfflineStatementController extends BaseController {

    private final OfflineStatementService offlineStatementService;
    @ApiOperation(httpMethod = "POST", value = " offline statement request.")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping
    public OfflineStatementResponseDto offlineStatementRequest(@Valid @RequestBody OfflineStatementRequestDto requestDto) {
        return this.offlineStatementService.offlineStatementRequest(requestDto, ChOfflineStatementType.NORMAL);
    }

    @ApiOperation(httpMethod = "GET", value = "report of OfflineStatement .")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping
    public OfflineStatementReportResponseDto getOfflineStatementReport(
            @RequestParam(required = false) @DateTimeFormat(pattern = "YYYY-MM-DD") Date fromDate,
                               @RequestParam (required = false) @DateTimeFormat(pattern = "YYYY-MM-DD") Date toDate) {
        return offlineStatementService.getOfflineStatementReport(fromDate,toDate,ChOfflineStatementType.NORMAL);
    }

    @ApiOperation(httpMethod = "GET", value = "download  Offline Statement file", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/report/file")
    public void downloadOfflineStatementFile(@RequestParam("fileType") String fileType, @RequestParam("requestId") Long requestId,
                                             HttpServletResponse response) {
        this.offlineStatementService.downloadOfflineStatementFile(requestId, fileType, response);
    }
}
