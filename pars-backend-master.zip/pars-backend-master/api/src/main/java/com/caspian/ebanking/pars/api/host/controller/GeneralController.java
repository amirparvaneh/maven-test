package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.general.GeneralService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/19/2020 1:38 AM
 */
@RestController
@RequestMapping("/general")
@Api(tags = "general")
public class GeneralController extends BaseController {

    private final GeneralService generalService;

    @Autowired
    public GeneralController(GeneralService generalService) {
        this.generalService = generalService;
    }



}
