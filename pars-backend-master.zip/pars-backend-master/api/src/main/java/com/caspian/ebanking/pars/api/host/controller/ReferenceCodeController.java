package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementReportResponseDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementRequestDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementResponseDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.service.OfflineStatementService;
import com.caspian.ebanking.pars.api.service.business.referencecode.dto.*;
import com.caspian.ebanking.pars.api.service.business.referencecode.service.ReferenceCodeService;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChOfflineStatementType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.Date;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 9:38 AM
 */
@RestController
@RequestMapping("/referenceCode")
@Api(tags = "referenceCode")
@RequiredArgsConstructor
public class ReferenceCodeController extends BaseController {

    private final ReferenceCodeService referenceCodeService;
    private final OfflineStatementService offlineStatementService;

    @ApiOperation(httpMethod = "GET", value = "دریافت نوع عملیات", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/operations")
    public GetOperationListResponseDto getOperationList() {
        return referenceCodeService.getOperationList();
    }

    @ApiOperation(httpMethod = "POST", value = "تعریف عنوان واریز", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/settlementTitle")
    public SettlementTitleResponseDto createSettlementTitle(@RequestBody SettlementTitleRequestDto requestDto) {
        return referenceCodeService.createSettlementTitle(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت لیست واریز کننده ها", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/liquidators")
    public GetLiquidatorListResponseDto getLiquidatorList() {
        return this.referenceCodeService.getLiquidatorList();
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت  سلسله مراتب واریز کننده ها", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/liquidators/hierarchy")
    public GetLiquidatorHierarchyResponseDto getLiquidatorsHierarchy() {
        return this.referenceCodeService.getLiquidatorsHierarchy();
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت  سلسله مراتب عناوین واریز", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/settlementTitles/hierarchy")
    public GetSettlementTitleHierarchyResponseDto getSettlementTitleHierarchy() {
        return this.referenceCodeService.getSettlementTitleHierarchy();
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش شناسه های واریزی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping
    public ReferenceCodeReportResponseDto getReferenceCodeReport(ReferenceCodeReportRequestDto requestDto) {
        return this.referenceCodeService.getReferenceCodeReport(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت اکسل گزارش شناسه های واریزی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/excel")
    public void getReferenceCodeExcelReport(ReferenceCodeReportRequestDto requestDto,@RequestParam("fileType") String fileType,
                                            HttpServletResponse response) {
         this.referenceCodeService.getReferenceCodeExcelReport(requestDto,fileType,response);
    }

    @ApiOperation(httpMethod = "POST", value = "تولید شناسه واریز", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping
    public CreateReferenceCodeResponseDto generateReferenceCode(@RequestBody CreateReferenceCodeRequestDto requestDto) {
        return this.referenceCodeService.generateReferenceCode(requestDto);
    }

    @ApiOperation(httpMethod = "PUT", value = "تغییر وضعیت شناسه واریز", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PutMapping
    public ResultDto changeReferenceCodeStatus(@RequestBody ChangeReferenceCodeStatusRequestDto requestDto) {
        return this.referenceCodeService.changeReferenceCodeStatus(requestDto);
    }


    @ApiOperation(httpMethod = "POST", value = "تعریف واریز کننده", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/liquidator")
    public ResultDto createLiquidator(@RequestBody @Valid CreateLiquidatorRequestDto requestDto) {
        return this.referenceCodeService.createLiquidator(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش صورتحساب با شناسه واریز", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("statement/report")
    public StatementWithReferenceCodeReportResponseDto getStatementWithReferenceCodeReport(StatementWithReferenceCodeReportRequestDto requestDto) {
        return this.referenceCodeService.getStatementWithReferenceCodeReport(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت اکسل گزارش صورتحساب با شناسه واریز", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("statement/report/excel")
    public void getStatementWithReferenceCodeExcelReport(StatementWithReferenceCodeReportRequestDto requestDto,@RequestParam("fileType") String fileType,
                                                         HttpServletResponse response) {
         this.referenceCodeService.getStatementWithReferenceCodeExcelReport(requestDto,fileType,response);
    }

    @ApiOperation(httpMethod = "GET", value = " دریافت پی دی اف گزارش صورتحساب با شناسه واریز", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("statement/report/pdf")
    public void getStatementWithReferenceCodePdfReport(StatementWithReferenceCodeReportRequestDto requestDto,
                                                         HttpServletResponse response) {
        this.referenceCodeService.getStatementWithReferenceCodePdfReport(requestDto,response);
    }
    @ApiOperation(httpMethod = "PUT", value = "ویرایش واریز کننده", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PutMapping("/liquidator")
    public ResultDto updateLiquidator(@RequestBody @Valid CreateLiquidatorRequestDto requestDto) {
        return this.referenceCodeService.updateLiquidator(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت عنوان واریز", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/settlementTitle")
    public GetSettlementTitleListResponseDto getSettlementTitleList(GetSettlementTitleListRequestDto requestDto) {
        return referenceCodeService.getSettlementTitleList(requestDto);
    }

    @ApiOperation(httpMethod = "PUT", value = "ویرایش عنوان واریز", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PutMapping("/settlementTitle")
    public SettlementTitleResponseDto updateSettlementTitle(@RequestBody SettlementTitleRequestDto requestDto) {
        return referenceCodeService.updateSettlementTitle(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش واریز بر اساس شناسه", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/deposit/report")
    public DepositByReferenceCodeReportResponseDto depositByReferenceCodeReport(DepositByReferenceCodeReportRequestDto requestDto) {
        return referenceCodeService.depositByReferenceCodeReport(requestDto);
    }
    @ApiOperation(httpMethod = "GET", value = "لیست بانک ها", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/banks")
    public GetBankInfoResponseDto getBankInfo() {
        return referenceCodeService.getBankInfo();
    }

    @ApiOperation(httpMethod = "POST", value = "ثبت درخواست صورتحساب آفلاین با شناسه واریز")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/offlineStatement")
    public OfflineStatementResponseDto offlineStatementRequest(@Valid @RequestBody OfflineStatementRequestDto requestDto) {
        return this.offlineStatementService.offlineStatementRequest(requestDto, ChOfflineStatementType.WITH_PAYMENT_ID);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش درخواست صورتحساب آفلاین با شناسه واریز")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/offlineStatement")
    public OfflineStatementReportResponseDto getOfflineStatementReport(
            @RequestParam(required = false) @DateTimeFormat(pattern = "YYYY-MM-DD") Date fromDate,
            @RequestParam(required = false) @DateTimeFormat(pattern = "YYYY-MM-DD") Date toDate) {
        return offlineStatementService.getOfflineStatementReport(fromDate, toDate, ChOfflineStatementType.WITH_PAYMENT_ID);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش شناسه های پرداختی با چک", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("statementByCheque/report")
    public GetReferenceCodeStatementByChequeResponseDto getReferenceCodeStatementByCheque(GetReferenceCodeStatementByChequeRequestDto requestDto) {
        return referenceCodeService.getReferenceCodeStatementByCheque(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "پی دی اف گزارش شناسه های پرداختی با چک")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("statementByCheque/report/pdf")
    public void getReferenceCodeStatementByChequePdfReport(GetReferenceCodeStatementByChequeRequestDto requestDto, HttpServletResponse response) {
        referenceCodeService.getReferenceCodeStatementByChequePdfReport(requestDto, response);
    }
}
