package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.account.AccountService;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetSourceAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.IbanInquiryByCentralBankResponseDto;
import com.caspian.ebanking.pars.api.service.business.rtgs.dto.*;
import com.caspian.ebanking.pars.api.service.business.rtgs.service.RtgsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۴/۰۱/۲۰۲۱ ۰۱:۱۳ بعدازظهر
 */
@RestController
@RequestMapping("/rtgs")
@RequiredArgsConstructor
@Api(tags = "rtgs")
public class RtgsController extends BaseController {
    private final RtgsService rtgsService;
    private final AccountService accountService;

    @ApiOperation(httpMethod = "POST", value = " انتقال وجه ساتنا")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/transfer/single")
    public RtgsSingleTransferResponseDto singleTransfer(@Valid @RequestBody RtgsSingleTransferRequestDto requestDto) {
        return rtgsService.singleTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = " گزارش انتقال وجه ساتنا(لیست انتقال ها)")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/transfer/report")
    public RtgsTransferReportResponseDto transferReport(RtgsTransferReportRequestDto requestDto) {
        return rtgsService.transferReport(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = " گزارش انتقال وجه ساتنا(لیست تراکنش ها)")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/transaction/report")
    public RtgsTransactionReportResponseDto transferReport(RtgsTransactionReportRequestDto requestDto) {
        return rtgsService.transactionReport(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "inquiry Iban By CentralBank.", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/ibanInquiry")
    public IbanInquiryByCentralBankResponseDto ibanInquiryByCentralBank(@RequestParam("iban") String iban, @RequestParam("amount") BigDecimal amount, @RequestParam(value = "paymentCode", required = false) String paymentCode) {
        return this.accountService.ibanInquiryByCentralBank(iban, amount, paymentCode);
    }

    @ApiOperation(httpMethod = "GET", value = "Get source Accounts per Organization.")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/sourceAccounts")
    public GetSourceAccountResponseDto getSourceAccount(@RequestParam(value = "accountType", required = false) String accountType) {
        return this.accountService.getSourceAccount("RTGS_NORMAL_TRANSFER",accountType);
    }

}
