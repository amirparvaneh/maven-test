package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.base.security.JwtTokenProvider;
import com.caspian.ebanking.pars.api.base.security.dto.LoginRequest;
import com.caspian.ebanking.pars.api.base.security.dto.LoginResponse;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.user.UserService;
import com.caspian.ebanking.pars.api.service.business.user.dto.ChangePasswordRequestDto;
import com.caspian.ebanking.pars.api.service.business.user.dto.ChangeUsernameRequestDto;
import com.caspian.ebanking.pars.api.service.business.user.dto.LoginResponseDto;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 2:26 PM
 */
@RestController
@RequestMapping("/user")
@Api(tags = "user")
public class UserController extends BaseController {

    private final UserService userService;
    private final JwtTokenProvider jwtTokenProvider;

    @Autowired
    public UserController(UserService userService, JwtTokenProvider jwtTokenProvider) {
        this.userService = userService;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @PostMapping("/login")
    @ApiOperation(httpMethod = "POST", value = "Login", notes = "Login and get Channel Manager token")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 422, message = "Invalid user/pass")})
    public LoginResponseDto login(@ApiParam("Login Request Dto") @RequestBody LoginRequest requestDto, HttpServletRequest request) {
        final LoginResponse loginResponse = userService.login(requestDto, request);
        return new LoginResponseDto(this.jwtTokenProvider.createToken(requestDto.getUsername(), loginResponse), loginResponse.getMenu(), loginResponse.getOrganizations());
    }

    @PutMapping("/username")
    @ApiOperation(httpMethod = "PUT", value = "Change username", notes = "Change current user username.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 422, message = "Invalid user/pass")})
    public ResultDto changeUsername(@ApiParam("Change username Request Dto") @RequestBody ChangeUsernameRequestDto requestDto) {
        return this.userService.changeUsername(requestDto);
    }

    @PutMapping("/password")
    @ApiOperation(httpMethod = "PUT", value = "Change password", notes = "Change current user login/second password.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 422, message = "Invalid user/pass")})
    public ResultDto changePassword(@ApiParam("Change username Request Dto") @RequestBody ChangePasswordRequestDto requestDto) {
        return this.userService.changePassword(requestDto);
    }

    @PostMapping("/logout")
    @ApiOperation(httpMethod = "POST", value = "Logout", notes = "Logout and clear client user data from user context")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok"),
            @ApiResponse(code = 403, message = "")})
    public ResultDto logout() {
        return userService.logout();
    }
}
