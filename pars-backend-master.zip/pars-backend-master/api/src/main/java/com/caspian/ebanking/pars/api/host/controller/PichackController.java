package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.account.AccountService;
import com.caspian.ebanking.pars.api.service.business.account.dto.*;
import com.caspian.ebanking.pars.api.service.business.ach.dto.GetIbanFromAccountRequestDto;
import com.caspian.ebanking.pars.api.service.business.ach.dto.GetIbanFromAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.dto.GetDestinationAccountsResponseDto;
import com.caspian.ebanking.pars.api.service.business.pichak.dto.*;
import com.caspian.ebanking.pars.api.service.business.pichak.service.PichakService;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 12/28/2020 9:53 AM
 */
@RestController
@RequestMapping("/pichack")
@Api(tags = "pichack")
@RequiredArgsConstructor
public class PichackController extends BaseController {

    private final PichakService pichakService;

    @ApiOperation(httpMethod = "POST", value = ".", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/issue")
    public PichakIssueChequeResponseDto pichakIssueCheque(@RequestBody PichakIssueChequeRequestDto requestDto) {
        return this.pichakService.pichakIssueCheque(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = ".", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/issue")
    public PichakTransferChequeResponseDto pichakTransferCheque(@RequestBody PichakTransferChequeRequestDto requestDto) {
        return this.pichakService.pichakTransferCheque(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = ".", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/inquiry")
    public PichakChequeInquiryResponseDto pichakChequeInquiry(@RequestBody PichakInquiryChequeRequestDto requestDto) {
        return this.pichakService.pichakChequeInquiry(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = ".", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/issue")
    public PichakSetChequeConfirmStatusResponseDto setChequeConfirmStatus(@RequestBody PichakSetChequeConfirmStatusRequestDto requestDto) {
        return this.pichakService.setChequeConfirmStatus(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = ".", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/cartable")
    public GetChequeCartableResponseDto getChequeCartable(GetChequeCartableRequestDto requestDto) {
        return this.pichakService.getChequeCartable(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = ".", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/do/cartable")
    public DoChequeCartableResponseDto doChequeCartable(@RequestBody DoChequeCartableRequestDto requestDto) {
        return this.pichakService.doChequeCartable(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = ".", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/approve/cartable")
    public ApproveChequeCartableResponseDto approveChequeCartable(@RequestBody ApproveChequeCartableRequestDto requestDto) {
        return this.pichakService.approveChequeCartable(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = ".", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/cancel/cartable")
    public CancelChequeCartableResponseDto cancelChequeCartable(@RequestBody CancelChequeCartableRequestDto requestDto) {
        return this.pichakService.cancelChequeCartable(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = ".", notes = "All fields are required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/reject/cartable")
    public RejectChequeCartableResponseDto rejectChequeCartable(@RequestBody RejectChequeCartableRequestDto requestDto) {
        return this.pichakService.rejectChequeCartable(requestDto);
    }

}