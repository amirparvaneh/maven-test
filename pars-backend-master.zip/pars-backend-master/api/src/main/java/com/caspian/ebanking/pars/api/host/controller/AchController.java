package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.account.AccountService;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetDestinationIbanResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetSourceAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.IbanInquiryByCentralBankResponseDto;
import com.caspian.ebanking.pars.api.service.business.ach.dto.*;
import com.caspian.ebanking.pars.api.service.business.ach.service.AchService;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * @author Atousa Khanjani
 * @author Amir Tajik
 * @version 1.0
 * @since 1/4/2021 12:09 PM
 */
@RestController
@RequestMapping("/ach")
@Api(tags = "ACH")
@RequiredArgsConstructor
public class AchController {

    private final AchService achService;
    private final AccountService accountService;

    @ApiOperation(httpMethod = "POST", value = "Cancel ACH Service", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/transaction/cancel")
    public ResultDto cancelAchTransaction(@RequestBody CancelAchTransactionRequestDto requestDto) {
        return this.achService.cancelAchTransaction(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "Ach Transaction Report", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/transaction/report")
    public AchTransactionReportResponseDto achTransactionReport(@RequestBody AchTransactionReportRequestDto requestDto) {
        return this.achService.achTransactionReport(requestDto);
    }


    @ApiOperation(httpMethod = "POST", value = "Ach Transfer Report", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/transfer/report")
    public AchTransferReportResponseDto achTransferReport(@RequestBody AchTransferReportRequestDto requestDto) {
        return this.achService.achTransferReport(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "Ach Single Transfer", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/transfer/single")
    public AchSingleTransferResponseDto achSingleTransfer(@RequestBody AchSingleTransferRequestDto requestDto) {
        return this.achService.achSingleTransfer(requestDto);
    }
    @ApiOperation(httpMethod = "GET", value = "Get source Accounts per Organization.")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/sourceAccounts")
    public GetSourceAccountResponseDto getSourceAccount( @RequestParam(value = "accountType", required = false) String accountType) {
        return this.accountService.getSourceAccount("ACH_NORMAL_TRANSFER",accountType);
    }

    @ApiOperation(httpMethod = "GET", value = "Get Destination Iban per  AccountId.", notes = "accountId is Required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/destinationIban")
    public GetDestinationIbanResponseDto getDestinationIban(@RequestParam("accountId") Long accountId) {
        return this.accountService.getDestinationIban(accountId);
    }
    @ApiOperation(httpMethod = "POST", value = "Cancel ACH Request", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/cancel")
    public ResultDto cancelAchRequest(@RequestBody CancelAchRequestDto requestDto) {
        return this.achService.cancelAchRequest(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "inquiry Iban By CentralBank.", notes = "accountId is Required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/ibanInquiry")
    public IbanInquiryByCentralBankResponseDto ibanInquiryByCentralBank(@RequestParam("iban") String iban, @RequestParam("amount") BigDecimal amount, @RequestParam(value = "paymentCode", required = false) String paymentCode) {
        return this.accountService.ibanInquiryByCentralBank(iban, amount, paymentCode);
    }


}
