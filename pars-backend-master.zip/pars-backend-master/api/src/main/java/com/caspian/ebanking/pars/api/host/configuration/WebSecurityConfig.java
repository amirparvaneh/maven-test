package com.caspian.ebanking.pars.api.host.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    private FilterConfigurer filterConfigurer;

    @Autowired
    public WebSecurityConfig(FilterConfigurer filterConfigurer) {
        this.filterConfigurer = filterConfigurer;
    }

    //TODO  Un-secure H2 Database (for testing purposes, H2 console shouldn't be unprotected in production)
    public static String[] ALLOWED_URIS = {"/user/login", "/captcha/forLogin", "/h2-console/**", "/h2-console/**", "/swagger-ui/**", "/v2/api-docs", "/swagger-resources/**", "/swagger-ui.html"};

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        // Disable CSRF
        http.csrf().disable();
        http.cors();

        // No session will be created or used by spring security
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        // Entry points
        http.authorizeRequests()
                .antMatchers(ALLOWED_URIS).permitAll()
                // Disallow everything else..
                .anyRequest().authenticated();

        // If a user try to access a resource without having enough permissions
//        http.exceptionHandling().accessDeniedPage("/user/login");

        // Apply JWT
        http.apply(filterConfigurer);

//        http.httpBasic();
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        // Allow swagger to be accessed without authentication
        web.ignoring().antMatchers(ALLOWED_URIS);
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return authenticationManager();
    }
}
