package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.test.TestService;
import com.caspian.ebanking.pars.api.service.business.test.dto.AddRequestDto;
import com.caspian.ebanking.pars.api.service.business.test.dto.AddResponseDto;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/13/2020 11:12 AM
 */
@RestController
@RequestMapping("/test")
@Api(tags = "test")
public class TestController extends BaseController {

    private final TestService testService;

    @Autowired
    public TestController(TestService testService) {
        this.testService = testService;
    }

    @ApiOperation(httpMethod = "POST", value = "example text", notes = "note text ")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 422, message = "description."),
            @ApiResponse(code = 401, message = "description"),
            @ApiResponse(code = 403, message = "description"),
            @ApiResponse(code = 404, message = "description"),
            @ApiResponse(code = 412, message = "description."),
            @ApiResponse(code = 500, message = "description.")})
    @PostMapping("/add")
    public AddResponseDto add(@ApiParam("Add Requets Dto") @RequestBody AddRequestDto requestDto) {
        return testService.add(requestDto);
    }

    @GetMapping("/subtract")
    public ResultDto subtract(@RequestParam("a") int a, @RequestParam("b") int b) throws Exception {
        return testService.subtract(a, b);
    }

    @GetMapping("/clientDataControl")
    public List<ClientDataControl> getClientDataControl() {
        return testService.getClientDataControl();
    }


    @GetMapping("/randomException")
    public ResultDto randomException() {
        return testService.randomException();
    }

}
