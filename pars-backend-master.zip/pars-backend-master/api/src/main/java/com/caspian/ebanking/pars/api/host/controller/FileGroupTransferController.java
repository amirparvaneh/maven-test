package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto.*;
import com.caspian.ebanking.pars.api.service.business.filegrouptransfer.service.FileGroupTransferService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 1/4/2021 12:30 PM
 */
@RestController
@RequestMapping("/fileGroupTransfer")
@Api(tags = "fileGroupTransfer")
@RequiredArgsConstructor
public class FileGroupTransferController {

    private final FileGroupTransferService fileGroupTransferService;

    @ApiOperation(httpMethod = "POST", value = "ثبت درخواست انتقال وجه گروهی فایلی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping
    public RegisterGroupTransferResponseDto registerGroupTransfer(@RequestBody RegisterGroupTransferRequestDto requestDto) {
        return this.fileGroupTransferService.registerGroupTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش انتقال وجه گروهی فایلی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping
    public SearchGroupTransferResponseDto searchGroupTransfer(SearchGroupTransferRequestDto requestDto) {
        return this.fileGroupTransferService.searchGroupTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "جزییات انتقال وجه گروهی فایلی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/detail")
    public SearchGroupTransferDetailResponseDto searchGroupTransferDetail(SearchGroupTransferDetailRequestDto requestDto) {
        return this.fileGroupTransferService.searchGroupTransferDetail(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "لغو انتقال وجه گروهی فایلی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/cancel")
    public GroupTransferDto canceleGroupTransfer(@RequestBody CancelGroupTransferDto requestDto) {
        return this.fileGroupTransferService.cancelGroupTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "لغو جزییات انتقال وجه گروهی فایلی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/cancel/detail")
    public GroupTransferDetailDto canceGroupTransferDetail(@RequestBody CancelGroupTransferDetailDto requestDto) {
        return this.fileGroupTransferService.cancelGroupTransferDetail(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت کانفیگ انتقال وجه گروهی فایلی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/config")
    public GetGroupTransferConfigResponseDto getGroupTransferConfig() {
        return this.fileGroupTransferService.getGroupTransferConfig();
    }

    @ApiOperation(httpMethod = "POST", value = "تایید نهایی انتقال وجه گروهی فایلی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/finalConfirm")
    public FinalConfirmGroupTransferResponseDto finalConfirmGroupTransfer(@RequestBody FinalConfirmGroupTransferRequestDto requestDto) {
        return this.fileGroupTransferService.finalConfirmGroupTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "POST", value = "ثبت کارتابل انتقال وجه گروهی فایلی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/cartable")
    public RegisterCartableGroupFileTransferResponseDto registerCartableGroupFileTransfer(@RequestBody RegisterCartableGroupFileTransferRequestDto requestDto) {
        return this.fileGroupTransferService.registerCartableGroupFileTransfer(requestDto);
    }


}
