package com.caspian.ebanking.pars.api.host.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/13/2020 3:14 PM
 */
public class BaseController {
}
