package com.caspian.ebanking.pars.api.host.controller;
/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */

import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementReportResponseDto;
import com.caspian.ebanking.pars.api.service.business.payment.dto.BillPaymentReportRequestDto;
import com.caspian.ebanking.pars.api.service.business.payment.dto.BillPaymentReportResponseDto;
import com.caspian.ebanking.pars.api.service.business.payment.dto.BillPaymentRequestDto;
import com.caspian.ebanking.pars.api.service.business.payment.dto.BillPaymentResponseDto;
import com.caspian.ebanking.pars.api.service.business.payment.service.PaymentService;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChOfflineStatementType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping("/billPayment")
@RequiredArgsConstructor
@Api(tags = "billPayment")
public class BillPaymentController extends BaseController {
    private final PaymentService paymentService;

    @ApiOperation(httpMethod = "POST", value = "پرداخت قبض تکی", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/single")
    public BillPaymentResponseDto singleBillPayment(@RequestBody BillPaymentRequestDto requestDto) {
        return paymentService.singleBillPayment(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش قبض های پرداخت شده")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping
    public BillPaymentReportResponseDto getPayedBillsReport(BillPaymentReportRequestDto requestDto)
    {
        return paymentService.getPayedBillsReport(requestDto);
    }
}
