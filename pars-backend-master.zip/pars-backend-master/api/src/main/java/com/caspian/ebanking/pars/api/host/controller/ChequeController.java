package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.account.AccountService;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetSourceAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.cheque.dto.*;
import com.caspian.ebanking.pars.api.service.business.cheque.service.ChequeService;
import com.caspian.ebanking.pars.api.service.business.organization.dto.UserDepartmentsDto;
import com.caspian.ebanking.pars.api.service.business.organization.service.OrganizationService;
import com.caspian.ebanking.pars.api.service.business.referencecode.dto.GetBankInfoResponseDto;
import com.caspian.ebanking.pars.api.service.business.referencecode.service.ReferenceCodeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۲:۴۶ بعدازظهر
 */
@RestController
@RequestMapping("/cheque")
@Api(tags = "cheque")
@RequiredArgsConstructor
public class ChequeController {

    private final ChequeService chequeService;
    private final AccountService accountService;
    private final ReferenceCodeService referenceCodeService;
    private final OrganizationService organizationService;

    @ApiOperation(httpMethod = "GET", value = "لیست حسابهای جاری")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/jariAccounts")
    public GetSourceAccountResponseDto getSourceAccount(@RequestParam(value = "accountType", required = false) String accountType) {
        return this.accountService.getSourceAccount(null, accountType);
    }

    @ApiOperation(httpMethod = "GET", value = "لیست بانک ها", notes = "")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/banks")
    public GetBankInfoResponseDto getBankInfo() {
        return referenceCodeService.getBankInfo();
    }

    @ApiOperation(httpMethod = "GET", value = "Get User Departments Info", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/departments")
    public UserDepartmentsDto getUserDepartments() {
        return this.organizationService.getUserDepartments();
    }

    @ApiOperation(httpMethod = "GET", value = "فهرست دسته چک های فعال", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/chequeBook/active")
    public ActiveChequeBookResponseDto getActiveChequeBook‌List(ActiveChequeBookRequestDto requestDto) {
        return this.chequeService.getActiveChequeBook‌List(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "وضعیت چک های واگذار شده", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/transferred")
    public TransferredChequeResponseDto getTransferredChequeList(TransferredChequeRequestDto requestDto) {
        return this.chequeService.getTransferredChequeList(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "وضعیت برگه های دسته چک", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/chequeSheet/detail")
    public ChequeSheetDetailResponseDto getChequeSheetDetails(ChequeSheetDetailRequestDto requestDto) {
        return this.chequeService.getChequeSheetDetails(requestDto);
    }

    @ApiOperation(httpMethod = "PUT", value = "ویرایش برگه چک", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PutMapping
    public void updateCheque(@RequestBody ChequeRegisterRequestDto requestDto) {
        this.chequeService.updateCheque(requestDto);
    }

 /*   @ApiOperation(httpMethod = "POST", value = "ثبت برگه چک", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = ""),
            @ApiResponse(code = 401, message = "Unauthorized")})
    @PostMapping
    public void registerCheque(@RequestBody ChequeRegisterRequestDto requestDto) {
        this.chequeService.registerCheque(requestDto);
    }*/

    @ApiOperation(httpMethod = "PUT", value = "انسداد موقت چک", notes = "")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PutMapping("/block")
    public BlockChequeResponseDto temporaryBlockage(BlockChequeRequestDto requestDto) {
        return this.chequeService.temporaryBlockage(requestDto);
    }
}