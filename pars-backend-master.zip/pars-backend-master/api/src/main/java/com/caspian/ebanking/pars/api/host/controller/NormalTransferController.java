package com.caspian.ebanking.pars.api.host.controller;

import com.caspian.ebanking.pars.api.service.business.account.AccountService;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetDepositOwnerNameResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetSourceAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.dto.*;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.service.NormalTransferService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/4/2021 12:30 PM
 */
@RestController
@RequestMapping("/normalTransfer")
@Api(tags = "normalTransfer")
@RequiredArgsConstructor
public class NormalTransferController {

    private final NormalTransferService normalTransferService;
    private final AccountService accountService;

    @ApiOperation(httpMethod = "POST", value = "Single Normal fund transfer.")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @PostMapping("/single")
    public SingleNormalFundTransferResponseDto singleNormalFundTransfer(@RequestBody SingleNormalFundTransferRequestDto requestDto) {
        return this.normalTransferService.singleNormalFundTransfer(requestDto);
    }

    @ApiOperation(httpMethod = "GET", value = "Get source accounts per Organization.")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/sourceAccounts")
    public GetSourceAccountResponseDto getSourceAccounts(@RequestParam(value = "accountType", required = false) String accountType) {
        return this.accountService.getSourceAccount("NORMAL_TRANSFER", accountType);
    }

    @ApiOperation(httpMethod = "GET", value = "دریافت نام صاحب حساب", notes = "accountNo is Required")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/ownerName")
    public GetDepositOwnerNameResponseDto getDepositOwnerName(@RequestParam("accountNo") String accountNo) {
        return accountService.getDepositOwnerName(accountNo);
    }

    @ApiOperation(httpMethod = "GET", value = "گزارش دستور انتقال مستمر")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/report")
    public AutoNormalTransferReportResponseDto autoNormalTransferReport(AutoNormalTransferReportRequestDto requestDto) {
        return normalTransferService.autoNormalTransferReport(requestDto);

    }

    @ApiOperation(httpMethod = "POST", value = "سرویس دستور پرداخت مستمر عادی")
    @ResponseBody
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK !"),
            @ApiResponse(code = 401, message = ""),
            @ApiResponse(code = 403, message = ""),
            @ApiResponse(code = 500, message = "")})
    @GetMapping("/auto")
    public AutoFundTransferResponseDto autoFundTransfer(@RequestBody AutoFundTransferRequestDto requestDto) {
        return normalTransferService.autoFundTransfer(requestDto);

    }
}
