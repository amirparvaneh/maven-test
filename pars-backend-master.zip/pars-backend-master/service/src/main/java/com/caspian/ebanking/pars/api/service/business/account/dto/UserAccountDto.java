package com.caspian.ebanking.pars.api.service.business.account.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/28/2020 12:37 PM
 */
@Data
public class UserAccountDto {

    private Long id;
    private String accountNumber; // NUMBER
    private Long accountTypeId; // NUMBER
    private String accountTypeTitle; // NUMBER

    private Long organization; // NUMBER
    private String organizationTitle; // NUMBER
    private String originalDescription;
    private java.util.Date timeStamp; // TIMESTAMP(6)
    private String description; // VARCHAR2

    private BigDecimal balance, availableBalance, blockedAmount;
    private String group, status, branch;
    private String groupStr, statusStr, branchStr;
    private Date lastRefresh;
    private String iban;
    private List<String> departmentUsage;
    private List<Long> departmentUsageIds;
    private String path;

}
