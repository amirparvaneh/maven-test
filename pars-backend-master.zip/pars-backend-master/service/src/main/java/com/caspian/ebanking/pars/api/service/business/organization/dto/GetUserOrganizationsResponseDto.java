package com.caspian.ebanking.pars.api.service.business.organization.dto;

import com.caspian.ebanking.pars.api.base.security.dto.OrganizationRelDto;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/19/2020 12:44 AM
 */
@Data
@AllArgsConstructor
public class GetUserOrganizationsResponseDto {
    private List<OrganizationRelDto> organizationRelDtoList;
}
