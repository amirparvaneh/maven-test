package com.caspian.ebanking.pars.api.service.business.ach.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/31/2020 11:05 AM
 */
@Data
public class AchTransactionReportItemDto {
    private String sourceIbanNumber;
    private Boolean resumeable;
    private String referenceId;
    private String id;
    private String factorNumber;
    private BigDecimal amount;
    private String currency;
    private String ibanNumber;
    private String ibanOwnerName;
    private Date issueDate;
    private String status;
    private Boolean cancelable;
    private Boolean suspendable;
    private Boolean changeable;
    private String description;

    public Date getIssueDate() {
        return new Date();
    }
}
