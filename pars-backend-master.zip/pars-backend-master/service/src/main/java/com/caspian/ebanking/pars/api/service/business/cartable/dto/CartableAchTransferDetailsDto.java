package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۹/۰۱/۲۰۲۱ ۰۳:۰۰ قبل‌ازظهر
 */
@Data
public class CartableAchTransferDetailsDto {
    private String description;
    private String ibanNumber;
    private String ibanBankName;
    private String ownerName;
    private String factorNumber;
    private BigDecimal amount;
}