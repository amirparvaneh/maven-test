package com.caspian.ebanking.pars.api.service.business.account.exception;

/**
 * @author atousa khanjani
 * @since 12/29/2020 07:34 PM
 */
public class IbanInquiryByCBException extends RuntimeException {
    public IbanInquiryByCBException(String message) {
        super(message);
    }

    public IbanInquiryByCBException(String message, Throwable cause) {
        super(message, cause);
    }

    public IbanInquiryByCBException(Throwable cause) {
        super(cause);
    }

    public IbanInquiryByCBException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
