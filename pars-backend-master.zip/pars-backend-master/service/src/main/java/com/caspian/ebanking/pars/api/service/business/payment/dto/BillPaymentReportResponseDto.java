package com.caspian.ebanking.pars.api.service.business.payment.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class BillPaymentReportResponseDto {

    private List<BillPaymentReportDto> billPaymentReportDtos;
    private Integer totalCount;
}
