package com.caspian.ebanking.pars.api.service.business.account.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

@Data
@ApiModel
public class SummaryStatementRequestDto {

    @ApiModelProperty(value = "شماره حساب", required = true)
    private String accountNumber;

    @ApiModelProperty(value = "دوره زمانی", required = true, allowableValues = "YEARLY,MONTHLY,WEEKLY")
    private String PeriodType;

    @ApiModelProperty(value = "از تاریخ")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fromDate;

    @ApiModelProperty(value = "تا تاریخ")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date toDate;

    @ApiModelProperty(value = "از مبلغ")
    private BigDecimal fromAmount;

    @ApiModelProperty(value = "تا مبلغ")
    private BigDecimal toAmount;

    @ApiModelProperty(value = "نوع تراکنش", allowableValues = "CREDIT,DEBIT,BOTH")
    private String transactionType;

}
