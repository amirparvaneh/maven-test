package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۱/۰۲/۲۰۲۱ ۱۲:۱۵ بعدازظهر
 */
@Data
public class ReferenceCodeDetailDto {
    @ApiModelProperty(value = "عنوان واریز")
    private String settleTitle;
    @ApiModelProperty(value = "کد عنوان واریز")
    private String settleTitleCode;
    @ApiModelProperty(value = "کد عملیات")
    private String operationCode;
    @ApiModelProperty(value = "مبلغ واریز")
    private BigDecimal amount;
    @ApiModelProperty(value = "تعداد")
    private Long numberOfRefCode;
}