package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 02/22/2021 12:59 PM
 */
@Data
public class GroupTransferDetailDto {
    private Long id;
    private String reference;
    private Long parentId;
    private String organizationClientId;
    private String parentTrackingCode;
    private String fileName;
    private Long fileId;
    private String destinationAccount;
    private String accountNumber;
    private String accountId;
    private BigDecimal amount;
    private String clientCode;
    private String clientName;
    private String clientFamily;
    private String paymentId;
    private String description;
    private String type;
    private String status;
    private String coreTrackingCode;
    private String coreId;
    private Date insertTime;
    private Date actionTime;
    private Date endProcessTime;
    private String endProcessDescription;
    private String rejectedDealReference;
    private Date rejectedDealReferenceTime;
    private String fullName;
    private Boolean isCancelable;

}