package com.caspian.ebanking.pars.api.service.business.cheque.utils;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.utils.DateUtils;
import com.caspian.ebanking.pars.api.service.business.cheque.dto.*;
import com.caspian.moderngateway.core.coreservice.dto.*;
import io.jsonwebtoken.lang.Collections;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۳:۳۷ بعدازظهر
 */
@Component
@RequiredArgsConstructor
public class ChequeConvertUtils {

    private final ParsModelMapper mapper;

    public ActiveChequeBookResponseDto convertToActiveChequeResponseDto(ChChequeBooksResponseBean chequeBooksResponseBean) {
        ActiveChequeBookResponseDto responseDto = new ActiveChequeBookResponseDto();
        responseDto.setTotalRecord(chequeBooksResponseBean.getTotalRecord());
        if (!Collections.isEmpty(chequeBooksResponseBean.getChequeBookDtos())) {
            responseDto.setChequeBookDtos(mapper.mapList(chequeBooksResponseBean.getChequeBookDtos(), ChequeBookDto.class));
            return responseDto;
        } else
            return responseDto;
    }

    public ChChequeSearchRequestBean convertToChequeRequestBean(ChequeSheetDetailRequestDto requestDto) {
        ChChequeSearchRequestBean searchRequestBean = new ChChequeSearchRequestBean();
        searchRequestBean = mapper.map(requestDto, ChChequeSearchRequestBean.class);
        if (requestDto.getStatusList() != null && !requestDto.getStatusList().isEmpty())
            searchRequestBean.setStatuses(Arrays.asList(requestDto.getStatusList().split(","))
                    .stream().map(st -> ChChequeStatus.fromValue(st)).collect(Collectors.toList()));
        return searchRequestBean;
    }

    public ChequeSheetDetailResponseDto convertToChequeDetailResponseDto(ChChequeSheetsResponseBean chequeSheetsResponseBean) {
        ChequeSheetDetailResponseDto responseDto = new ChequeSheetDetailResponseDto();
        if (chequeSheetsResponseBean != null && !Collections.isEmpty(chequeSheetsResponseBean.getChequeSheetBeans()))
            responseDto.setDetailDtoList(mapper.mapList(chequeSheetsResponseBean.getChequeSheetBeans(), ChequeSheetDetailDto.class));
        return responseDto;
    }

    public ChBlockChequeRequestBean convertToBlockChequeRequestBean(BlockChequeRequestDto requestDto) {
        ChBlockChequeRequestBean requestBean = new ChBlockChequeRequestBean();
        requestBean.setBlockedReason(requestDto.getBlockedReason() != null && !requestDto.getBlockedReason().isEmpty() ?
                ChBlockedChequeReasonType.fromValue(requestDto.getBlockedReason()) : null);
        requestBean.setChequeNumbers(Arrays.asList(requestDto.getChequeNumbers().split(","))
                .stream().collect(Collectors.toList()));
        requestBean.setDepositNumber(requestDto.getDepositNumber());
        return requestBean;
    }

    public BlockChequeResponseDto convertToBlockChequeResponse(ChBlockChequeResponseBean blockChequeResponseBean) {
        BlockChequeResponseDto responseDto = new BlockChequeResponseDto();
        if (blockChequeResponseBean != null && !Collections.isEmpty(blockChequeResponseBean.getBlockingStatus())) {
            List<BlockChequeResponseItemDto> itemDtoList = new ArrayList<>();
            for (ChBlockingStatusBean statusBean : blockChequeResponseBean.getBlockingStatus()

            ) {
                BlockChequeResponseItemDto newItem = new BlockChequeResponseItemDto();
                newItem.setBlockingStatus(statusBean.getBlockingStatus().value());
                newItem.setChequeNumber(statusBean.getChequeNumber());
            }
            responseDto.setItemDtoList(itemDtoList);
        }
        return responseDto;
    }

    public ChSearchTransferChequeRequestBean convertToTransferredChequeRequestBean(TransferredChequeRequestDto requestDto) {
        ChSearchTransferChequeRequestBean requestBean = mapper.map(requestDto, ChSearchTransferChequeRequestBean.class);
        requestBean.setFromRegisterDate(DateUtils.getTimeValue(requestDto.getFromRegisterDate(), 0, 0, 0));
        requestBean.setFromPassDate(DateUtils.getTimeValue(requestDto.getFromPassDate(), 0, 0, 0));
        requestBean.setFromDueDate(DateUtils.getTimeValue(requestDto.getFromDueDate(), 0, 0, 0));
        requestBean.setToRegisterDate(DateUtils.getTimeValue(requestDto.getToRegisterDate(), 23, 59, 59));
        requestBean.setToPassDate(DateUtils.getTimeValue(requestDto.getToPassDate(), 23, 59, 59));
        requestBean.setToDueDate(DateUtils.getTimeValue(requestDto.getToDueDate(), 23, 59, 59));
        return requestBean;

    }

    public TransferredChequeResponseDto convertToTransferredChequeResponse(ChTransferChequesResponseBean transferChequesResponseBean) {
        TransferredChequeResponseDto responseDto = new TransferredChequeResponseDto();
        responseDto.setTotalRecord(transferChequesResponseBean.getTotalRecord());
        if (transferChequesResponseBean != null && !Collections.isEmpty(transferChequesResponseBean.getTransferChequesDtos()))
            responseDto.setItemDtoList(mapper.mapList(transferChequesResponseBean.getTransferChequesDtos(), TransferredChequeResponseItemDto.class));
        return responseDto;
    }
}