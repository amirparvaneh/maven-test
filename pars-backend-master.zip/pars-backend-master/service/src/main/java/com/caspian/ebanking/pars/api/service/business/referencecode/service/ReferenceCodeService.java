package com.caspian.ebanking.pars.api.service.business.referencecode.service;

import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.referencecode.dto.*;

import javax.servlet.http.HttpServletResponse;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 9:38 AM
 */
public interface ReferenceCodeService {

    GetOperationListResponseDto getOperationList();

    SettlementTitleResponseDto createSettlementTitle(SettlementTitleRequestDto requestDto);

    CreateReferenceCodeResponseDto generateReferenceCode(CreateReferenceCodeRequestDto requestDto);

    GetLiquidatorListResponseDto getLiquidatorList();

    GetLiquidatorHierarchyResponseDto getLiquidatorsHierarchy();

    GetSettlementTitleListResponseDto getSettlementTitleList(GetSettlementTitleListRequestDto requestDto);

    GetSettlementTitleHierarchyResponseDto getSettlementTitleHierarchy();

    ResultDto createLiquidator(CreateLiquidatorRequestDto requestDto);

    ResultDto updateLiquidator(CreateLiquidatorRequestDto requestDto);

    SettlementTitleResponseDto updateSettlementTitle(SettlementTitleRequestDto requestDto);

    ReferenceCodeReportResponseDto getReferenceCodeReport(ReferenceCodeReportRequestDto requestDto);

    ResultDto changeReferenceCodeStatus(ChangeReferenceCodeStatusRequestDto requestDto);

    DepositByReferenceCodeReportResponseDto depositByReferenceCodeReport(DepositByReferenceCodeReportRequestDto requestDto);

    GetBankInfoResponseDto getBankInfo();

    StatementWithReferenceCodeReportResponseDto getStatementWithReferenceCodeReport(StatementWithReferenceCodeReportRequestDto requestDto);

    void getReferenceCodeExcelReport(ReferenceCodeReportRequestDto requestDto, String fileType, HttpServletResponse response);

    GetReferenceCodeStatementByChequeResponseDto getReferenceCodeStatementByCheque(GetReferenceCodeStatementByChequeRequestDto requestDto);

    void getReferenceCodeStatementByChequePdfReport(GetReferenceCodeStatementByChequeRequestDto requestDto, HttpServletResponse response);

    void getStatementWithReferenceCodeExcelReport(StatementWithReferenceCodeReportRequestDto requestDto, String fileType, HttpServletResponse response);

    void getStatementWithReferenceCodePdfReport(StatementWithReferenceCodeReportRequestDto requestDto, HttpServletResponse response);
}
