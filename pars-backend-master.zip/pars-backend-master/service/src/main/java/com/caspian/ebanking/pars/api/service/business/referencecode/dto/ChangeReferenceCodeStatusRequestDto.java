package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۲/۰۲/۲۰۲۱ ۰۴:۳۵ بعدازظهر
 */
@Data
public class ChangeReferenceCodeStatusRequestDto {
    @ApiModelProperty(value = "کد عملیات")
    private String operationCode;
    @ApiModelProperty(value = "شناسه واریز")
    private String referenceCode;
    @ApiModelProperty(value = "نوع شناسه", allowableValues = " CONTINUES,TEMPORARY,MIXED")
    private String referenceCodeType;
}