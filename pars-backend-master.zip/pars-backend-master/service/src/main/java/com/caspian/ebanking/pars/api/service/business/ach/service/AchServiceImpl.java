package com.caspian.ebanking.pars.api.service.business.ach.service;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.service.business.account.dto.DestinationIbanDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetDestinationIbanResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetSourceAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.UserAccountDto;
import com.caspian.ebanking.pars.api.service.business.ach.dto.*;
import com.caspian.ebanking.pars.api.service.business.ach.utils.AchConverterUtils;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.*;
import com.caspian.moderngateway.core.message.*;
import com.caspian.moderngateway.core.message.valuablecustomer.GetVCUserAccountsMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.GetVCValidDestIbanByAccIdMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.dto.VCAccountDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Atousa Khanjani
 * @author Amir Tajik
 * @version 1.0
 * @since 1/4/2021 12:18 PM
 */
@Service
@RequiredArgsConstructor
public class AchServiceImpl extends BaseService implements AchService {

    private final AchConverterUtils achConverterUtils;
    private final CurrentUserService currentUserService;


    @Override
    public ResultDto cancelAchTransaction(CancelAchTransactionRequestDto requestDto) {
        ChAchTransactionKeysRequestBean requestBean = new ChAchTransactionKeysRequestBean();
        final CancelAchTransactionMsg.Inbound inbound = new CancelAchTransactionMsg.Inbound();
        requestBean.setReferenceId(requestDto.getReferenceId());
        requestBean.setKeys(mapper.mapList(requestDto.getCancelAchTransactionItemDtoList(), ChAchTransactionKeyRequestBean.class));
        inbound.setRequestBean(requestBean);

        try {
            channelManagerProvider.execute(inbound, CancelAchTransactionMsg.Outbound.class);
            return ResultDto.success();
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public AchTransactionReportResponseDto achTransactionReport(AchTransactionReportRequestDto requestDto) {
        AchTransactionReportMsg.Inbound inbound = new AchTransactionReportMsg.Inbound();
        inbound.setRequestBean(achConverterUtils.getAchTransactionReportCriteria(requestDto));

        try {
            final AchTransactionReportMsg.Outbound outbound = channelManagerProvider.execute(inbound, AchTransactionReportMsg.Outbound.class);
            return achConverterUtils.convertAchTransactionReportResponse(outbound.getResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public AchTransferReportResponseDto achTransferReport(AchTransferReportRequestDto requestDto) {
        AchTransferReportMsg.Inbound inbound = new AchTransferReportMsg.Inbound();
        inbound.setRequestBean(achConverterUtils.getAchTransferReportCriteria(requestDto));

        try {
            final AchTransferReportMsg.Outbound outbound = channelManagerProvider.execute(inbound, AchTransferReportMsg.Outbound.class);
            return achConverterUtils.convertAchTransferReportResponse(outbound.getResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public AchSingleTransferResponseDto achSingleTransfer(AchSingleTransferRequestDto requestDto) {
        AchNormalTransferMsg.Inbound inbound = new AchNormalTransferMsg.Inbound();
        ChAchNormalTransferRequestBean requestBean = achConverterUtils.convertAchSingleRequestDto(requestDto);
        requestBean.setCheckUniqueTrackingCode(Boolean.TRUE);
        requestBean.setUniqueTrackingCode(String.valueOf(System.currentTimeMillis()));
        inbound.setRequestBean(requestBean);
        AchNormalTransferMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, AchNormalTransferMsg.Outbound.class);
            return achConverterUtils.convertAchTransferResponse(result.getResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto cancelAchRequest(CancelAchRequestDto requestDto) {
        ChAchTransferKeyRequestBean requestBean = new ChAchTransferKeyRequestBean();
        final CancelAchTransferMsg.Inbound inbound = new CancelAchTransferMsg.Inbound();
        requestBean.setReferenceId(requestDto.getReferenceId());
        requestBean.setComment(requestDto.getComment());
        inbound.setRequestBean(requestBean);

        try {
            channelManagerProvider.execute(inbound, CancelAchTransferMsg.Outbound.class);
            return ResultDto.success();
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }
}