package com.caspian.ebanking.pars.api.service.business.cheque.service;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.service.business.cheque.dto.*;
import com.caspian.ebanking.pars.api.service.business.cheque.utils.ChequeConvertUtils;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.*;
import com.caspian.moderngateway.core.message.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۲:۵۳ بعدازظهر
 */
@Service
@RequiredArgsConstructor
public class ChequeServiceImpl extends BaseService implements ChequeService {
    private final ChequeConvertUtils convertUtils;

    @Override
    public ActiveChequeBookResponseDto getActiveChequeBook‌List(ActiveChequeBookRequestDto requestDto) {
        GetChequeBookListMsg.Outbound result;
        ChBaseSearchChequeBookRequestBean chequeBookCriteria = mapper.map(requestDto, ChBaseSearchChequeBookRequestBean.class);
        GetChequeBookListMsg.Inbound inbound = new GetChequeBookListMsg.Inbound();
        inbound.setBaseSearchChequeBookRequestBean(chequeBookCriteria);
        try {
            result = channelManagerProvider.execute(inbound, GetChequeBookListMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        ActiveChequeBookResponseDto responseDto = convertUtils.convertToActiveChequeResponseDto(result.getChequeBooksResponseBean());
        return responseDto;
    }

    @Override
    public ChequeSheetDetailResponseDto getChequeSheetDetails(ChequeSheetDetailRequestDto requestDto) {
        GetChequeMsg.Outbound result;
        ChChequeSearchRequestBean chequeNoteCriteria = convertUtils.convertToChequeRequestBean(requestDto);
        GetChequeMsg.Inbound inbound = new GetChequeMsg.Inbound();
        inbound.setChequeSearchRequestBean(chequeNoteCriteria);

        try {
            result = channelManagerProvider.execute(inbound, GetChequeMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }

        ChequeSheetDetailResponseDto responseDto = convertUtils.convertToChequeDetailResponseDto(result.getChequeSheetsResponseBean());
        return responseDto;
    }

    @Override
    public void updateCheque(ChequeRegisterRequestDto requestDto) {
        ChRegisterChequeRequestBean chequeRegisterCriteria = mapper.map(requestDto, ChRegisterChequeRequestBean.class);
        RegisterChequeMsg.Inbound inbound = new RegisterChequeMsg.Inbound();
        inbound.setRegisterChequeRequestBean(chequeRegisterCriteria);
        try {
            channelManagerProvider.execute(inbound, RegisterChequeMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public BlockChequeResponseDto temporaryBlockage(BlockChequeRequestDto requestDto) {
        ChBlockChequeRequestBean chequeBlockCriteria = convertUtils.convertToBlockChequeRequestBean(requestDto);
        BlockChequeMsg.Inbound inbound = new BlockChequeMsg.Inbound();
        inbound.setChequeRequestBean(chequeBlockCriteria);
        BlockChequeMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, BlockChequeMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        BlockChequeResponseDto responseDto = convertUtils.convertToBlockChequeResponse(result.getBlockChequeResponseBean());
        return responseDto;
    }

  /*  @Override
    public void registerCheque(ChequeRegisterRequestDto requestDto) {
        ChRegisterChequeRequestBean chequeRegisterCriteria = mapper.map(requestDto, ChRegisterChequeRequestBean.class);
        RegisterChequeMsg.Inbound inbound = new RegisterChequeMsg.Inbound();
        inbound.setRegisterChequeRequestBean(chequeRegisterCriteria);
        try {
            channelManagerProvider.execute(inbound, RegisterChequeMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }*/

    @Override
    public TransferredChequeResponseDto getTransferredChequeList(TransferredChequeRequestDto requestDto) {
        ChSearchTransferChequeRequestBean transferredChequeRequestBean = convertUtils.convertToTransferredChequeRequestBean(requestDto);
        GetTransferChequeListMsg.Outbound result;
        GetTransferChequeListMsg.Inbound inbound = new GetTransferChequeListMsg.Inbound();
        inbound.setSearchTransferChequeRequestBean(transferredChequeRequestBean);
        try {

            result = channelManagerProvider.execute(inbound, GetTransferChequeListMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        TransferredChequeResponseDto responseDto=convertUtils.convertToTransferredChequeResponse(result.getTransferChequesResponseBean());
        return responseDto;
    }
}