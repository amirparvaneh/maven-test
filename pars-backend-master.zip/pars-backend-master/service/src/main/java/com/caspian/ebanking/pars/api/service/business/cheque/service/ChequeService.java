package com.caspian.ebanking.pars.api.service.business.cheque.service;

import com.caspian.ebanking.pars.api.service.business.cheque.dto.*;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۲:۵۳ بعدازظهر
 */
public interface ChequeService {
    ActiveChequeBookResponseDto getActiveChequeBook‌List(ActiveChequeBookRequestDto requestDto);

    ChequeSheetDetailResponseDto getChequeSheetDetails(ChequeSheetDetailRequestDto requestDto);

    void updateCheque(ChequeRegisterRequestDto requestDto);

    BlockChequeResponseDto temporaryBlockage(BlockChequeRequestDto requestDto);

/*
    void registerCheque(ChequeRegisterRequestDto requestDto);
*/

    TransferredChequeResponseDto getTransferredChequeList(TransferredChequeRequestDto requestDto);
}
