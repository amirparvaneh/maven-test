package com.caspian.ebanking.pars.api.service.business.normaltransfer.dto;

import lombok.Data;

import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/5/2021 9:56 AM
 */
@Data
public class SingleNormalFundTransferResponseDto {
    private String serialNumber;
    private Date transactionDate;
}
