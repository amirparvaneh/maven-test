package com.caspian.ebanking.pars.api.service.business.account.dto;

import lombok.Data;

/**
 * @author atousa khanjani
 * @since 12/29/2020 07:34 PM
 */
@Data
public class GetDepositOwnerNameResponseDto {
    private String data;
    private String uniqueTrackingCode;
}
