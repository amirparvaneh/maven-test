package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 11:38 PM
 */
@Data
public class DepositByReferenceCodeReportResponseDto {
    private String referenceCodeCreator;
    private String depositTitle;
    private String liquidator;
    private Date createDate;
    private Date ExpireDate;
    private String accountNumber;
    private String phoneNumber;
    private String description;
    private String referenceCode;
    private String organization;
    private String referenceCodeType;
    private List<DetailOfReferenceCodeDto> chDetailOfReferenceCodeList;
    private List<DocumentsIssuedDto> documentIssues;
}
