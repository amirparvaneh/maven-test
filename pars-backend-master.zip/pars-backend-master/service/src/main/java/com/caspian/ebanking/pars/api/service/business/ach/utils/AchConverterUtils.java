package com.caspian.ebanking.pars.api.service.business.ach.utils;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.utils.CollectionUtils;
import com.caspian.ebanking.pars.api.base.utils.DateUtils;
import com.caspian.ebanking.pars.api.service.business.ach.dto.*;
import com.caspian.moderngateway.core.coreservice.dto.*;
import com.caspian.moderngateway.core.security.dto.ChSecondPasswordType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 1/4/2021 12:20 PM
 */
@Component
@RequiredArgsConstructor
public class AchConverterUtils {

    private final ParsModelMapper mapper;

    public ChAchTransactionSearchRequestBean getAchTransactionReportCriteria(AchTransactionReportRequestDto requestDto) {
        ChAchTransactionSearchRequestBean criteria = new ChAchTransactionSearchRequestBean();

        criteria.setSourceDepositIban(requestDto.getSourceDepositIban());
        criteria.setIbanNumber(requestDto.getDestinationIbanNumber());

        criteria.setTransferDescription(requestDto.getTransferDescription());
        criteria.setReferenceId(requestDto.getReferenceId());
        criteria.setTransactionId(requestDto.getTransactionId());
        criteria.setSourceDepositNumber(requestDto.getSourceDepositNumber());

        criteria.setFromRegisterDate(DateUtils.getFromDate(requestDto.getFromRegisterDate()));
        criteria.setToRegisterDate(DateUtils.getToDate(requestDto.getToRegisterDate()));

        criteria.setFromIssueDate(DateUtils.getFromDate(requestDto.getFromIssueDate()));
        criteria.setToIssueDate(DateUtils.getToDate(requestDto.getToIssueDate()));

        criteria.setFromTransactionAmount(requestDto.getFromTransactionAmount());
        criteria.setToTransactionAmount(requestDto.getToTransactionAmount());
        criteria.setIbanOwnerName(requestDto.getDestinationOwnerName());
        criteria.setFactorNumber(requestDto.getFactorNumber());
        criteria.setDescription(requestDto.getDescription());
        criteria.setOffset(0L);
        criteria.setLength(10000L);

        if (requestDto.getTransactionStatus()!=null &&!requestDto.getTransactionStatus().isEmpty()) {
            criteria.setIncludeTransactionStatus(Arrays.asList(requestDto.getTransactionStatus().split(","))
                    .stream().map(st -> ChTransactionStatus.fromValue(st)).collect(Collectors.toList()));
        }
        return criteria;
    }

    public AchTransactionReportResponseDto convertAchTransactionReportResponse(ChAchTransactionsResponseBean responseBean) {
        AchTransactionReportResponseDto responseDto = new AchTransactionReportResponseDto();
        if (CollectionUtils.isNullOrEmpty(responseBean.getTransactions()))
            return responseDto;

        //Set correct cancelable values to mapper
        responseBean.getTransactions().forEach((x) -> x.setCancelable(x.getStatus() != null && x.getStatus().value().equals(ChTransactionStatus.READY_TO_TRANSFER.value())));

        responseDto.setTotalRecord(responseBean.getTotalRecord());
        responseDto.setReportItemList(mapper.mapList(responseBean.getTransactions(), AchTransactionReportItemDto.class));

        return responseDto;
    }

    public ChAchTransferSearchRequestBean getAchTransferReportCriteria(AchTransferReportRequestDto requestDto) {
        ChAchTransferSearchRequestBean criteria = new ChAchTransferSearchRequestBean();

        criteria.setSourceDepositNumber(requestDto.getSourceDepositNumber());
        criteria.setReferenceId(requestDto.getReferenceId());
        criteria.setDestinationIbanNumber(requestDto.getDestinationIbanNumber());
        criteria.setDestinationOwnerName(requestDto.getDestinationOwnerName());
        if (requestDto.getStatusList() != null && !requestDto.getStatusList().isEmpty())
            criteria.setStatusSet(Arrays.asList(requestDto.getStatusList().split(","))
                    .stream().map(st -> ChAchTransferStatus.fromValue(st)).collect(Collectors.toList()));
        if (requestDto.getTransactionStatusList() != null && !requestDto.getTransactionStatusList().isEmpty())
            criteria.setTransactionStatusSet(Arrays.asList(requestDto.getTransactionStatusList().split(","))
                    .stream().map(st -> ChTransactionStatus.fromValue(st)).collect(Collectors.toList()));
        criteria.setTransferDescription(requestDto.getTransferDescription());
        criteria.setFromRegisterDate(DateUtils.getTimeValue(requestDto.getFromRegisterDate(), 0, 0, 0));
        criteria.setToRegisterDate(DateUtils.getTimeValue(requestDto.getToRegisterDate(), 23, 59, 59));
        criteria.setFromIssueDate(DateUtils.getTimeValue(requestDto.getFromIssueDate(), 0, 0, 0));
        criteria.setToIssueDate(DateUtils.getTimeValue(requestDto.getToIssueDate(), 23, 59, 59));
        criteria.setFromTransactionAmount(requestDto.getFromTransactionAmount());
        criteria.setToTransactionAmount(requestDto.getToTransactionAmount());
        criteria.setDescription(requestDto.getDescription());
        criteria.setOffset(requestDto.getOffset());
        criteria.setLength(requestDto.getLength());
        return criteria;
    }

    public AchTransferReportResponseDto convertAchTransferReportResponse(ChAchTransfersResponseBean responseBean) {
        AchTransferReportResponseDto responseDto = new AchTransferReportResponseDto();
        if (CollectionUtils.isNullOrEmpty(responseBean.getAchTransferBeans()))
            return responseDto;
        //Set correct cancelable values to mapper
        responseBean.getAchTransferBeans().forEach((x) -> x.setCancelable(x.getStatus() != null &&
                x.getStatus().value().equals(ChTransactionStatus.READY_TO_TRANSFER.value())));
        responseDto.setTotalRecord(responseBean.getTotalRecord());

        List<AchTransferReportItemDto> reportItemDtos = new ArrayList<>();
        for (ChAchTransferBean chAchTransferBean : responseBean.getAchTransferBeans()) {
            AchTransferReportItemDto itemDto = mapper.map(chAchTransferBean, AchTransferReportItemDto.class);
            List<AchTransferDetailsDto> transferDetailsDtos = new ArrayList<>();
            if (!CollectionUtils.isNullOrEmpty(chAchTransferBean.getTransactions())) {
                for (ChBriefAchTransactionBean briefAchTransactionBean : chAchTransferBean.getTransactions()
                ) {
                    transferDetailsDtos.add(mapper.map(briefAchTransactionBean, AchTransferDetailsDto.class));
                }
                itemDto.setDetailsDtoList(transferDetailsDtos);
                reportItemDtos.add(itemDto);
            }
        }
        responseDto.setReportItemList(reportItemDtos);

        return responseDto;
    }
    public ChAchNormalTransferRequestBean convertAchSingleRequestDto(AchSingleTransferRequestDto requestDto){
        ChAchNormalTransferRequestBean requestBean=null;
        if (requestDto!=null){
            requestBean=  mapper.map(requestDto, ChAchNormalTransferRequestBean.class);
            requestBean.setOwnerName(requestDto.getOwnerName().length() > 30 ? requestDto.getOwnerName().substring(0, 30) : requestDto.getOwnerName());
            requestBean.setChSecondPasswordType(ChSecondPasswordType.valueOf(requestDto.getPasswordType()));

        }
        return requestBean;
    }

    public  AchSingleTransferResponseDto convertAchTransferResponse (ChNormalAchTransferResultBean response) {
        AchSingleTransferResponseDto ach = mapper.map(response, AchSingleTransferResponseDto.class);
        ach.setTransactionDate(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(response.getTransactionDate()));
        return ach;
    }

}
