package com.caspian.ebanking.pars.api.service.business.normaltransfer.utils;

import com.caspian.ebanking.pars.api.base.utils.DateUtils;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.dto.*;
import com.caspian.moderngateway.core.coreservice.dto.*;
import com.caspian.moderngateway.core.security.dto.ChSecondPasswordType;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/5/2021 11:22 AM
 */
@Component
public class NormalTransferConvertUtils {

    public ChNormalTransferRequestBean getSingleNormalFundTransferRequestBean(SingleNormalFundTransferRequestDto requestDto) {
        ChNormalTransferRequestBean criteria = new ChNormalTransferRequestBean();

        criteria.setSourceDeposit(requestDto.getSourceAccount());
        criteria.setDestinationDeposit(requestDto.getDestinationAccount());
        criteria.setAmount(requestDto.getAmount());
        criteria.setSourceComment(requestDto.getSourceComment());
        criteria.setDestinationComment(requestDto.getDestinationComment());
        criteria.setReferenceNumber(requestDto.getReferenceNumber());
        criteria.setEmail(requestDto.getEmail());
        criteria.setChSecondPasswordType(ChSecondPasswordType.valueOf(requestDto.getPasswordType()));
        criteria.setSecondPassword(requestDto.getPassword());

        if (requestDto.isCheckTrackingCode()) {
            criteria.setUniqueTrackingCode(requestDto.getUniqueTrackingNumber());
            criteria.setCheckUniqueTrackingCode(true);
        }
        return criteria;
    }

    public ChSearchAutoTransferRequestBean getAutoNormalTransferReportCriteria(AutoNormalTransferReportRequestDto requestDto, long defaultMaxReportLength) {
        ChSearchAutoTransferRequestBean criteria = new ChSearchAutoTransferRequestBean();
        criteria.setMinAmount(requestDto.getMinAmount());
        criteria.setMaxAmount(requestDto.getMaxAmount());
        criteria.setStartDate(DateUtils.getTimeValue(requestDto.getFromDate(), 0, 0, 0));
        criteria.setEndDate(DateUtils.getTimeValue(requestDto.getToDate(), 23, 59, 59));
        criteria.setSourceDepositNumber((requestDto.getAccounts()));
        criteria.setSerial((requestDto.getSoNumber() != null && !requestDto.getSoNumber().trim().isEmpty()) ? requestDto.getSoNumber() : null);
        criteria.setOffset(0L);
        criteria.setLength(defaultMaxReportLength);
        return criteria;
    }


    public AutoNormalTransferReportResponseDto autoNormalTransferReportConverter(ChAutoTransferDetailsResponseBean response) {
        AutoNormalTransferReportResponseDto report = new AutoNormalTransferReportResponseDto();
        if (response.getAutoTransferDetailDtos() == null) {
            return report;
        }
        List<AutoNormalTransferResponseDetail> orderDetails = new ArrayList<AutoNormalTransferResponseDetail>();
        AutoNormalTransferResponseDetail order;
        report.setTotal(response.getTotalRecord().toString());
        for (ChAutoTransferDetailBean entry : response.getAutoTransferDetailDtos()) {
            order = new AutoNormalTransferResponseDetail();
            order.setSourceDepositNumber(entry.getSourceDepositNumber());
            order.setSourceDestinationNumber(entry.getSourceDestinationNumber());
            order.setSerial(entry.getSerial());
            order.setSuccessTransactionNumber(entry.getSuccessTransactionNumber());
            order.setNote(entry.getNote());
            order.setEndDate(entry.getEndDate());
            order.setStartDate(entry.getStartDate());
            order.setStatus(entry.getStatus().toString());
            order.setTransactionCount(entry.getTransactionCount());
            order.setDisable(entry.getDisable());
            order.setRegisterDate(entry.getRegisterDate());
            order.setUnProcessedCount(entry.getUnProcessedCount());
            order.setFailedCount(entry.getFailedCount());
            order.setSuspendedCount(entry.getSuspendedCount());
            order.setCancelable(entry.isCancelable());

            orderDetails.add(order);
        }
        report.setOrderDetails(orderDetails);
        return report;
    }

    public ChAutoTransferRequestBean convertAutoFundTransferRequest(AutoFundTransferRequestDto requestDto) {
        ChAutoTransferRequestBean requestBean = new ChAutoTransferRequestBean();

        requestBean.setSourceDepositNumber(requestDto.getSourceAccountNumber());
        requestBean.setDestinationDepositNumber(requestDto.getDestinationAccountNumber());
        requestBean.setAmount(requestDto.getTransferAmount());
        requestBean.setStartDate(requestDto.getFirstTransferDate());
        requestBean.setTermLength(requestDto.getPeriodDuration());
        requestBean.setTermType(requestDto.getPaymentPeriod() != null ? ChTermType.valueOf(requestDto.getPaymentPeriod()) : null);
        requestBean.setTransactionCount(requestDto.getPaymentPeriodCount());
        requestBean.setTryCountDay(null);
        requestBean.setChSecondPasswordType(ChSecondPasswordType.valueOf(requestDto.getPasswordType()));
        requestBean.setSecondPassword(requestDto.getTransferPassword() != null && !requestDto.getTransferPassword().trim().equals("") ? requestDto.getTransferPassword() : null);
        requestBean.setPaymentId(requestDto.getPaymentId() != null && !requestDto.getPaymentId().trim().equals("") ? requestDto.getPaymentId() : null);

        requestBean.setUniqueTrackingCode(requestDto.getUniqueTrackingCode());
        requestBean.setCheckUniqueTrackingCode(true);
        return requestBean;
    }

    public AutoFundTransferResponseDto convertAutoFundTransferResponse(ChAutoTransferResponseBean resultBean) {
        AutoFundTransferResponseDto auto = new AutoFundTransferResponseDto();
        auto.setSerialNumber(resultBean.getSerialNumber());
        auto.setTransactionDate(resultBean.getTransactionDate());
        return auto;
    }
}