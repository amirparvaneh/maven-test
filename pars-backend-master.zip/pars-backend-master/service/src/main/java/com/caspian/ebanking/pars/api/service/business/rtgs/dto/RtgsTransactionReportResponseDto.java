package com.caspian.ebanking.pars.api.service.business.rtgs.dto;

import lombok.Data;

import java.util.List;

@Data
public class RtgsTransactionReportResponseDto {
    private List<RtgsTransactionReportItemDto> statusDtos;
    private Long totalRecord;
}
