package com.caspian.ebanking.pars.api.service.business.user.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/6/2021 1:01 PM
 */
@Data
@ApiModel
public class ChangePasswordRequestDto {
    private String currentPassword;
    private String newPassword;

    @ApiModelProperty(value = "Password type", allowableValues = "LOGIN,TRANSFER_SECOND_PASS")
    private String passwordType;
}
