package com.caspian.ebanking.pars.api.service.business.account;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.utils.StringUtils;
import com.caspian.ebanking.pars.api.service.business.account.dto.*;
import com.caspian.ebanking.pars.api.service.business.account.exception.IbanInquiryByCBException;
import com.caspian.ebanking.pars.api.service.business.ach.dto.GetIbanFromAccountRequestDto;
import com.caspian.ebanking.pars.api.service.business.ach.dto.GetIbanFromAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.dto.GetDestinationAccountsResponseDto;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.dto.ValidDestinationAccountDto;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.channelmanagerserviceaggregator.dto.ChCBIbanEnquiryRequestBean;
import com.caspian.moderngateway.core.channelmanagerserviceaggregator.dto.ChCBPaymentIDCheckRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.*;
import com.caspian.moderngateway.core.domainmodel.dto.deposit.ChDepositDetail;
import com.caspian.moderngateway.core.message.*;
import com.caspian.moderngateway.core.message.valuablecustomer.GetVCUserAccountsMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.GetVCValidDestAccountByAccIdMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.GetVCValidDestIbanByAccIdMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.dto.VCAccountDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Amir Tajik
 * @author atousa khanjani
 * @version 1.0
 * @since 12/28/2020 12:35 PM
 */
@Service
@RequiredArgsConstructor
public class AccountServiceImpl extends BaseService implements AccountService {

    private final CurrentUserService currentUserService;
    private final AccountConverterUtils accountConverterUtils;

    @Override
    public GetUserAccountsResponseDto getUserAccounts(String serviceCode) {
        GetVCUserAccountsMsg.Inbound inbound = new GetVCUserAccountsMsg.Inbound();
        inbound.setUserName(currentUserService.getUsername());
        inbound.setOrganizationId(String.valueOf(currentUserService.getCurrentOrganizationId()));

        try {
            GetVCUserAccountsMsg.Outbound outbound = channelManagerProvider.execute(inbound, GetVCUserAccountsMsg.Outbound.class);
            final List<UserAccountDto> userAccountsList = mapper.mapList(outbound.getAccounts(), UserAccountDto.class);

            /* Core inquiry for accounts to fetch core balance data */
            final List<String> inquiryList = userAccountsList.stream().map(UserAccountDto::getAccountNumber).collect(Collectors.toList());

            final GetDepositsMsg.Inbound getDepositInbound = new GetDepositsMsg.Inbound();
            final ChDepositSearchRequestBean depositSearchRequestBean = new ChDepositSearchRequestBean();
            depositSearchRequestBean.setDepositNumbers(inquiryList);

            depositSearchRequestBean.setServiceCode(accountConverterUtils.getServiceCode(serviceCode));

            getDepositInbound.setChDepositSearchRequestBean(depositSearchRequestBean);

            GetDepositsMsg.Outbound getDepositResult = channelManagerProvider.execute(getDepositInbound, GetDepositsMsg.Outbound.class);
            final List<UserAccountDto> vcResultFinalAccounts = new ArrayList<>();
            for (ChDepositBean coreAccount : getDepositResult.getChDepositResponseBean().getDepositBeans()) {
                for (UserAccountDto vcAccountDTO : userAccountsList) {
                    if (coreAccount.getDepositNumber().equalsIgnoreCase(vcAccountDTO.getAccountNumber())) {
                        vcAccountDTO.setBalance(coreAccount.getBalance());
                        vcAccountDTO.setAvailableBalance(coreAccount.getAvailableBalance());
                        vcAccountDTO.setBlockedAmount(coreAccount.getBlockedAmount());
                        vcResultFinalAccounts.add(vcAccountDTO);
                    }
                }
            }
            return new GetUserAccountsResponseDto(vcResultFinalAccounts);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public StatementResponseDto getNormalStatement(StatementRequestDto requestDto) {
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DAY_OF_YEAR, -100);
        requestDto.setFromDate(c.getTime());
        c.setTime(new Date());
        c.add(Calendar.DAY_OF_YEAR, -10);
        requestDto.setToDate(c.getTime());
        final ChStatementSearchRequestBean criteria = accountConverterUtils.convertNormalStatementRequestDto(requestDto);
        GetStatementMsg.Inbound inbound = new GetStatementMsg.Inbound();
        inbound.setChStatementSearchRequestBean(criteria);
        GetStatementMsg.Outbound result;

        try {
            result = channelManagerProvider.execute(inbound, GetStatementMsg.Outbound.class);

            StatementResponseDto responseDto = new StatementResponseDto();
            responseDto.setStatementBeans(mapper.mapList(result.getStatementResponseBean().getStatementBeans(), StatementRowDto.class));
            responseDto.setTotalRecords(result.getStatementResponseBean().getTotalRecord());

            return responseDto;
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public GetIbanFromAccountResponseDto getIbanFromUserAccount(GetIbanFromAccountRequestDto requestDto) {
        ConvertDepositNumberToIbanMsg.Inbound inbound = new ConvertDepositNumberToIbanMsg.Inbound();
        ChDepositNumberToIbanRequestBean chDepositNumberToIbanRequestBean = new ChDepositNumberToIbanRequestBean();
        chDepositNumberToIbanRequestBean.setDepositNumber(requestDto.getDepositNumber());
        inbound.setRequestBean(chDepositNumberToIbanRequestBean);
        ConvertDepositNumberToIbanMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, ConvertDepositNumberToIbanMsg.Outbound.class);

        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        GetIbanFromAccountResponseDto responseDto = new GetIbanFromAccountResponseDto();
        responseDto.setIban(result.getIban());
        return responseDto;

    }


    @Override
    public GetSourceAccountResponseDto getSourceAccount(String serviceCode, String accountType) {
        GetVCUserAccountsMsg.Inbound inbound = new GetVCUserAccountsMsg.Inbound();
        inbound.setUserName(currentUserService.getUsername());
        inbound.setOrganizationId(String.valueOf(currentUserService.getCurrentOrganizationId()));
        inbound.setRefreshAllAccountInformation(Boolean.FALSE);
        inbound.setRegisterWithrawRequest(Boolean.FALSE);
        List<VCAccountDTO> finalAccounts;

        try {
            final GetVCUserAccountsMsg.Outbound result = channelManagerProvider.execute(inbound,
                    GetVCUserAccountsMsg.Outbound.class);

            finalAccounts = fillFinalAccounts(serviceCode, accountType, result.getAccounts());

        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        GetSourceAccountResponseDto responseDto = new GetSourceAccountResponseDto();
        final List<UserAccountDto> userAccountsList = mapper.mapList(finalAccounts, UserAccountDto.class);
        responseDto.setUserAccountDtos(userAccountsList);
        return responseDto;

    }

    private List<VCAccountDTO> fillFinalAccounts(String serviceName, String accountType, List<VCAccountDTO> result) throws ChannelManagerException {
        final List<VCAccountDTO> vcResultFinalAccounts = new ArrayList<>();
        final List<String> inquiryList = new ArrayList<>();
        result.forEach(s -> inquiryList.add(s.getAccountNumber()));

        final GetDepositsMsg.Inbound getDepositInbound = new GetDepositsMsg.Inbound();
        ChDepositSearchRequestBean depositSearchRequestBean = new ChDepositSearchRequestBean();
        depositSearchRequestBean.setServiceCode(accountConverterUtils.getServiceCode(serviceName));
        depositSearchRequestBean.setDepositNumbers(inquiryList);
        depositSearchRequestBean.setOffset(0L);
        depositSearchRequestBean.setLength(1000L);
        getDepositInbound.setChDepositSearchRequestBean(depositSearchRequestBean);
        GetDepositsMsg.Outbound getDepositResult = channelManagerProvider.execute(getDepositInbound, GetDepositsMsg.Outbound.class);
        final List<ChDepositBean> chDepositBeanList = getDepositResult.getChDepositResponseBean().getDepositBeans();
        final List<ChDepositBean> inquiryFinalList = new ArrayList<>();

        for (ChDepositBean bean : chDepositBeanList) {
            if (accountType == null || accountType.isEmpty()) {
                if (bean.getCurrency().equalsIgnoreCase("IRR") &&
                        bean.getDepositStatus().equals(ChDepositStatus.OPEN) &&
                        (bean.getGroup().equals(ChDepositGroupType.JARI_ACCOUNT) ||
                                bean.getGroup().equals(ChDepositGroupType.PASANDAZ) ||
                                bean.getGroup().equals(ChDepositGroupType.SHORT_ACCOUNT))) {

                    inquiryFinalList.add(bean);
                }
            } else {
                if (bean.getCurrency().equalsIgnoreCase("IRR") &&
                        bean.getDepositStatus().equals(ChDepositStatus.OPEN) &&
                        bean.getGroup().equals(ChDepositGroupType.fromValue(accountType))) {
                    inquiryFinalList.add(bean);
                }
            }
        }
        for (ChDepositBean coreAccount : inquiryFinalList) {
            for (VCAccountDTO vcAccountDTO : result) {
                if (coreAccount.getDepositNumber().equalsIgnoreCase(vcAccountDTO.getAccountNumber())) {
                    vcAccountDTO.setBlockedAmount(coreAccount.getBlockedAmount());
                    vcAccountDTO.setAvailableBalance(coreAccount.getAvailableBalance());
                    vcAccountDTO.setBalance(coreAccount.getBalance());
                    vcResultFinalAccounts.add(vcAccountDTO);
                }
            }
        }
        return vcResultFinalAccounts;
    }

    @Override
    public GetDestinationIbanResponseDto getDestinationIban(Long accountId) {
        GetVCValidDestIbanByAccIdMsg.Inbound inbound = new GetVCValidDestIbanByAccIdMsg.Inbound();
        inbound.setAccountId(accountId);
        GetVCValidDestIbanByAccIdMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, GetVCValidDestIbanByAccIdMsg.Outbound.class);

        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        GetDestinationIbanResponseDto responseDto = new GetDestinationIbanResponseDto();
        responseDto.setDestinationIbanDtos(mapper.mapList(result.getDestinationIbanDtos(), DestinationIbanDto.class));
        return responseDto;
    }

    @Override
    public IbanInquiryByCentralBankResponseDto ibanInquiryByCentralBank(String iban, BigDecimal amount, String paymentCode) {
        IbanEnquiryByCBMsg.Inbound inbound = new IbanEnquiryByCBMsg.Inbound();
        ChCBIbanEnquiryRequestBean chCBIbanEnquiryRequestBean = new ChCBIbanEnquiryRequestBean();
        chCBIbanEnquiryRequestBean.setIban(iban);
        inbound.setRequestBean(chCBIbanEnquiryRequestBean);
        IbanEnquiryByCBMsg.Outbound result;
        IbanInquiryByCentralBankResponseDto responseDto;
        try {
            result = channelManagerProvider.execute(inbound, IbanEnquiryByCBMsg.Outbound.class);
            if (result.getResponseBean().getErrorCode().equals("00")) {
                if (result.getResponseBean().getRequiredPaymentCode()) {
                    PaymentIDCheckByCBMsg.Inbound inboundCBPaymentCheck = new PaymentIDCheckByCBMsg.Inbound();
                    ChCBPaymentIDCheckRequestBean chCBPaymentIDCheckRequestBean = new ChCBPaymentIDCheckRequestBean();
                    chCBPaymentIDCheckRequestBean.setIban(iban);
                    chCBPaymentIDCheckRequestBean.setPaymentID(paymentCode);
                    chCBPaymentIDCheckRequestBean.setAmount(amount);
                    inboundCBPaymentCheck.setRequestBean(chCBPaymentIDCheckRequestBean);
                    PaymentIDCheckByCBMsg.Outbound outboundCBPaymentCheck = channelManagerProvider.execute(inboundCBPaymentCheck, PaymentIDCheckByCBMsg.Outbound.class);
                    responseDto = accountConverterUtils.cbPaymentIDCheckConverter(outboundCBPaymentCheck.getResponseBean());
                } else {
                    responseDto = accountConverterUtils.IbanEnquiryByCBConverter(result.getResponseBean());
                }
                if (responseDto == null)
                    throw new GatewayException(new IbanInquiryByCBException("ChannelManagerException,ResponseIsNull"));
            } else {
                throw new GatewayException(new IbanInquiryByCBException("IbansNotValidExceptionForACH"));
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        return responseDto;
    }

    @Override
    public GetDestinationAccountsResponseDto getDestinationAccounts(Long accountId) {
        GetVCValidDestAccountByAccIdMsg.Inbound inbound = new GetVCValidDestAccountByAccIdMsg.Inbound();
        inbound.setAccountId(accountId);

        try {
            GetVCValidDestAccountByAccIdMsg.Outbound result = channelManagerProvider.execute(inbound, GetVCValidDestAccountByAccIdMsg.Outbound.class);
            GetDestinationAccountsResponseDto responseDto = new GetDestinationAccountsResponseDto();
            responseDto.setDestinationAccounts(mapper.mapList(result.getDestinationAccountDtoList(), ValidDestinationAccountDto.class));
            return responseDto;
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto setCustomerDepositDetail(SetCustomerDepositDetailRequestDto requestDto) {
        ChDepositDetail requestBean = accountConverterUtils.convertCustomerDepositDetails(requestDto);
        SetCustomerDepositDescMsg.Inbound inbound = new SetCustomerDepositDescMsg.Inbound();
        inbound.setRequestBean(requestBean);

        try {
            SetCustomerDepositDescMsg.Outbound result = channelManagerProvider.execute(inbound, SetCustomerDepositDescMsg.Outbound.class);
            return ResultDto.success(result.getId());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    private static String getRandomPeriodType() {
        if (new Random().nextBoolean())
            return "WEEKLY";
        if (new Random().nextBoolean())
            return "MONTHLY";
        return "YEARLY";
    }

    @Override
    public SummaryStatementResponseDto getSummaryStatement(SummaryStatementRequestDto requestDto) {

        if (StringUtils.isNullOrEmpty(requestDto.getAccountNumber()) || StringUtils.isNullOrEmpty(requestDto.getPeriodType()))
            throw new GatewayException();

        SummaryStatementResponseDto responseDto = new SummaryStatementResponseDto();
        Random random = new Random();
        //TODO MOCK
        String randomPeriodType = getRandomPeriodType();
        List<SummaryStatementItemDto> items = new ArrayList<>();

        for (int i = 0; i < random.nextInt(5999) + 1; i++) {
            boolean isCredit = random.nextBoolean();
            int amount = random.nextInt(999999999);
            if (!isCredit) amount *= -1;

            SummaryStatementItemDto item = new SummaryStatementItemDto();
            item.setAmount(new BigDecimal(amount));

            Date fromDate = requestDto.getFromDate() == null ? new Date() : requestDto.getFromDate();
            Calendar c = Calendar.getInstance();
            c.setTime(fromDate);
            c.add(Calendar.DAY_OF_YEAR, random.nextInt(100) + 1);
            item.setFromDate(c.getTime());

            item.setToDate(requestDto.getToDate() == null ? new Date() : requestDto.getToDate());
            item.setPeriodType(StringUtils.isNullOrEmpty(requestDto.getPeriodType()) ? randomPeriodType : requestDto.getPeriodType());
            item.setTransactionType(isCredit ? "CREDIT" : "DEBIT");
            items.add(item);
        }
        responseDto.setItems(items);
        return responseDto;
    }

    @Override
    public GetDepositOwnerNameResponseDto getDepositOwnerName(String accountNumber) {
        ChDepositOwnerRequestBean requestBean = new ChDepositOwnerRequestBean();
        requestBean.setDepositNumber(accountNumber);
        GetDepositOwnerNameMsg.Outbound result;
        GetDepositOwnerNameMsg.Inbound inbound = new GetDepositOwnerNameMsg.Inbound();
        GetDepositOwnerNameResponseDto responseDto = new GetDepositOwnerNameResponseDto();
        inbound.setDepositOwnerRequestBean(requestBean);
        try {
            result = channelManagerProvider.execute(inbound, GetDepositOwnerNameMsg.Outbound.class);
            responseDto.setData(result.getOwnerName());
            responseDto.setUniqueTrackingCode(String.valueOf(System.currentTimeMillis()));

        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        return responseDto;

    }
}


