package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۰۳:۱۳ بعدازظهر
 */
@Data
public class GuarantyReportItemDto {
    @ApiModelProperty(value = "شماره ضمانتنامه")
    private String guarantyNumber;

    @ApiModelProperty(value = "تاریخ گشایش")
    private Date openingDate;

    @ApiModelProperty(value = "مبلغ گشایش")
    private BigDecimal openingAmount;

    @ApiModelProperty(value = "مبلغ ضمانتنامه")
    private BigDecimal guarantyAmount;

    @ApiModelProperty(value = "نوع ارز", allowableValues = "IRR,USD")
    private String currencyType;
}