package com.caspian.ebanking.pars.api.service.business.file.dto;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

import static java.lang.String.format;

public class ClientFileDto {
    public enum Extension {
        xls("xls"),
        xlsx("xlsx"),
        pdf("pdf");

        private final String value;
        private static final Map<String, Extension> lookup;

        static {
            lookup = new HashMap<>();
            for (Extension eventType : EnumSet.allOf(Extension.class)) {
                lookup.put(eventType.value(), eventType);
            }
        }

        Extension(String value) {
            this.value = value;
        }

        public String value() {
            return value;
        }

        public static Extension convert(final String value) {
            if (value == null) {
                throw new IllegalArgumentException(format("'%s' isn't a valid value", (Object[]) null));
            }
            return lookup.get(value);
        }

    }

    private String fileName;
    private String filePath;
    private Extension extension;

    public ClientFileDto(String filePath, String fileName, Extension fileExtension) {
        this.filePath = filePath;
        this.fileName = fileName;
        this.extension = fileExtension;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public Extension getExtension() {
        return extension;
    }

    public void setExtension(Extension extension) {
        this.extension = extension;
    }
}
