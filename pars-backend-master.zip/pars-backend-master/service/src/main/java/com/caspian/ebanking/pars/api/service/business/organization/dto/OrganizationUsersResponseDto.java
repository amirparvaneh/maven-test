package com.caspian.ebanking.pars.api.service.business.organization.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۹/۰۱/۲۰۲۱ ۰۴:۱۱ قبل‌ازظهر
 */
@Data
public class OrganizationUsersResponseDto {
    private List<OrganizationUserDto> userDtoList;
}