package com.caspian.ebanking.pars.api.service.business.offlineStatement.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class OfflineStatementRequestDto {
    @ApiModelProperty(value = "شماره حساب")
    private String depositNumber;
    @ApiModelProperty(value = "شرح سند")
    private String description;
    private Date fromDate;
    private String order;
    private Date toDate;
    private BigDecimal fromAmount;
    private BigDecimal toAmount;
    private String fromDateTime;
    private String toDateTime;
    @ApiModelProperty(value = "شماره چک")
    private String chequeNumber;
    @ApiModelProperty(value ="نوع تراکنش",allowableValues = "CREDIT,DEBIT,BOTH")
    private String actionType;
}