package com.caspian.ebanking.pars.api.service.business.user;

import com.caspian.ebanking.pars.api.base.security.dto.LoginRequest;
import com.caspian.ebanking.pars.api.base.security.dto.LoginResponse;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.user.dto.ChangePasswordRequestDto;
import com.caspian.ebanking.pars.api.service.business.user.dto.ChangeUsernameRequestDto;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 2:32 PM
 */
public interface UserService {
    LoginResponse login(LoginRequest requestDto, HttpServletRequest headers);

    ResultDto changeUsername(ChangeUsernameRequestDto requestDto);

    ResultDto logout();

    ResultDto changePassword(ChangePasswordRequestDto requestDto);
}
