package com.caspian.ebanking.pars.api.service.business.cartable.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۶/۰۱/۲۰۲۱ ۰۲:۳۱ قبل‌ازظهر
 */
@Getter
public enum RequestStatus {
    REGISTERED ("REGISTERED", 'R'),
    CONFORMED("CONFORMED",'C'),
    REJECTED ("REJECTED",'J'),
    CANCELED("CANCELED",'D'),
    UBSUCCEEDED("UBSUCCEEDED",'U'),
    SUCCEEDED ("SUCCEEDED",'S'),
    EXPIRED ("EXPIRED",'X');


    String name;
    Character ch;

    RequestStatus(String name, Character ch) {
        this.name = name;
        this.ch = ch;
    }

    public static Character getCharacterOf(String name) {
        Optional<Character> ch = Arrays.stream(RequestStatus.values()).filter(item -> item.name.equals(name)).map(i -> i.getCh()).findFirst();
        if (ch.isPresent())
            return ch.get();
        else
            return null;

    }

    public static String getNameOf(Character ch){
        Optional<String> name = Arrays.stream(RequestStatus.values()).filter(item -> item.ch.equals(ch)).map(i -> i.getName()).findFirst();
        if (name.isPresent())
            return name.get();
        else
            return null;
    }
}
