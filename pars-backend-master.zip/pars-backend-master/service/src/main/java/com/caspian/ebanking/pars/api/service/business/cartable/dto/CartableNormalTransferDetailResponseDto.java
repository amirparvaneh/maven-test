package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import com.caspian.ebanking.pars.api.service.business.cartable.enums.Priority;
import com.caspian.ebanking.pars.api.service.business.cartable.enums.RequestStatus;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۸/۰۱/۲۰۲۱ ۱۰:۵۱ بعدازظهر
 */
@Data
public class CartableNormalTransferDetailResponseDto {
    private Long id;
    private String requestCode;
    private Date requestDate;
    private Date expireDate;
    private String description;
    private Character priority;
    private String accountNumber;
    private Character status;
    private CartableTransferDetailsDto transferDetailsDto;
    private String withdrawConditionCode;
    private List<CartableTransferApprovalDto> transferApprovalDtos;
    private Long version;
    private Date updateSysDate;

    public String getPriorityName() {
        return priority != null ? Priority.getNameOf(priority) : "";
    }

    public String getStatusName() {
        return status != null ? RequestStatus.getNameOf(status) : "";
    }
}