package com.caspian.ebanking.pars.api.service.business.organization.dto;

import lombok.Data;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۹/۰۱/۲۰۲۱ ۰۴:۱۳ قبل‌ازظهر
 */
@Data
public class OrganizationUserDto {
    private Long id;
    private String channelCode;
    private Long roleId;
    private String username;
    private String chargeAccount;
    private Long customerNumber;
    private Long version;

}