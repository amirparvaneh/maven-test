package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import lombok.Data;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 11:38 PM
 */
@Data
public class DetailOfReferenceCodeDto {
    private String amount;
    private String settleTitleCode;
    private String settleTitle;
    private String numberOfRefCode;
    private String operationTitle;
}
