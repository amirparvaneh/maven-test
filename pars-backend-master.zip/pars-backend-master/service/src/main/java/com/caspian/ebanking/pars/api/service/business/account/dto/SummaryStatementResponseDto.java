package com.caspian.ebanking.pars.api.service.business.account.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

@Data
@ApiModel
public class SummaryStatementResponseDto {
    private List<SummaryStatementItemDto> items;
}
