package com.caspian.ebanking.pars.api.service.business.ach.dto;

import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/30/2020 11:27 PM
 */
@Data
public class CancelAchTransactionItemDto {
    private String transactionId, comment;
}
