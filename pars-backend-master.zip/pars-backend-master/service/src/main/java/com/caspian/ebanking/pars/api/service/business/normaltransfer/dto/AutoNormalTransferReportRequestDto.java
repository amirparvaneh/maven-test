package com.caspian.ebanking.pars.api.service.business.normaltransfer.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author atousa khanjani
 * @since 12/29/2020 07:34 PM
 */
@Data
public class AutoNormalTransferReportRequestDto {
    @ApiModelProperty(value = "شماره سپرده")
    private String accounts;
    @ApiModelProperty(value = "از تاریخ")
    private Date fromDate;
    @ApiModelProperty(value = "تا تاریخ")
    private Date toDate;
    @ApiModelProperty(value = "حداقل مبلغ")
    private BigDecimal minAmount;
    @ApiModelProperty(value = "حداکثر مبلغ")
    private BigDecimal maxAmount;
    @ApiModelProperty(value = "شناسه دستور")
    private String soNumber;
}