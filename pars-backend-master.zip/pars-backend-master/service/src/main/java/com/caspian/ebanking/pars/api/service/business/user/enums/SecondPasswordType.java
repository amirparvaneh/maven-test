package com.caspian.ebanking.pars.api.service.business.user.enums;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/6/2021 1:17 PM
 */
public enum SecondPasswordType {
    LOGIN, TRANSFER_SECOND_PASS
}
