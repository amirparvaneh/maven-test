package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import lombok.Data;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 02/22/2021 12:59 PM
 */
@Data
public class CancelGroupTransferDto {
    private Long groupTransferId;
}
