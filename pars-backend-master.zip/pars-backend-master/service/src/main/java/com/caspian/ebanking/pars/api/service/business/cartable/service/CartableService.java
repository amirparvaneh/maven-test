package com.caspian.ebanking.pars.api.service.business.cartable.service;


import com.caspian.ebanking.pars.api.service.business.account.dto.GetWithdrawConditionsResponseDto;
import com.caspian.ebanking.pars.api.service.business.cartable.dto.*;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @author Atousa Khanjani
 * @version 1.0
 * @since ۱۳/۰۱/۲۰۲۱ ۰۳:۱۵ قبل‌ازظهر
 */

public interface CartableService {
    CartableResponseDto getCartableReuquests(CartableRequestDto requestDto);

    CartableNormalTransferDetailResponseDto getNormalTransferDetail(String requestCode);

    CartableFileGroupTransferDetailResponseDto getFileGroupTransferDetail(String requestCode);

    CartableNormalBatchTransferDetailResponseDto getNormalBatchTransferDetail(String requestCode);

    CartableAchBatchTransferDetailResponseDto getAchBatchTransferDetail(String requestCode);

    CartableAchNormalTransferDetailResponseDto getAchNormalTransferDetail(String requestCode);

    ResultDto approveCartableRequest(ApproveCartableRequestDto requestDto);

    SingleCartableAchOrderTransferResponseDto singleCartableAchOrderTransfer(SingleCartableAchOrderTransferRequestDto requestDto);

    BatchCartableAchOrderTransferResponseDto batchCartableAchOrderTransfer(BatchCartableAchOrderTransferRequestDto requestDto);

    GetWithdrawConditionsResponseDto getWithdrawConditions(String accountNumber, BigDecimal amount, Date expireDate);

    ResultDto rejectCartableRequest(CartableRequestCodeDto requestDto);

    ResultDto doCartableRequest(DoCartableRequestDto requestDto);

    ResultDto cancelCartableRequest(CartableRequestCodeDto requestDto);

    SingleCartableNormalFundTransferResponseDto singleCartableNormalFundTransfer(SingleCartableNormalFundTransferRequestDto requestDto);

    BatchCartableNormalFundTransferResponseDto batchCartableNormalFundTransfer(BatchCartableNormalFundTransferRequestDto requestDto);

    SingleCartableRtgsOrderTransferResponseDto singleCartableRtgsOrderTransfer(SingleCartableRtgsOrderTransferRequestDto requestDto);



}
