package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class PichakChequeInquiryResponseDto {
    private String sayyadId;
    private String serialNo;
    private String fromIban;
    private BigDecimal amount;
    private Date dueDate;
    private String description;
    private String bankCode;
    private String branchCode;
    private String chequeType;
    private String chequeMedia;
    private String chequeStatus;
    private String guaranteeStatus;
    private String blockStatus;
    private Boolean locked;
    private List<PichakChequePersonDto> chequeOwners;

    private String errorCode;
    private String errorDescription;


}
