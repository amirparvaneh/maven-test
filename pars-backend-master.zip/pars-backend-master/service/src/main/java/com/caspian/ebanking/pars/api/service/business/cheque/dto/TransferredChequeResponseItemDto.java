package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۷/۰۲/۲۰۲۱ ۰۳:۰۶ بعدازظهر
 */
@Data
public class TransferredChequeResponseItemDto {
    @ApiModelProperty(value = "مبلغ چک")
    private BigDecimal amount;
    private String depositNumber;
    @ApiModelProperty(value = "بانک چک")
    private String deviseeBank;
    private String deviseeBankCode;
    private String deviseeDepositNumber;
    @ApiModelProperty(value = "تاریخ وصول")
    private Date dueDate;
    @ApiModelProperty(value = "شماره چک")
    private String number;
    @ApiModelProperty(value = "تاریخ واگذاری")
    private Date passDate;
    @ApiModelProperty(value = "تاریخ چک")
    private Date registerDate;
    @ApiModelProperty(value = "وضعیت چک")
    private String status;
    private String type;
    @ApiModelProperty(value = "شعبه عامل")
    private Integer transferredBranchCode;
}