package com.caspian.ebanking.pars.api.service.business.cartable.service;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetWithdrawConditionsResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.WithdrawConditionDto;
import com.caspian.ebanking.pars.api.service.business.account.exception.DepartmentAccountException;
import com.caspian.ebanking.pars.api.service.business.account.exception.UserInvalidWithdrawConditionException;
import com.caspian.ebanking.pars.api.service.business.cartable.dto.*;
import com.caspian.ebanking.pars.api.service.business.cartable.utils.CartableConverterUtils;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.ChWithdrawConditionsRequestBean;
import com.caspian.moderngateway.core.message.GetWithdrawConditionsMsg;
import com.caspian.moderngateway.core.message.cartable.*;
import com.caspian.moderngateway.core.message.cartable.ach.GetCartableAchOrderRequestDetailMsg;
import com.caspian.moderngateway.core.message.cartable.ach.GetCartableBatchAchOrderRequestDetailMsg;
import com.caspian.moderngateway.core.message.cartable.ach.RegisterCartableAchOrderRequestMsg;
import com.caspian.moderngateway.core.message.cartable.ach.RegisterCartableBatchAchOrderRequestMsg;
import com.caspian.moderngateway.core.message.cartable.groupfiletransfer.GetCartableGroupFileTransferDetailMsg;
import com.caspian.moderngateway.core.message.cartable.transfer.GetCartableBatchTransferRequestDetailMsg;
import com.caspian.moderngateway.core.message.cartable.transfer.GetCartableTransferRequestDetailMsg;
import com.caspian.moderngateway.core.message.cartable.transfer.RegisterCartableBatchTransferRequestMsg;
import com.caspian.moderngateway.core.message.cartable.transfer.RegisterCartableTransferRequestMsg;
import com.caspian.moderngateway.core.message.dto.groupfiletransfer.CartableRequestCodeDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @author Atousa Khanjani
 * @version 1.0
 * @since ۱۳/۰۱/۲۰۲۱ ۰۳:۱۵ قبل‌ازظهر
 */
@Service
@RequiredArgsConstructor
public class CartableServiceImpl extends BaseService implements CartableService {

    private final CartableConverterUtils converterUtils;
    private final ParsModelMapper mapper;

    @Override
    public CartableResponseDto getCartableReuquests(CartableRequestDto requestDto) {
        GetCartableRequestsMsg.Inbound inbound = new GetCartableRequestsMsg.Inbound();
        inbound.setRequestSearchDto(converterUtils.convertToCartableSearchDto(requestDto));
        GetCartableRequestsMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, GetCartableRequestsMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        CartableResponseDto cartableResponseDto = new CartableResponseDto();
        cartableResponseDto.setDtoList(mapper.mapList(result.getCartableRequestDtoList(), CartableResponseItemDto.class));
        return cartableResponseDto;
    }

    @Override
    public CartableNormalTransferDetailResponseDto getNormalTransferDetail(String requestCode) {
        GetCartableTransferRequestDetailMsg.Inbound inbound = new GetCartableTransferRequestDetailMsg.Inbound();
        inbound.setCartableRequestCode(requestCode);

        GetCartableTransferRequestDetailMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetCartableTransferRequestDetailMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }

        CartableNormalTransferDetailResponseDto responseDto = converterUtils.convertToCartableTransferDetailResponse(outbound.getCartableTransferRequestDto());
        return responseDto;
    }

    @Override
    public CartableFileGroupTransferDetailResponseDto getFileGroupTransferDetail(String requestCode) {
        GetCartableGroupFileTransferDetailMsg.Inbound inbound = new GetCartableGroupFileTransferDetailMsg.Inbound();
        CartableRequestCodeDto requestCodeDto = new CartableRequestCodeDto();
        requestCodeDto.setCartableRequestCode(requestCode);
        inbound.setCartableRequestCodeDto(requestCodeDto);
        GetCartableGroupFileTransferDetailMsg.Outbound outbound;

        try {
            outbound = channelManagerProvider.execute(inbound, GetCartableGroupFileTransferDetailMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        CartableFileGroupTransferDetailResponseDto responseDto = converterUtils.convertToFileGroupTransferDetailResponse(outbound.getCartableGroupFileTransferDetailDto());
        return responseDto;
    }

    @Override
    public CartableNormalBatchTransferDetailResponseDto getNormalBatchTransferDetail(String requestCode) {
        GetCartableBatchTransferRequestDetailMsg.Inbound inbound = new GetCartableBatchTransferRequestDetailMsg.Inbound();
        inbound.setCartableRequestCode(requestCode);
        GetCartableBatchTransferRequestDetailMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetCartableBatchTransferRequestDetailMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        CartableNormalBatchTransferDetailResponseDto responseDto = converterUtils.convertToCartableBatchTransferDetailResponse(outbound.getCartableTransferRequestDtos());
        return responseDto;
    }

    @Override
    public CartableAchBatchTransferDetailResponseDto getAchBatchTransferDetail(String requestCode) {
        GetCartableBatchAchOrderRequestDetailMsg.Inbound inbound = new GetCartableBatchAchOrderRequestDetailMsg.Inbound();
        inbound.setCartableRequestCode(requestCode);

        GetCartableBatchAchOrderRequestDetailMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetCartableBatchAchOrderRequestDetailMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        CartableAchBatchTransferDetailResponseDto responseDto = converterUtils.
                convertToCartableAchBatchTransferDetailResponse(outbound.getCartableBatchAchOrderTransferDetailsDto());
        return responseDto;
    }

    @Override
    public CartableAchNormalTransferDetailResponseDto getAchNormalTransferDetail(String requestCode) {
        GetCartableAchOrderRequestDetailMsg.Inbound inbound = new GetCartableAchOrderRequestDetailMsg.Inbound();
        inbound.setCartableRequestCode(requestCode);

        GetCartableAchOrderRequestDetailMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetCartableAchOrderRequestDetailMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        CartableAchNormalTransferDetailResponseDto responseDto = converterUtils.
                convertToCartableAchNormalTransferDetailResponse(outbound.getCartableAchOrderTransferDto());
        return responseDto;

    }

    @Override
    public ResultDto approveCartableRequest(ApproveCartableRequestDto requestDto) {
        ApproveCartableRequestMsg.Inbound inbound = new ApproveCartableRequestMsg.Inbound();
        inbound.setRequestBean(converterUtils.convertToApproveCartableRequestBean(requestDto));
        ApproveCartableRequestMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, ApproveCartableRequestMsg.Outbound.class);
            return ResultDto.success();
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public SingleCartableAchOrderTransferResponseDto singleCartableAchOrderTransfer(SingleCartableAchOrderTransferRequestDto requestDto) {
        RegisterCartableAchOrderRequestMsg.Inbound inbound = new RegisterCartableAchOrderRequestMsg.Inbound();
        inbound.setCartableAchOrderTransferDto(converterUtils.convertSingleCartableAchTransferRequest(requestDto));
        try {
            RegisterCartableAchOrderRequestMsg.Outbound outbound = channelManagerProvider.execute(inbound, RegisterCartableAchOrderRequestMsg.Outbound.class);
            return mapper.map(outbound.getCartableAchOrderTransferDto(), SingleCartableAchOrderTransferResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public BatchCartableAchOrderTransferResponseDto batchCartableAchOrderTransfer(BatchCartableAchOrderTransferRequestDto requestDto) {
        RegisterCartableBatchAchOrderRequestMsg.Inbound inbound = new RegisterCartableBatchAchOrderRequestMsg.Inbound();
        inbound.setCartableAchOrderTransferDto(converterUtils.convertBatchCartableAchTransferRequest(requestDto));
        try {
            RegisterCartableBatchAchOrderRequestMsg.Outbound outbound = channelManagerProvider.execute(inbound, RegisterCartableBatchAchOrderRequestMsg.Outbound.class);
            return mapper.map(outbound.getCartableBatchAchOrderTransferDto(), BatchCartableAchOrderTransferResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }



    @Override
    public GetWithdrawConditionsResponseDto getWithdrawConditions(String accountNumber, BigDecimal amount, Date expireDate) {
        GetWithdrawConditionsMsg.Inbound inbound = new GetWithdrawConditionsMsg.Inbound();
        ChWithdrawConditionsRequestBean conditionsRequestBean = new ChWithdrawConditionsRequestBean();
        conditionsRequestBean.setAccountNo(accountNumber);
        conditionsRequestBean.setAmount(amount);
        conditionsRequestBean.setExpireDate(expireDate);
        inbound.setRequestBean(conditionsRequestBean);

        GetWithdrawConditionsMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetWithdrawConditionsMsg.Outbound.class);

        } catch (ChannelManagerException e) {
            if (e.getMessage().contains("There is no valid Credit condition")) {
                throw new GatewayException(new UserInvalidWithdrawConditionException());
            } else if (e.getMessage().contains("DepartmentAccountException")) {
                throw new GatewayException(new DepartmentAccountException());
            }
            throw new GatewayException(e);
        }
        List<WithdrawConditionDto> itemList = mapper.mapList(outbound.getWithdrawConditionsDto(), WithdrawConditionDto.class);
        GetWithdrawConditionsResponseDto responseDto = new GetWithdrawConditionsResponseDto();
        responseDto.setWithdrawConditionDtoList(itemList);
        return responseDto;
    }

    @Override
    public ResultDto rejectCartableRequest(com.caspian.ebanking.pars.api.service.business.cartable.dto.CartableRequestCodeDto requestDto) {
        RejectCartableRequestMsg.Inbound inbound = new RejectCartableRequestMsg.Inbound();
        inbound.setCartableRequestCode(requestDto.getRequestCode());
        try {
            channelManagerProvider.execute(inbound, RejectCartableRequestMsg.Outbound.class);
            return ResultDto.success();
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto doCartableRequest(DoCartableRequestDto requestDto) {
        DoCartableRequestMsg.Inbound inbound = new DoCartableRequestMsg.Inbound();
        inbound.setDoCartableRequestDto(converterUtils.convertDoCartableRequest(requestDto));
        try {
            channelManagerProvider.execute(inbound, DoCartableRequestMsg.Outbound.class);
            return ResultDto.success();
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto cancelCartableRequest(com.caspian.ebanking.pars.api.service.business.cartable.dto.CartableRequestCodeDto requestDto) {
        CancelCartableRequestMsg.Inbound inbound = new CancelCartableRequestMsg.Inbound();
        inbound.setCartableRequestCode(requestDto.getRequestCode());
        try {
            channelManagerProvider.execute(inbound, CancelCartableRequestMsg.Outbound.class);
            return ResultDto.success();
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public SingleCartableNormalFundTransferResponseDto singleCartableNormalFundTransfer(SingleCartableNormalFundTransferRequestDto requestDto) {
        RegisterCartableTransferRequestMsg.Inbound inbound = new RegisterCartableTransferRequestMsg.Inbound();
        inbound.setCartableRequestDto(converterUtils.convertSingleCartableTransferRequest(requestDto));

        try {
            RegisterCartableTransferRequestMsg.Outbound outbound = channelManagerProvider.execute(inbound, RegisterCartableTransferRequestMsg.Outbound.class);
            return mapper.map(outbound.getCartableRequestDto(), SingleCartableNormalFundTransferResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public BatchCartableNormalFundTransferResponseDto batchCartableNormalFundTransfer(BatchCartableNormalFundTransferRequestDto requestDto) {
        RegisterCartableBatchTransferRequestMsg.Inbound inbound = new RegisterCartableBatchTransferRequestMsg.Inbound();
        inbound.setCartableRequestDto(converterUtils.convertBatchCartableTransferRequest(requestDto));
        try {
            RegisterCartableBatchTransferRequestMsg.Outbound outbound = channelManagerProvider.execute(inbound, RegisterCartableBatchTransferRequestMsg.Outbound.class);
            return mapper.map(outbound.getCartableBatchTransferRequestDto(), BatchCartableNormalFundTransferResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public SingleCartableRtgsOrderTransferResponseDto singleCartableRtgsOrderTransfer(SingleCartableRtgsOrderTransferRequestDto requestDto) {
        return createSingleRtgsResponseMock(requestDto);
    }

    private SingleCartableRtgsOrderTransferResponseDto createSingleRtgsResponseMock(SingleCartableRtgsOrderTransferRequestDto requestDto) {
        final SingleCartableRtgsOrderTransferResponseDto response = new SingleCartableRtgsOrderTransferResponseDto();
        response.setRequestCode("1611566978780");
        response.setAccountNumber(requestDto.getSourceAccount());
        response.setDescription(requestDto.getDescription());
        response.setExpireDate(requestDto.getExpireDate());
        response.setRequestDate(new Date());
        response.setPriority(requestDto.getPriority());
        response.setStatus('R');
        response.setWithdrawConditionCode("23552995");
        CartableAchOrderTransferEntry entry = new CartableAchOrderTransferEntry();
        entry.setDescription("تست کارتابل");
        entry.setIbanNumber("IR170540105402000166460007");
        entry.setOwnerName("اتوسا خانجانی");
        entry.setAmount(new BigDecimal(500000));
        entry.setFactorNumber("9999");
        response.setTransferRequestEntryDto(entry);
        return response;
    }
}