package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.AccountNo;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.FinancialDestinationNoProperty;
import com.caspian.moderngateway.core.coreservice.dto.ChChequeStatus;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۴:۵۸ بعدازظهر
 */
@Data
public class ChequeSheetDetailRequestDto {
@ApiModelProperty(value = "شماره دسته چک")
    protected String chequeBookNumber;
    @ApiModelProperty(value = "شماره چک")
    protected String chequeNumber;
    @ApiModelProperty(value = "شماره حساب")
    protected String depositNumber;
    protected Long length;
    protected Long offset;
    protected String statusList;
}