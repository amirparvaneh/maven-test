package com.caspian.ebanking.pars.api.service.business.account.exception;

/**
 * @author atousa khanjani
 * @since 01/09/2021 07:34 PM
 */
public class UserInvalidWithdrawConditionException extends RuntimeException {
    public UserInvalidWithdrawConditionException() {
    }

    public UserInvalidWithdrawConditionException(String message) {
        super(message);
    }

    public UserInvalidWithdrawConditionException(String message, Throwable cause) {
        super(message, cause);
    }

    public UserInvalidWithdrawConditionException(Throwable cause) {
        super(cause);
    }

    public UserInvalidWithdrawConditionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
