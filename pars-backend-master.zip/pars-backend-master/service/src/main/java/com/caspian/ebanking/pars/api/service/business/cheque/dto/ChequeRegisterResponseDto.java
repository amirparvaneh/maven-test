package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import lombok.Data;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۶:۲۲ بعدازظهر
 */
@Data
public class ChequeRegisterResponseDto {
}