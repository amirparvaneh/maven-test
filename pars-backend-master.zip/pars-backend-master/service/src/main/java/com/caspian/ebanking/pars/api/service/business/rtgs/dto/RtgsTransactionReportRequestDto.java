package com.caspian.ebanking.pars.api.service.business.rtgs.dto;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.AccountNo;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.FinancialDestinationNoProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.Date;

@Data
public class RtgsTransactionReportRequestDto {
  private String branchCode;
  private String depositNumber;
  private Date fromDate;
  private Long length;
  private Long offset;
  private String serial;
  private Date toDate;
}
