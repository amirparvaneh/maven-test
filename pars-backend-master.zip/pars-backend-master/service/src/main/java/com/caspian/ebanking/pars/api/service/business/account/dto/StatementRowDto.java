package com.caspian.ebanking.pars.api.service.business.account.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/29/2020 12:25 PM
 */
@Data
public class StatementRowDto {
    private String serialNumber;
    private Date date;
    private String time;
    private String description;
    private String customerComment;
    private BigDecimal balance;
    private String serial;
    private Long registrationNumber;
    private String branchCode;
    private String branchName;
    private String agentBranchCode;
    private String agentBranchName;
    private BigDecimal transferAmount;
    private String referenceNumber;
    private Integer sequence;
    private String depositSerial; // Deposit serial for check serial or receipt serial(This is reserved param)
}
