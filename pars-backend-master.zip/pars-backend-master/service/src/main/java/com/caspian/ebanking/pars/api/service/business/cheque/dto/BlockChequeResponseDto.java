package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۷/۰۲/۲۰۲۱ ۰۹:۱۷ قبل‌ازظهر
 */
@Data
public class BlockChequeResponseDto {
    private List<BlockChequeResponseItemDto> itemDtoList;
}