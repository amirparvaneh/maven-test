package com.caspian.ebanking.pars.api.service.business.ach.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/31/2020 10:06 AM
 */
@Data
public class AchTransactionReportResponseDto {
    private Long totalRecord;
    private List<AchTransactionReportItemDto> reportItemList;
}
