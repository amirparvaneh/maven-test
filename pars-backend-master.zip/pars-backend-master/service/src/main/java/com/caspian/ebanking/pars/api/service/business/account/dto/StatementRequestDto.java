package com.caspian.ebanking.pars.api.service.business.account.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/29/2020 11:18 AM
 */
@Data
@ApiModel
public class StatementRequestDto {
    @ApiModelProperty("شماره حساب")
    private String accountNumber;

    @ApiModelProperty(value = "ترتیب", allowableValues = "ASC,DESC")
    private String orderType; //ASC,DESC

    @ApiModelProperty(value = "مقدار این فیلد فعلا 0 است", allowableValues = "0")
    private Long fromRow;

    @ApiModelProperty(value = "بعد از پیاده سازی تنظیمات صورت حساب کاربرد دارد")
    private Long toRow;

    private Date fromDate;
    private Date toDate;
    private Date fromDateTime;
    private Date toDateTime;
    private BigDecimal fromAmount;
    private BigDecimal toAmount;

    @ApiModelProperty("شرح سند")
    private String description;

    @ApiModelProperty("یادداشت مشتری")
    private String customerDescription;

    @ApiModelProperty(value = "نوع تراکنش", allowableValues = "BOTH,CREDIT,DEBIT")
    private String actionType; // CREDIT,DEBIT,BOTH

    private String chequeSerial;

    @ApiModelProperty("شماره فیش")
    private String receiptNo;

    @ApiModelProperty("نمایش شرح سند")
    private Boolean showDealDesc;
}
