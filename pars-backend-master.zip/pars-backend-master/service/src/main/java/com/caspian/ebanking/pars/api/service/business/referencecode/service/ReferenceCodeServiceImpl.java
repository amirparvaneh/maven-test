package com.caspian.ebanking.pars.api.service.business.referencecode.service;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.service.business.file.dto.ClientFileDto;
import com.caspian.ebanking.pars.api.service.business.file.utils.FileReaderWriterService;
import com.caspian.ebanking.pars.api.service.business.file.utils.FileUtils;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.enums.ReportFileType;
import com.caspian.ebanking.pars.api.service.business.referencecode.dto.*;
import com.caspian.ebanking.pars.api.service.business.referencecode.utils.ReferenceCodeConverterUtils;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.*;
import com.caspian.moderngateway.core.domainmodel.exception.valuablecustomer.DuplicateLiquidatorCodeException;
import com.caspian.moderngateway.core.message.*;
import io.jsonwebtoken.lang.Collections;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 9:38 AM
 */
@Service
@RequiredArgsConstructor
public class ReferenceCodeServiceImpl extends BaseService implements ReferenceCodeService {
    private final ReferenceCodeConverterUtils referenceCodeConverterUtils;
    private final FileReaderWriterService fileReaderWriterService;


    @Override
    public GetOperationListResponseDto getOperationList() {
        GetOperationsListMsg.Inbound inbound = new GetOperationsListMsg.Inbound();
        try {
            final GetOperationsListMsg.Outbound outbound = channelManagerProvider.execute(inbound, GetOperationsListMsg.Outbound.class);
            return referenceCodeConverterUtils.convertToGetOperationsResponse(outbound.getOperationsBeanList());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }


    @Override
    public SettlementTitleResponseDto createSettlementTitle(SettlementTitleRequestDto requestDto) {
        CreateSettlementTitleMsg.Inbound inbound = new CreateSettlementTitleMsg.Inbound();
        inbound.setRequestBean(referenceCodeConverterUtils.convertToSettlementTitleRequest(requestDto));
        CreateSettlementTitleMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, CreateSettlementTitleMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        SettlementTitleResponseDto responseDto = new SettlementTitleResponseDto();
        responseDto.setSettleCode(result.getSettleCode());
        return responseDto;
    }

    @Override
    public CreateReferenceCodeResponseDto generateReferenceCode(CreateReferenceCodeRequestDto requestDto) {
        GenerateReferenceCodeMsg.Inbound inbound = new GenerateReferenceCodeMsg.Inbound();
        ChGenerateReferenceCodeRequestBean requestBean = referenceCodeConverterUtils.getChReferenceCodeBean(requestDto);
        inbound.setChGenerateReferenceCodeRequestBean(requestBean);
        GenerateReferenceCodeMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GenerateReferenceCodeMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        CreateReferenceCodeResponseDto responseDto = new CreateReferenceCodeResponseDto();
        responseDto.setReferenceCode(outbound.getResponseBean().getReferenceCode());
        return responseDto;
    }

    @Override
    public GetLiquidatorListResponseDto getLiquidatorList() {
        GetLiquidatorListMsg.Inbound inbound = new GetLiquidatorListMsg.Inbound();
        GetLiquidatorListMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetLiquidatorListMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        GetLiquidatorListResponseDto responseDto = new GetLiquidatorListResponseDto();
        responseDto.setLiquidatorDtoList(!Collections.isEmpty(outbound.getResponseBeans()) ?
                mapper.mapList(outbound.getResponseBeans(), LiquidatorDto.class) : null);
        return responseDto;
    }

    @Override
    public GetLiquidatorHierarchyResponseDto getLiquidatorsHierarchy() {
        GetLiquidatorHierarchyMsg.Inbound inbound = new GetLiquidatorHierarchyMsg.Inbound();
        GetLiquidatorHierarchyMsg.Outbound outbound;

        try {
            outbound = channelManagerProvider.execute(inbound, GetLiquidatorHierarchyMsg.Outbound.class);

        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        GetLiquidatorHierarchyResponseDto responseDto = new GetLiquidatorHierarchyResponseDto();
        responseDto.setItemDtoList(!Collections.isEmpty(outbound.getResponseBeans()) ?
                mapper.mapList(outbound.getResponseBeans(), LiquidatorHierarchyItemDto.class) : null);
        return responseDto;
    }

    @Override
    public GetSettlementTitleListResponseDto getSettlementTitleList(GetSettlementTitleListRequestDto requestDto) {
        GetSettlementTitleListMsg.Inbound inbound = new GetSettlementTitleListMsg.Inbound();
        inbound.setActive(requestDto.getIsActive());
        inbound.setOperationCode(requestDto.getOperationCode());
        GetSettlementTitleListMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetSettlementTitleListMsg.Outbound.class);
            return referenceCodeConverterUtils.convertToGetSettlementTitleResponse(outbound.getSettlementTitleList());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public GetSettlementTitleHierarchyResponseDto getSettlementTitleHierarchy() {
        GetSettlementTitleHierarchyMsg.Inbound inbound = new GetSettlementTitleHierarchyMsg.Inbound();
        GetSettlementTitleHierarchyMsg.Outbound outbound;

        try {
            outbound = channelManagerProvider.execute(inbound, GetSettlementTitleHierarchyMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        GetSettlementTitleHierarchyResponseDto responseDto = new GetSettlementTitleHierarchyResponseDto();
        responseDto.setItemDtoList(!Collections.isEmpty(outbound.getResponseList()) ?
                mapper.mapList(outbound.getResponseList(), SettlementTitleHierarchyItemDto.class) : null);

        return responseDto;
    }

    @Override
    public ResultDto createLiquidator(CreateLiquidatorRequestDto requestDto) {
        CreateLiquidatorMsg.Inbound inbound = new CreateLiquidatorMsg.Inbound();
        ChCreateLiquidatorRequestBean chLiquidatorRequestBean = mapper.map(requestDto, ChCreateLiquidatorRequestBean.class);
        inbound.setRequestBean(chLiquidatorRequestBean);
        CreateLiquidatorMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, CreateLiquidatorMsg.Outbound.class);
            if (outbound.getResponseBean().getResult())
                return ResultDto.success();
            else
                return ResultDto.failure();
        } catch (DuplicateLiquidatorCodeException e) {
            throw new GatewayException(e);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto updateLiquidator(CreateLiquidatorRequestDto requestDto) {
        UpdateLiquidatorMsg.Inbound inbound = new UpdateLiquidatorMsg.Inbound();
        ChUpdateLiquidatorRequestBean requestBean = mapper.map(requestDto, ChUpdateLiquidatorRequestBean.class);
        inbound.setRequestBean(requestBean);
        UpdateLiquidatorMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, UpdateLiquidatorMsg.Outbound.class);
            if (outbound.getResponseBean().getResult())
                return ResultDto.success();
            else
                return ResultDto.failure();
        } catch (DuplicateLiquidatorCodeException e) {
            throw new GatewayException(e);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public SettlementTitleResponseDto updateSettlementTitle(SettlementTitleRequestDto requestDto) {
        UpdateSettlementTitleMsg.Inbound inbound = new UpdateSettlementTitleMsg.Inbound();
        inbound.setRequestBean(referenceCodeConverterUtils.convertToSettlementTitleRequest(requestDto));
        UpdateSettlementTitleMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, UpdateSettlementTitleMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        SettlementTitleResponseDto responseDto = new SettlementTitleResponseDto();
        responseDto.setSettleCode(result.getResult());
        return responseDto;
    }

    @Override
    public ReferenceCodeReportResponseDto getReferenceCodeReport(ReferenceCodeReportRequestDto requestDto) {
        ReferenceCodeReportMsg.Inbound inbound = new ReferenceCodeReportMsg.Inbound();
        ChReferenceCodeRequestBean requestBean = referenceCodeConverterUtils.convertToReferenceCodeRequestBean(requestDto);
        inbound.setRequestBean(requestBean);
        ReferenceCodeReportMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, ReferenceCodeReportMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        ReferenceCodeReportResponseDto responseDto = new ReferenceCodeReportResponseDto();
        responseDto.setItemDtoList(!Collections.isEmpty(outbound.getResponseBean().getReferenceCodeResponseBeanList()) ?
                mapper.mapList(outbound.getResponseBean().getReferenceCodeResponseBeanList(), ReferenceCodeReportItemDto.class) : null);
        return responseDto;
    }

    @Override
    public ResultDto changeReferenceCodeStatus(ChangeReferenceCodeStatusRequestDto requestDto) {
        ChangeStatusReferenceCodeMsg.Inbound inbound = new ChangeStatusReferenceCodeMsg.Inbound();
        ChangeStatusReferenceCodeRequestBean referenceCodeRequestBean =
                referenceCodeConverterUtils.convertToChangeStatusReferenceCodeBean(requestDto);
        inbound.setRequestBean(referenceCodeRequestBean);
        ChangeStatusReferenceCodeMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, ChangeStatusReferenceCodeMsg.Outbound.class);
            if (outbound != null) {
                return ResultDto.success();
            } else {
                return ResultDto.failure();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public DepositByReferenceCodeReportResponseDto depositByReferenceCodeReport(DepositByReferenceCodeReportRequestDto requestDto) {
        DepositByReferenceCodeReportMsg.Inbound inbound = new DepositByReferenceCodeReportMsg.Inbound();
        ChDepositByReferenceRequestBean requestBean = referenceCodeConverterUtils.convertToDepositByReferenceCodeReportRequest(requestDto);
        inbound.setRequestBean(requestBean);
        DepositByReferenceCodeReportMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, DepositByReferenceCodeReportMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        return referenceCodeConverterUtils.convertToDepositByReferenceCodeReportResponse(outbound.getResponseBean());
    }

    @Override
    public GetBankInfoResponseDto getBankInfo() {
        GetBanksMsg.Inbound inbound = new GetBanksMsg.Inbound();
        ChBankSearchRequestBean requestBean = new ChBankSearchRequestBean();
        requestBean.setOffset(0L);
        requestBean.setLength(1000L);
        inbound.setRequestBean(requestBean);
        GetBanksMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetBanksMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        GetBankInfoResponseDto responseDto = new GetBankInfoResponseDto();
        responseDto.setBanks(mapper.mapList(outbound.getResponseBean().getBanks(), BankInfoDto.class));
        responseDto.setTotalRecord(outbound.getResponseBean().getTotalRecord());
        return responseDto;

    }


    @Override
    public StatementWithReferenceCodeReportResponseDto getStatementWithReferenceCodeReport
            (StatementWithReferenceCodeReportRequestDto requestDto) {
        StatementWithReferenceCodeReportMsg.Inbound inbound = new StatementWithReferenceCodeReportMsg.Inbound();

        ChStatementWithReferenceCodeRequestBean requestBean = referenceCodeConverterUtils.convertToStatementWithReferenceCodeBean(requestDto);
        inbound.setRequestBean(requestBean);
        StatementWithReferenceCodeReportMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, StatementWithReferenceCodeReportMsg.Outbound.class);

        } catch (ChannelManagerException e) {
            throw new GatewayException(e);

        }
        StatementWithReferenceCodeReportResponseDto responseDto = new StatementWithReferenceCodeReportResponseDto();
        responseDto.setItemDtoList(referenceCodeConverterUtils.convertToStatemenetWithReferenceCodeResponse(outbound.getResponseBean()));
        return responseDto;
    }

    @Override
    public void getReferenceCodeExcelReport(ReferenceCodeReportRequestDto requestDto, String fileType, HttpServletResponse response) {
        CreateReferenceCodeExcelReportMsg.Inbound inbound = new CreateReferenceCodeExcelReportMsg.Inbound();
        ChReferenceCodeRequestBean requestBean = referenceCodeConverterUtils.convertToReferenceCodeRequestBean(requestDto);
        inbound.setChReferenceCodeRequestBean(requestBean);
        CreateReferenceCodeExcelReportMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, CreateReferenceCodeExcelReportMsg.Outbound.class);
            final ClientFileDto.Extension extension = ClientFileDto.Extension.convert(fileType);
            final ClientFileDto dto = new ClientFileDto(null, null, extension);


            if (result.getBytes() != null) {
                FileUtils.writeToResponse(result.getBytes(),
                        ReportFileType.fromExtension(dto.getExtension()),
                        "Reference_Code_Report--" + requestDto.getReferenceCode(),
                        response);
            } else {
                throw new GatewayException();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public GetReferenceCodeStatementByChequeResponseDto getReferenceCodeStatementByCheque(GetReferenceCodeStatementByChequeRequestDto requestDto) {
        GetReferenceCodeStatementByChequeMsg.Inbound inbound = new GetReferenceCodeStatementByChequeMsg.Inbound();
        ChGetReferenceCodeStatementByChequeRequestBean requestBean = referenceCodeConverterUtils.convertToStatementByChequeRequest(requestDto);
        inbound.setRequestBean(requestBean);
        GetReferenceCodeStatementByChequeMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetReferenceCodeStatementByChequeMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }

        return referenceCodeConverterUtils.convertToStatementByChequeResponse(outbound.getResponseBeanList());
    }

    @Override
    public void getReferenceCodeStatementByChequePdfReport(GetReferenceCodeStatementByChequeRequestDto requestDto, HttpServletResponse response) {
        GetReferenceCodeStatementByChequePdfReportMsg.Inbound inbound = new GetReferenceCodeStatementByChequePdfReportMsg.Inbound();
        ChGetReferenceCodeStatementByChequeRequestBean requestBean = referenceCodeConverterUtils.convertToStatementByChequeRequest(requestDto);
        inbound.setRequestBean(requestBean);
        GetReferenceCodeStatementByChequePdfReportMsg.Outbound outbound;
        try {
            outbound = channelManagerProvider.execute(inbound, GetReferenceCodeStatementByChequePdfReportMsg.Outbound.class);
            FileUtils.writeToResponse(outbound.getBytes(),
                    ReportFileType.PDF,
                    "referenceCodeStatementByChequePdf_" + requestDto.getReferenceCode(),
                    response);

        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }

    }

    @Override
    public void getStatementWithReferenceCodeExcelReport(StatementWithReferenceCodeReportRequestDto requestDto, String fileType, HttpServletResponse response) {
        CreateStatementWithReferenceCodeExcelReportMsg.Inbound inbound = new CreateStatementWithReferenceCodeExcelReportMsg.Inbound();
        ChStatementWithReferenceCodeRequestBean requestBean = referenceCodeConverterUtils.convertToStatementWithReferenceCodeBean(requestDto);
        inbound.setChStatementWithReferenceCodeRequestBean(requestBean);
        CreateStatementWithReferenceCodeExcelReportMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, CreateStatementWithReferenceCodeExcelReportMsg.Outbound.class);
            final ClientFileDto.Extension extension = ClientFileDto.Extension.convert(fileType);
            final ClientFileDto dto = new ClientFileDto(null, null, extension);


            if (result.getBytes() != null) {
                FileUtils.writeToResponse(result.getBytes(),
                        ReportFileType.fromExtension(dto.getExtension()),
                        "Statement_With_Reference_Code_Report-" + requestDto.getAccountNumber(),
                        response);
            } else {
                throw new GatewayException();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public void getStatementWithReferenceCodePdfReport(StatementWithReferenceCodeReportRequestDto requestDto, HttpServletResponse response) {
        CreateStatementWithReferenceCodePdfReportMsg.Inbound inbound = new CreateStatementWithReferenceCodePdfReportMsg.Inbound();
        ChStatementWithReferenceCodeRequestBean requestBean = referenceCodeConverterUtils.convertToStatementWithReferenceCodeBean(requestDto);
        inbound.setChStatementWithReferenceCodeRequestBean(requestBean);
        CreateStatementWithReferenceCodePdfReportMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, CreateStatementWithReferenceCodePdfReportMsg.Outbound.class);
            if (result.getBytes() != null) {
                FileUtils.writeToResponse(result.getBytes(),
                        ReportFileType.PDF,
                        "Statement_With_Reference_Code_Report-" + requestDto.getAccountNumber(),
                        response);
            } else {
                throw new GatewayException();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }
}