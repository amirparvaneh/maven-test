package com.caspian.ebanking.pars.api.service.business.file.utils;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class FileReaderWriterModel {

    public enum ReaderWriterType {
        FTP,
        HDD
    }

    private Logger log = Logger.getLogger("LotusIBLog-" + this.getClass().getSimpleName());

    private static FileReaderWriterModel instance;

    private String destinationType;
    private String ftpServer;
    private Integer ftpPort;
    private String ftpUser;
    private String ftpPassword;
    private Integer ftpConnectTimeout;
    private Integer ftpReadTimeout;
    private String loadedBasePath;

    private FileReaderWriterModel() {
        Properties properties = new Properties();
        try {
            InputStream stream = this.getClass().getClassLoader().getResourceAsStream("file.properties");
            properties.load(stream);

            destinationType = properties.getProperty("file.destination.type");
            ftpServer = properties.getProperty("file.ftp.host");
            ftpPort = Integer.parseInt(properties.getProperty("file.ftp.port"));
            ftpUser = properties.getProperty("file.ftp.user");
            ftpPassword = properties.getProperty("file.ftp.password");
            ftpConnectTimeout = Integer.parseInt(properties.getProperty("file.ftp.connectTimeout"));
            ftpReadTimeout = Integer.parseInt(properties.getProperty("file.ftp.readTimeout"));
            loadedBasePath = properties.getProperty("file.destination.path");
        } catch (NullPointerException e) {
            log.warn("-> Loading 'file.properties' configuration failed.");
        } catch (IOException e) {
            log.warn(e);
        }
    }

    public static FileReaderWriterModel getInstance() {
        if (instance == null) {
            instance = new FileReaderWriterModel();
            return instance;
        } else
            return instance;
    }

    public String getFtpServer() {
        return ftpServer;
    }

    public Integer getFtpPort() {
        return ftpPort;
    }

    public String getFtpUser() {
        return ftpUser;
    }

    public String getFtpPassword() {
        return ftpPassword;
    }

    public Integer getFtpConnectTimeout() {
        return ftpConnectTimeout;
    }

    public Integer getFtpReadTimeout() {
        return ftpReadTimeout;
    }

    public String getLoadedBasePath() {
        return loadedBasePath;
    }

    public String getDestinationType() {
        return destinationType;
    }

    public ReaderWriterType getReaderWriterType() {
        return ReaderWriterType.valueOf(getDestinationType());
    }

}
