package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 01/21/2021 9:53 AM
 */
@Data
public class BatchCartableAchOrderTransferResponseDto {
    private Long id;
    private String requestCode;
    private Date requestDate;
    private Date expireDate;
    private String description;
    private Character priority;
    private String accountNumber;
    private Character status;
    private CartableAchOrderTransferEntry cartableAchOrderTransferEntryDto;
    private String withdrawConditionCode;
    private List<CartableTransferApprovalDto> cartableApprovalRequestDtos;
}
