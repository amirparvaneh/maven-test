package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۰۳:۱۲ بعدازظهر
 */
@Data
public class GuarantyReportRequestDto {
    @ApiModelProperty(value = "شماره ضمانتنامه")
    private String guarantyNumber;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "از تاریخ گشایش")
    private Date fromOpeningDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تا تاریخ گشایش")
    private Date toOpeningDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "از تاریخ انقضا")
    private Date fromExpireDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تا تاریخ انقضا")
    private Date toExpireDate;

    @ApiModelProperty(value = "نوع ضمانتنامه",allowableValues = "IMPORTED,ISSUED")
    private String guarantyType;

    @ApiModelProperty(value = "نوع وثیقه",allowableValues = "IMMOVABLE_PROPERTY,MOVABLE_PROPERTY,COMMERICAL_DOCS")
    private String bailType;

    private BigDecimal fromAmount;
    private BigDecimal toAmount;

    @ApiModelProperty(value = "نوع ارز",allowableValues = "IRR,USD")
    private String currencyType;

    private String branch;
}