package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/5/2021 1:45 PM
 */
@Data
@ApiModel
public class SingleCartableNormalFundTransferRequestDto {
    @ApiModelProperty(name = "حساب مبدا")
    private String sourceAccount;

    @ApiModelProperty(name = "حساب مقصد")
    private String destinationAccount;

    @ApiModelProperty(name = "تاریخ انقضا")
    private Date expireDate;

    @ApiModelProperty(name = "اولویت", allowableValues = "M,C,I,T", notes = "(1: MAJOR, 2: CRITICAL, 3: MINOR, 4: TRIVIAL)")
    private Character priority;

    @ApiModelProperty(name = "شرح کارتابل")
    private String cartableDescription;

    @ApiModelProperty(name = "مبلغ")
    private BigDecimal amount;

    @ApiModelProperty(name = "یادداشت گیرنده")
    private String destinationComment;

    @ApiModelProperty(name = "یادداشت فرستنده")
    private String sourceComment;

    @ApiModelProperty(name = "شناسه شرط برداشت")
    private String conditionId;
}
