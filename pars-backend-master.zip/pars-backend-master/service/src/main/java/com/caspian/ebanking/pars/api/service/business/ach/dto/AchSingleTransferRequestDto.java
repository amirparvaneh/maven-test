package com.caspian.ebanking.pars.api.service.business.ach.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author atousa khanjani
 * @since 12/29/2020 07:34 PM
 */
@Data
public class AchSingleTransferRequestDto {
    private String sourceDepositNumber;
    private String ibanNumber;
    private String secondPassword;
    private BigDecimal amount;
    private String ownerName;
    private String description;
    private String transferDescription;
    private String factorNumber;
    private String email;
    private String passwordType;
}
