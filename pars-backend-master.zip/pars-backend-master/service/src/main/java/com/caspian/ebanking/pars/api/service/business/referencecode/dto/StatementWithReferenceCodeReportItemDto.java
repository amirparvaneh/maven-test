package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۳/۰۲/۲۰۲۱ ۱۰:۱۱ قبل‌ازظهر
 */
@Data
public class StatementWithReferenceCodeReportItemDto {
    private Date date;
    private String time;
    @ApiModelProperty(value = "کد شعبه")
    private Integer branchCode;
    @ApiModelProperty(value = "واریز کننده")
    private String liquidator;
    @ApiModelProperty(value = "شناسه واریز")
    private String referenceCode;
    @ApiModelProperty(value = "شرح")
    private String description;
    @ApiModelProperty(value = "شماره چک")
    private String chequeNumber;
    @ApiModelProperty(value = "مبلغ واریز/برداشت اگر منفی بود برداشت است و اگر مثبت بود واریز است")
    private BigDecimal transferAmount;
    @ApiModelProperty(value = "شماره سند")
    private String docNumber;
    private String debit;
    private String credit;
    @ApiModelProperty(value = "موجودی")
    private BigDecimal balance;
    @ApiModelProperty(value = "عنوان واریز")
    private String settleTitle;
}