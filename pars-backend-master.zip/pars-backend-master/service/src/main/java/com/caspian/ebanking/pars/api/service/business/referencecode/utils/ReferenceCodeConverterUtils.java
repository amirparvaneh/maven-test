package com.caspian.ebanking.pars.api.service.business.referencecode.utils;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.utils.CollectionUtils;
import com.caspian.ebanking.pars.api.base.utils.DateUtils;
import com.caspian.ebanking.pars.api.service.business.referencecode.dto.*;
import com.caspian.ebanking.pars.api.service.business.referencecode.enums.ExtraParameterPosition;
import com.caspian.ebanking.pars.api.service.business.referencecode.enums.ReferenceCodeType;
import com.caspian.ebanking.pars.api.service.business.referencecode.enums.SettlementType;
import com.caspian.moderngateway.core.coreservice.dto.*;
import io.jsonwebtoken.lang.Collections;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 9:38 AM
 */
@Component
@RequiredArgsConstructor
public class ReferenceCodeConverterUtils {
    private final ParsModelMapper mapper;

    public GetOperationListResponseDto convertToGetOperationsResponse(List<ChOperationsBean> response) {
        List<OperationItemDto> list = new ArrayList<>();
        GetOperationListResponseDto responseDto = new GetOperationListResponseDto();
        if (!CollectionUtils.isNullOrEmpty(response)) {
            for (ChOperationsBean item : response) {
                OperationItemDto operationItemDto = new OperationItemDto();
                operationItemDto.setOperationCode(item.getOperationCode());
                operationItemDto.setOperationId(item.getOperationId());
                operationItemDto.setBranchCode(item.getBranchCode());
                operationItemDto.setOperationTitle(item.getOperationTitle());
                operationItemDto.setAccountNumber(item.getAccountNumber());
                operationItemDto.setOwnerName(item.getOwnerName());
                list.add(operationItemDto);
            }
            responseDto.setOperationItemDtoList(list);
        }
        return responseDto;
    }

    public SettlementTitleBean convertToSettlementTitleRequest(SettlementTitleRequestDto requestDto) {
        SettlementTitleBean settlementTitleBean = new SettlementTitleBean();
        settlementTitleBean.setOperationCode(requestDto.getOperationCode());
        settlementTitleBean.setSettleTitle(requestDto.getSettleTitle());
        settlementTitleBean.setParentId(requestDto.getParentId());
        settlementTitleBean.setSettleTitleCode(requestDto.getSettleTitleCode());
        return settlementTitleBean;
    }

    public ChGenerateReferenceCodeRequestBean getChReferenceCodeBean(CreateReferenceCodeRequestDto requestDto) {
        ChGenerateReferenceCodeRequestBean chReferenceCodeBean = new ChGenerateReferenceCodeRequestBean();
        chReferenceCodeBean.setLiquidatorCode(requestDto.getLiquidatorCode());
        chReferenceCodeBean.setLiquidatorName(requestDto.getLiquidatorName());
        chReferenceCodeBean.setPhoneNumber(requestDto.getPhoneNumber());
        chReferenceCodeBean.setDescription(requestDto.getDescription());
        chReferenceCodeBean.setReferenceCodeType(ReferenceCodeType.getCharacterOf(requestDto.getReferenceCodeType()));
        chReferenceCodeBean.setSettleTitleCode(requestDto.getSettleTitleCode());
        chReferenceCodeBean.setExtraParameter(requestDto.getExtraParameter());
        chReferenceCodeBean.setExtraParameterPosition(requestDto.getExtraParameterPosition() != null && !requestDto.getExtraParameterPosition().isEmpty() ?
                ExtraParameterPosition.getCharacterOf(requestDto.getExtraParameterPosition()) : null);
        chReferenceCodeBean.setExpireDate(requestDto.getExpireDate());
        Long currentTimeMillis = System.currentTimeMillis();
        chReferenceCodeBean.setTrackingNo(currentTimeMillis.toString());
        ArrayList<ChReferenceCodeDetailBean> referenceCodeDetailBeans = new ArrayList<>();
        if (!Collections.isEmpty(requestDto.getReferenceCodeDetailList())) {
            referenceCodeDetailBeans.addAll(mapper.mapList(requestDto.getReferenceCodeDetailList(), ChReferenceCodeDetailBean.class));
            chReferenceCodeBean.setReferenceCodeDetailList(referenceCodeDetailBeans);
        }
        return chReferenceCodeBean;
    }

    public GetSettlementTitleListResponseDto convertToGetSettlementTitleResponse(List<SettlementTitleBean> response) {
        List<SettlementTitleDto> list = new ArrayList<>();
        GetSettlementTitleListResponseDto responseDto = new GetSettlementTitleListResponseDto();
        if (!CollectionUtils.isNullOrEmpty(response)) {
            for (SettlementTitleBean item : response) {
                SettlementTitleDto settlementTitle = new SettlementTitleDto();
                settlementTitle.setId(item.getId());
                settlementTitle.setSettleTitle(item.getSettleTitle());
                settlementTitle.setSettleTitleCode(item.getSettleTitleCode());
                OperationItemDto operation = new OperationItemDto();
                if (item.getChOperationsBean() != null) {
                    operation.setOperationCode(item.getChOperationsBean().getOperationCode());
                    operation.setOperationTitle(item.getChOperationsBean().getOperationTitle());
                    operation.setAccountNumber(item.getChOperationsBean().getAccountNumber());
                    operation.setOwnerName(item.getChOperationsBean().getOwnerName());
                    operation.setBranchCode(item.getChOperationsBean().getBranchCode());
                }
                settlementTitle.setOperationItemDto(operation);
                settlementTitle.setStatus(SettlementType.getNameOf(item.getStatus()));
                list.add(settlementTitle);
            }
        }
        responseDto.setSettlementTitleDtos(list);
        return responseDto;
    }

    public ChReferenceCodeRequestBean convertToReferenceCodeRequestBean(ReferenceCodeReportRequestDto requestDto) {
        ChReferenceCodeRequestBean requestBean = new ChReferenceCodeRequestBean();
        requestBean.setFromAmount(requestDto.getFromAmount());
        requestBean.setToAmount(requestDto.getToAmount());
        requestBean.setFromDate(DateUtils.getTimeValue(requestDto.getFromDate(), 0, 0, 0));
        requestBean.setToDate(DateUtils.getTimeValue(requestDto.getToDate(), 23, 59, 59));
        requestBean.setLiquidator(requestDto.getLiquidator());
        requestBean.setPhoneNumber(requestDto.getPhoneNumber());
        requestBean.setReferenceType(requestDto.getReferenceType() != null ?
                ReferenceCodeType.getCharacterOf(requestDto.getReferenceType()) : null);
        if (requestDto.getSettleTitleCodes() != null && !requestDto.getSettleTitleCodes().isEmpty())
            requestBean.setSettleTitleCodes(Arrays.asList(requestDto.getSettleTitleCodes().split(","))
                    .stream().collect(Collectors.toList()));
        requestBean.setReferenceCode(requestDto.getReferenceCode());
        return requestBean;

    }

    public ChangeStatusReferenceCodeRequestBean convertToChangeStatusReferenceCodeBean(ChangeReferenceCodeStatusRequestDto requestDto) {
        ChangeStatusReferenceCodeRequestBean requestBean = new ChangeStatusReferenceCodeRequestBean();
        requestBean.setOperationCode(requestDto.getOperationCode());
        requestBean.setReferenceCode(requestDto.getReferenceCode());
        if (requestDto.getReferenceCodeType() != null && !requestDto.getReferenceCodeType().isEmpty())
            requestBean.setReferenceCodeType(ReferenceCodeType.getCharacterOf(requestDto.getReferenceCodeType()));
        return requestBean;
    }

    public ChDepositByReferenceRequestBean convertToDepositByReferenceCodeReportRequest(DepositByReferenceCodeReportRequestDto requestDto) {
        ChDepositByReferenceRequestBean requestBean = new ChDepositByReferenceRequestBean();
        requestBean.setFromCreateReferenceDate(requestDto.getFromDate());
        requestBean.setToCreateReferenceDate(requestDto.getToDate());
        requestBean.setReferenceCode(requestDto.getReferenceCode());
        return requestBean;
    }

    public DepositByReferenceCodeReportResponseDto convertToDepositByReferenceCodeReportResponse(ChDepositByReferenceResponseBean bean) {
        DepositByReferenceCodeReportResponseDto depositByReferenceCodeDto = new DepositByReferenceCodeReportResponseDto();
        if (bean != null) {
            depositByReferenceCodeDto.setChDetailOfReferenceCodeList(new ArrayList<>());
            depositByReferenceCodeDto.setDocumentIssues(new ArrayList<>());
            if (bean.getChDetailReferenceCode() != null) {
                final ChDetailReferenceCodeBean chDetailReferenceCode = bean.getChDetailReferenceCode();
                depositByReferenceCodeDto.setReferenceCodeCreator(chDetailReferenceCode.getReferenceCodeCreator());
                depositByReferenceCodeDto.setDepositTitle(chDetailReferenceCode.getDepositTitle());
                depositByReferenceCodeDto.setLiquidator(chDetailReferenceCode.getLiquidator());
                depositByReferenceCodeDto.setCreateDate(chDetailReferenceCode.getCreateDate());
                depositByReferenceCodeDto.setExpireDate(chDetailReferenceCode.getExpireDate());
                depositByReferenceCodeDto.setAccountNumber(chDetailReferenceCode.getAccountNumber());
                depositByReferenceCodeDto.setPhoneNumber(chDetailReferenceCode.getPhoneNumber());
                depositByReferenceCodeDto.setDescription(chDetailReferenceCode.getDescription());
                depositByReferenceCodeDto.setReferenceCode(chDetailReferenceCode.getReferenceCode());
                depositByReferenceCodeDto.setOrganization(chDetailReferenceCode.getOrganization());
                depositByReferenceCodeDto.setReferenceCodeType(String.valueOf(chDetailReferenceCode.getReferenceCodeType()));
                if (CollectionUtils.isNullOrEmpty(chDetailReferenceCode.getChDetailOfReferenceCodeList())) {
                    for (ChDetailOfReferenceCode detailOfReferenceCode : chDetailReferenceCode.getChDetailOfReferenceCodeList()) {
                        DetailOfReferenceCodeDto referenceCodeModel = getDetailOfReferenceCodeDto(detailOfReferenceCode);
                        depositByReferenceCodeDto.getChDetailOfReferenceCodeList().add(referenceCodeModel);
                    }
                }
            }
            if (!CollectionUtils.isNullOrEmpty(bean.getChDocumentsIssuedDtoList())) {
                for (ChDocumentsIssuedBean item : bean.getChDocumentsIssuedDtoList()) {
                    DocumentsIssuedDto documentIssued = getDocumentsIssuedDto(item);
                    depositByReferenceCodeDto.getDocumentIssues().add(documentIssued);
                }
            }
        }
        return depositByReferenceCodeDto;
    }

    private DocumentsIssuedDto getDocumentsIssuedDto(ChDocumentsIssuedBean item) {
        DocumentsIssuedDto documentIssued = new DocumentsIssuedDto();
        documentIssued.setAccountNumber(item.getAccountNumber());
        documentIssued.setSettleTitle(item.getSettleTitle());
        documentIssued.setDate(item.getDate());
        documentIssued.setRegistrationDocTime(item.getRegistrationDocTime());
        documentIssued.setBranchCode(item.getBranchCode());
        documentIssued.setLiquidator(item.getLiquidator());
        documentIssued.setReferenceCode(item.getReferenceCode());
        documentIssued.setDocNumber(item.getDocNumber());
        documentIssued.setAmount(item.getAmount());
        return documentIssued;
    }

    private DetailOfReferenceCodeDto getDetailOfReferenceCodeDto(ChDetailOfReferenceCode detailOfReferenceCode) {
        DetailOfReferenceCodeDto referenceCodeModel = new DetailOfReferenceCodeDto();
        referenceCodeModel.setAmount((detailOfReferenceCode.getAmount() != null) ? String.valueOf(detailOfReferenceCode.getAmount()) : "0");
        referenceCodeModel.setSettleTitleCode(detailOfReferenceCode.getSettleTitleCode());
        referenceCodeModel.setSettleTitle(detailOfReferenceCode.getSettleTitle());
        referenceCodeModel.setNumberOfRefCode((detailOfReferenceCode.getNumberOfRefCode() != null) ? String.valueOf(detailOfReferenceCode.getNumberOfRefCode()) : "0");
        return referenceCodeModel;
    }

    public ChStatementWithReferenceCodeRequestBean convertToStatementWithReferenceCodeBean(StatementWithReferenceCodeReportRequestDto requestDto) {
        ChStatementWithReferenceCodeRequestBean requestBean = new ChStatementWithReferenceCodeRequestBean();
        requestBean.setAccountNumber(requestDto.getAccountNumber());
        requestBean.setFromDate(DateUtils.getTimeValue(requestDto.getFromDate(), 0, 0, 0));
        requestBean.setToDate(DateUtils.getTimeValue(requestDto.getToDate(), 23, 59, 59));
        requestBean.setFromDateTime(DateUtils.getTimeValue(requestDto.getFromDate(), requestDto.getFromDateTime()));
        requestBean.setToDateTime(DateUtils.getTimeValue(requestDto.getToDate(), requestDto.getToDateTime()));
        requestBean.setFromAmount(requestDto.getFromAmount());
        requestBean.setOffset(0L);
        requestBean.setLength(requestDto.getLength());
        requestBean.setToAmount(requestDto.getToAmount());
        requestBean.setStatementSearchDirection(requestDto.getStatementSearchDirection()!=null?
                ChStatementSearchDirection.fromValue(requestDto.getStatementSearchDirection()):null);
        return requestBean;
    }

    public List<StatementWithReferenceCodeReportItemDto> convertToStatemenetWithReferenceCodeResponse(List<ChStatementWithReferenceCodeResponseBean> responseBean) {
        List<StatementWithReferenceCodeReportItemDto> itemDtoList = new ArrayList<>();
        if (responseBean == null) {
            return itemDtoList;
        }
        for (ChStatementWithReferenceCodeResponseBean item : responseBean) {
            StatementWithReferenceCodeReportItemDto newItem;
            newItem = mapper.map(item, StatementWithReferenceCodeReportItemDto.class);
            newItem.setDate(item.getRegistrationDocTime());
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            Calendar gCal = new GregorianCalendar();
            gCal.setTime(item.getRegistrationDocTime());
            newItem.setTime(sdf.format(gCal.getTime()));
            itemDtoList.add(newItem);
        }
        return itemDtoList;
    }

    public GetReferenceCodeStatementByChequeResponseDto convertToStatementByChequeResponse(List<ChGetReferenceCodeStatementByChequeResponseBean> responseBeanList) {

        List<GetReferenceCodeStatementByChequeDto> referenceCodeStatementByChequeList = new ArrayList<>();
        GetReferenceCodeStatementByChequeDto chequeDto;
        GetReferenceCodeStatementByChequeResponseDto responseDto = new GetReferenceCodeStatementByChequeResponseDto();
        if (!CollectionUtils.isNullOrEmpty(responseBeanList)) {

            for (ChGetReferenceCodeStatementByChequeResponseBean responseBean : responseBeanList) {
                chequeDto = new GetReferenceCodeStatementByChequeDto();
                chequeDto.setReferenceType(responseBean.getReferenceType());
                chequeDto.setReferenceCode(responseBean.getReferenceCode());
                chequeDto.setDescription(responseBean.getDescription());
                chequeDto.setAmount(responseBean.getAmount());
                chequeDto.setReceiptNumber(responseBean.getReceiptNumber());
                chequeDto.setDealNarrative(responseBean.getDealNarrative());
                chequeDto.setDealReference(responseBean.getDealReference());
                chequeDto.setDealDate(responseBean.getDealDate());
                chequeDto.setBusinessTime(responseBean.getBusinessTime());
                chequeDto.setEntryNarrative(responseBean.getEntryNarrative());
                chequeDto.setExtraNarrative(responseBean.getExtraNarrative());
                chequeDto.setChequeNumber(responseBean.getChequeNumber());
                chequeDto.setOperatorBranchCode(responseBean.getOperatorBranchCode());
                chequeDto.setChequeBankCode(responseBean.getChequeBankCode());
                chequeDto.setChequeBranchCode(responseBean.getChequeBranchCode());
                chequeDto.setChequeOpBranchCode(responseBean.getChequeOpBranchCode());
                chequeDto.setChequeDate(responseBean.getChequeDate());
                chequeDto.setChequeRegisterDate(responseBean.getChequeRegisterDate());
                chequeDto.setChequeSeri(responseBean.getChequeSeri());
                chequeDto.setChequeType(responseBean.getChequeType());
                referenceCodeStatementByChequeList.add(chequeDto);
            }
        }
        responseDto.setTotal(String.valueOf(referenceCodeStatementByChequeList.size()));
        responseDto.setResponseBeanList(referenceCodeStatementByChequeList);
        return responseDto;
    }


    public ChGetReferenceCodeStatementByChequeRequestBean convertToStatementByChequeRequest(GetReferenceCodeStatementByChequeRequestDto requestDto) {

        ChGetReferenceCodeStatementByChequeRequestBean requestBean = new ChGetReferenceCodeStatementByChequeRequestBean();
        requestBean.setAccountNumber(requestDto.getAccountNumber());
        requestBean.setChequeBankCode(requestDto.getChequeBankCode());
        requestBean.setChequeNumber(requestDto.getChequeNumber());
        requestBean.setChStatementSearchDirection(ChStatementSearchDirection.fromValue(requestDto.getSearchDirection()));
        requestBean.setDealReference(requestDto.getDealReference());
        requestBean.setChequeOpBranchCode(requestDto.getChequeOpBranchCode());
        requestBean.setFromAmount(requestDto.getFromAmount());
        requestBean.setToAmount(requestDto.getToAmount());
        requestBean.setLength(requestDto.getLength());
        requestBean.setOffset(requestDto.getOffset());
        requestBean.setPassChequeFrom(requestDto.getPassChequeFrom());
        requestBean.setPassChequeTo(requestDto.getPassChequeTo());
        requestBean.setReferenceCode(requestDto.getReferenceCode());
        return requestBean;

    }

}