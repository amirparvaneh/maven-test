package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 11:38 PM
 */
@Data
public class DepositByReferenceCodeReportRequestDto {
    @ApiModelProperty(value = "شناسه واریز")
    private String referenceCode;
    @ApiModelProperty(value = "از تاریخ")
    private Date fromDate;
    @ApiModelProperty(value = "تاتاریخ")
    private Date toDate;


}
