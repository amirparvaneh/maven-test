package com.caspian.ebanking.pars.api.service.business.remitance.service;

import com.caspian.ebanking.pars.api.service.business.remitance.dto.*;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۱۰:۰۷ قبل‌ازظهر
 */
@Service
@RequiredArgsConstructor
public class RemittanceServiceImpl extends BaseService implements RemittanceService {

    @Override
    public CurrencyRemittanceReportResponseDto currencyRemittanceReport(CurrencyRemittanceReportRequestDto requestDto) {
        CurrencyRemittanceReportResponseDto responseDto = new CurrencyRemittanceReportResponseDto();
        List<CurrencyRemittanceReportItemDto> itemDtoList = new ArrayList<>();
        Random random = new Random();
        for (int i = 1; i <= 10; i++) {
            CurrencyRemittanceReportItemDto newItem = new CurrencyRemittanceReportItemDto();
            newItem.setRemittanceNumber(String.valueOf(Math.abs(random.nextLong())));
            newItem.setAmount(BigDecimal.valueOf(20000000));
            newItem.setAmountEquivalent(newItem.getAmount());
            newItem.setOrderNumber(String.valueOf(Math.abs(random.nextInt())));
            newItem.setBranch("101");
            newItem.setCurrencyType("IRR");
            newItem.setApplicantName("سعید زمانی");
            itemDtoList.add(newItem);
        }
        responseDto.setReportItemDtoList(itemDtoList);
        return responseDto;
    }

    @Override
    public DocumentaryCreditsReportResponseDto documentaryCreditsReport(DocumentaryCreditsReportRequestDto requestDto) {
        DocumentaryCreditsReportResponseDto responseDto = new DocumentaryCreditsReportResponseDto();
        List<DocumentaryCreditsReportItemDto> itemDtoList = new ArrayList<>();
        Random random = new Random();
        for (int i = 1; i <= 10; i++) {
            DocumentaryCreditsReportItemDto newItem = new DocumentaryCreditsReportItemDto();
            newItem.setCreditNumber(String.valueOf(Math.abs(random.nextLong())));
            newItem.setOpeningDate(new Date());
            newItem.setExpireDate(new Date());
            newItem.setAmount(BigDecimal.valueOf(20000000));
            newItem.setOpeningTimeAmount(newItem.getAmount());
            newItem.setCurrencyType("IRR");
            newItem.setCurrencyRate(BigDecimal.valueOf(30000));
            newItem.setCreditType("DURATIONAL");

            itemDtoList.add(newItem);
        }
        responseDto.setReportItemDtoList(itemDtoList);
        return responseDto;
    }

    @Override
    public GuarantyReportResponseDto guarantyReport(GuarantyReportRequestDto requestDto) {
        GuarantyReportResponseDto responseDto = new GuarantyReportResponseDto();
        List<GuarantyReportItemDto> itemDtoList = new ArrayList<>();
        Random random = new Random();
        for (int i = 1; i <= 10; i++) {
            GuarantyReportItemDto newItem = new GuarantyReportItemDto();
            newItem.setGuarantyNumber(String.valueOf(Math.abs(random.nextLong())));
            newItem.setOpeningDate(new Date());
            newItem.setOpeningAmount(BigDecimal.valueOf(20000000));
            newItem.setGuarantyAmount(BigDecimal.valueOf(25000000000L));
            newItem.setCurrencyType("IRR");
            itemDtoList.add(newItem);
        }
        responseDto.setReportItemDtoList(itemDtoList);
        return responseDto;
    }

    @Override
    public IssuedRemittanceReportResponseDto issuedRemittanceReport(IssuedRemittanceReportRequestDto requestDto) {
        IssuedRemittanceReportResponseDto responseDto = new IssuedRemittanceReportResponseDto();
        List<IssuedRemittanceReportItemDto> itemDtoList = new ArrayList<>();
        Random random = new Random();
        for (int i = 1; i <= 10; i++) {
            IssuedRemittanceReportItemDto newItem = new IssuedRemittanceReportItemDto();
            newItem.setRemittanceNumber(String.valueOf(Math.abs(random.nextLong())));
            newItem.setBrokerBank("بانک کارگزار");
            newItem.setBeneficiaryBank("بانک ذینفع");
            newItem.setIssueDate(new Date());
            newItem.setAmount(BigDecimal.valueOf(20000000));
            newItem.setCurrencyRate(BigDecimal.valueOf(23000));
            newItem.setCurrencyType("IRR");
            newItem.setStatus("REGISTERED");
            itemDtoList.add(newItem);
        }
        responseDto.setReportItemDtoList(itemDtoList);
        return responseDto;
    }
}