package com.caspian.ebanking.pars.api.service.business.general.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/13/2020 3:18 PM
 */
@Data
@AllArgsConstructor
public class ResultDto {

    private boolean result;
    private Object data;
    private Date timestamp;

    public ResultDto(boolean result, Object data) {
        this(result, data, new Date());
    }

    public static ResultDto success() {
        return new ResultDto(true, null);
    }

    public static ResultDto failure() {
        return new ResultDto(false, null);
    }

    public static ResultDto success(Object data) {
        return new ResultDto(true, data);
    }

    public static ResultDto failure(Object data) {
        return new ResultDto(false, data);
    }

}
