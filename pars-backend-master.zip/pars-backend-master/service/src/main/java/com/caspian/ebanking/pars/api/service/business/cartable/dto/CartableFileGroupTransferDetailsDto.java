package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۹/۰۱/۲۰۲۱ ۰۴:۲۸ قبل‌ازظهر
 */
@Data
public class CartableFileGroupTransferDetailsDto {
    private Long id;
    private Long groupTransferId;
    private String clientId;
    private String trackingCode;
    private String title;
    private String description;
    private Date effectiveDate;
    private String sourceAccountNumber;
    private Integer clientTotalNumber;
    private BigDecimal clientTotalAmount;
}