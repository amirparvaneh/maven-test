package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class PichakIssueChequeRequestDto {
    private String accountNumber;
    private List<PichakChequePersonDto> receivers;
    private List<WithdrawConditionCustomerItemDto> signers;
    private String withdrawConditionCode;
    private String sayyadId;
    private String amount;
    private Date dueDate;
    private String description;
    private String toIban;
    private String chequeType;
}
