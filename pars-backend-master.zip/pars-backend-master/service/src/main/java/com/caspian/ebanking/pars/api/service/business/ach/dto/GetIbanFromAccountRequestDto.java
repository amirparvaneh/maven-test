package com.caspian.ebanking.pars.api.service.business.ach.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class GetIbanFromAccountRequestDto {
    @NotNull
    @ApiModelProperty(value = "شماره حساب")
    private String depositNumber;

}
