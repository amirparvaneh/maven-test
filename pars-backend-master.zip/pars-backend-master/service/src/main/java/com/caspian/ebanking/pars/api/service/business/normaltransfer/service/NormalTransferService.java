package com.caspian.ebanking.pars.api.service.business.normaltransfer.service;

import com.caspian.ebanking.pars.api.service.business.normaltransfer.dto.*;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/4/2021 12:36 PM
 */
public interface NormalTransferService {
    SingleNormalFundTransferResponseDto singleNormalFundTransfer(SingleNormalFundTransferRequestDto requestDto);

    AutoNormalTransferReportResponseDto autoNormalTransferReport(AutoNormalTransferReportRequestDto requestDto);

    AutoFundTransferResponseDto autoFundTransfer(AutoFundTransferRequestDto requestDto);

}
