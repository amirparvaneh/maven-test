package com.caspian.ebanking.pars.api.service.business.payment.service;


import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.utils.StringUtils;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.payment.dto.*;
import com.caspian.ebanking.pars.api.service.business.payment.utils.PaymentConverterUtils;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.ChPayedBillSearch;
import com.caspian.moderngateway.core.coreservice.dto.epayment.*;
import com.caspian.moderngateway.core.message.GetPayedBillsMsg;
import com.caspian.moderngateway.core.message.PayBillMsg;
import com.caspian.moderngateway.core.message.epayment.*;
import com.caspian.moderngateway.core.message.valuablecustomer.GetVCUserAccountsMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.dto.VCAccountDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Service
@RequiredArgsConstructor
public class PaymentServiceImpl extends BaseService implements PaymentService {

    private final PaymentConverterUtils paymentConverterUtils;
    private final CurrentUserService currentUserService;

    public BillPaymentResponseDto singleBillPayment(BillPaymentRequestDto requestDto) {
        PayBillMsg.Inbound inbound = new PayBillMsg.Inbound();
        inbound.setRequestBean(paymentConverterUtils.convertToBillPaymentRequest(requestDto));
        try {
            PayBillMsg.Outbound outbound = channelManagerProvider.execute(inbound, PayBillMsg.Outbound.class);
            return paymentConverterUtils.convertToBillPaymentResponse(outbound.getResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    public BillPaymentReportResponseDto getPayedBillsReport(BillPaymentReportRequestDto requestDto) {
        GetPayedBillsMsg.Inbound inbound = new GetPayedBillsMsg.Inbound();
        inbound.setPayedBillSearch(mapper.map(requestDto, ChPayedBillSearch.class));
        try {
            GetPayedBillsMsg.Outbound outbound = channelManagerProvider.execute(inbound, GetPayedBillsMsg.Outbound.class);
            return paymentConverterUtils.convertToBillPaymentReportResponse(outbound.getResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public Long addPeriod(PeriodRequestDto requestDto) {
        AddPeriodMsg.Inbound inbound = new AddPeriodMsg.Inbound();
        inbound.setRequestBean(paymentConverterUtils.convertToAddPeriodRequest(requestDto));
        try {
            AddPeriodMsg.Outbound outbound = channelManagerProvider.execute(inbound, AddPeriodMsg.Outbound.class);
            return outbound.getResponseBean().getPeriodId();

        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto removePeriod(Long id) {
        RemovePeriodMsg.Inbound inbound = new RemovePeriodMsg.Inbound();
        ChRemovePeriodRequestBean requestBean = new ChRemovePeriodRequestBean();
        requestBean.setId(id);
        inbound.setRequestBean(requestBean);
        try {
            RemovePeriodMsg.Outbound outbound = channelManagerProvider.execute(inbound, RemovePeriodMsg.Outbound.class);
            if (outbound != null) {
                return ResultDto.success();
            } else {
                return ResultDto.failure();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto updatePeriod(PeriodRequestDto requestDto) {
        UpdatePeriodMsg.Inbound inbound = new UpdatePeriodMsg.Inbound();
        inbound.setRequestBean(paymentConverterUtils.convertToUpdatePeriodRequest(requestDto));
        try {
            UpdatePeriodMsg.Outbound outbound = channelManagerProvider.execute(inbound, UpdatePeriodMsg.Outbound.class);
            if (outbound != null) {
                return ResultDto.success();
            } else {
                return ResultDto.failure();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public LoadPeriodResponseDto loadPeriod(LoadPeriodRequestDto requestDto) {

        LoadPeriodResponseDto result = null;
        if (StringUtils.isNullOrEmpty(requestDto.getAccountId())) {

            GetVCUserAccountsMsg.Inbound inbound =
                    paymentConverterUtils.getUserAccountsConverter(
                            currentUserService.getUsername(), null,
                            currentUserService.getCurrentOrganizationId());
            GetVCUserAccountsMsg.Outbound outbound;
            try {
                outbound = channelManagerProvider.execute(inbound, GetVCUserAccountsMsg.Outbound.class);
            } catch (ChannelManagerException e) {
                throw new GatewayException(e);
            }
            for (VCAccountDTO vcAccount : outbound.getAccounts()) {
                String accNumber = vcAccount.getAccountNumber();
                result = loadPeriodService(accNumber);

            }
        } else {
            result = loadPeriodService(requestDto.getAccountId());
        }
        return result;
    }

    private LoadPeriodResponseDto loadPeriodService(String accountNumber) {
        LoadPeriodsMsg.Inbound loadInbound = new LoadPeriodsMsg.Inbound();
        ChLoadPeriodsRequestBean requestBean = new ChLoadPeriodsRequestBean();
        requestBean.setAccountId(accountNumber);
        loadInbound.setRequestBean(requestBean);
        try {
            LoadPeriodsMsg.Outbound result = channelManagerProvider.execute(loadInbound, LoadPeriodsMsg.Outbound.class);
            return paymentConverterUtils.convertToLoadPeriodResponse(result.getResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public LoadPeriodHistoryResponseDto loadPeriodHistory(Long id) {
        LoadPeriodHistoryMsg.Inbound loadInbound = new LoadPeriodHistoryMsg.Inbound();
        ChLoadPeriodHistoryRequestBean requestBean = new ChLoadPeriodHistoryRequestBean();
        requestBean.setId(id);
        loadInbound.setRequestBean(requestBean);
        try {
            LoadPeriodHistoryMsg.Outbound result = channelManagerProvider.execute(loadInbound, LoadPeriodHistoryMsg.Outbound.class);
            return paymentConverterUtils.convertToLoadPeriodHistoryResponse(result.getResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public AddPeriodPersonResponseDto addPeriodPerson(AddPeriodPersonRequestDto requestDto) {
        AddPeriodPersonsMsg.Inbound inbound = new AddPeriodPersonsMsg.Inbound();
        ChAddPeriodPersonRequestBeanList beanList = new ChAddPeriodPersonRequestBeanList();
        List<ChAddPeriodPersonRequestBean> requestBean = mapper.mapList(requestDto.getPeriodPersonRequestDtoList(), ChAddPeriodPersonRequestBean.class);
        beanList.setRequestBeans(requestBean);
        inbound.setRequestBean(beanList);
        try {
            AddPeriodPersonsMsg.Outbound result = channelManagerProvider.execute(inbound, AddPeriodPersonsMsg.Outbound.class);
            AddPeriodPersonResponseDto responseDto = new AddPeriodPersonResponseDto();
            responseDto.setPeriodDtoList(mapper.mapList(result.getResponseBeans(), PeriodPersonResponseDto.class));
            return responseDto;
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto removePeriodPerson(Long id) {
        RemovePeriodPersonMsg.Inbound inbound = new RemovePeriodPersonMsg.Inbound();
        ChPeriodPersonIdRequestBean requestBean = new ChPeriodPersonIdRequestBean();
        requestBean.setId(id);
        inbound.setRequestBean(requestBean);
        try {
            RemovePeriodPersonMsg.Outbound outbound = channelManagerProvider.execute(inbound, RemovePeriodPersonMsg.Outbound.class);
            if (outbound != null) {
                return ResultDto.success();
            } else {
                return ResultDto.failure();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto updatePeriodPerson(PeriodPersonRequestDto requestDto) {
        UpdatePeriodPersonMsg.Inbound inbound = new UpdatePeriodPersonMsg.Inbound();
        inbound.setRequestBean(mapper.map(requestDto, ChUpdatePeriodPersonRequestBean.class));
        try {
            UpdatePeriodPersonMsg.Outbound outbound = channelManagerProvider.execute(inbound, UpdatePeriodPersonMsg.Outbound.class);
            if (outbound != null) {
                return ResultDto.success();
            } else {
                return ResultDto.failure();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto inactivePeriodPerson(Long id) {
        InactivePeriodPersonMsg.Inbound inbound = new InactivePeriodPersonMsg.Inbound();
        ChPeriodPersonIdRequestBean requestBean = new ChPeriodPersonIdRequestBean();
        requestBean.setId(id);
        inbound.setRequestBean(requestBean);
        try {
            InactivePeriodPersonMsg.Outbound outbound = channelManagerProvider.execute(inbound, InactivePeriodPersonMsg.Outbound.class);
            if (outbound != null) {
                return ResultDto.success();
            } else {
                return ResultDto.failure();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public LoadPeriodPersonResponseDto loadPeriodPerson(LoadPeriodPersonRequestDto requestDto) {
        LoadPeriodPersonsMsg.Inbound inbound = new LoadPeriodPersonsMsg.Inbound();
        ChLoadPeriodPersonsRequestBean requestBean = new ChLoadPeriodPersonsRequestBean();

        inbound.setRequestBean(requestBean);
        try {
            LoadPeriodPersonsMsg.Outbound result = channelManagerProvider.execute(inbound, LoadPeriodPersonsMsg.Outbound.class);
            LoadPeriodPersonResponseDto responseDto = new LoadPeriodPersonResponseDto();
            responseDto.setPeriodPersonDtoList(mapper.mapList(result.getResponseBean().getPeriodPersonBeans(), LoadPeriodPersonDto.class));
            return responseDto;
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }
}