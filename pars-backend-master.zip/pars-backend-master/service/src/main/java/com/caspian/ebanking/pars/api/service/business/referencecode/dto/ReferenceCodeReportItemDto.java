package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۲/۰۲/۲۰۲۱ ۱۲:۵۷ بعدازظهر
 */
@Data
public class ReferenceCodeReportItemDto {
    @ApiModelProperty(value = "شناسه واریز")
    private String referenceCode;

    @ApiModelProperty(value = "نوع شناسه", allowableValues = " CONTINUES,TEMPORARY,MIXED")
    private Character referenceType;

    @ApiModelProperty(value = "کد عملیات")
    private String operationCode;

    private String operationTitle;

    @ApiModelProperty(value = "واریز کننده")
    private String liquidator;

    @ApiModelProperty(value = "تولید کننده")
    private String creator;
    private String phoneNumber;
    private BigDecimal amount;
    private Date createDate;
    private Integer status;
    private Long staticAutoRefId;
    private String settleTitleCode;

    @ApiModelProperty(value = "عنوان واریز")
    private String settleTitle;
    private Date expireDate;
    private Long numberOfRefCode;
}