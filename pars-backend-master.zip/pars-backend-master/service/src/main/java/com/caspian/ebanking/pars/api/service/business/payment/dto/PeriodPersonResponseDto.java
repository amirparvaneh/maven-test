package com.caspian.ebanking.pars.api.service.business.payment.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/09/2021 07:18 PM
 */
@Data
public class PeriodPersonResponseDto {
    @ApiModelProperty(value = "نام شخص /شرکت")
    private String firstName;
    @ApiModelProperty(value = "نام خانوادگی")
    private String lastName;
    @ApiModelProperty(value = "مبلغ")
    private Long amount;
    @ApiModelProperty(value = "محل ثبت")
    private String registrationPlace;
    @ApiModelProperty(value = "کد ملی")
    private String nationalCode;
    @ApiModelProperty(value = "شماره موبایل")
    private String mobileNo;
    @ApiModelProperty(value = "وضعیت ثبت")
    private String registerStatus;
    @ApiModelProperty(value = "علت")
    private String reasons;
    @ApiModelProperty(value = "کد سهامداری")
    private String stocksCode;
    @ApiModelProperty(value = "شماره حواله")
    private String orderNo;
    @ApiModelProperty(value = "شماره شناسایی")
    private String idNo;
    @ApiModelProperty(value = "نوع مشتری")
    private Integer personType;
}