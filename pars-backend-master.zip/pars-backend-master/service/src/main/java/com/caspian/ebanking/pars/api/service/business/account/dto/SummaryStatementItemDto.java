package com.caspian.ebanking.pars.api.service.business.account.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
@ApiModel
public class SummaryStatementItemDto {
    @ApiModelProperty(value = "دوره زمانی")
    private String PeriodType;

    @ApiModelProperty(value = "از تاریخ")
    private Date fromDate;

    @ApiModelProperty(value = "تا تاریخ")
    private Date toDate;

    @ApiModelProperty("مبلغ")
    private BigDecimal amount;

    @ApiModelProperty("توع تراکنش")
    private String transactionType;
}
