package com.caspian.ebanking.pars.api.service.business.account;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.utils.DateUtils;
import com.caspian.ebanking.pars.api.base.utils.StringUtils;
import com.caspian.ebanking.pars.api.service.business.account.dto.IbanInquiryByCentralBankResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.SetCustomerDepositDetailRequestDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.StatementRequestDto;
import com.caspian.moderngateway.core.channelmanagerserviceaggregator.dto.ChAccountOwner;
import com.caspian.moderngateway.core.channelmanagerserviceaggregator.dto.ChCBIbanInquiryResponseBean;
import com.caspian.moderngateway.core.channelmanagerserviceaggregator.dto.ChCBPaymentIDCheckResponseBean;
import lombok.RequiredArgsConstructor;
import com.caspian.moderngateway.core.coreservice.dto.ChActionType;
import com.caspian.moderngateway.core.coreservice.dto.ChDepositSearchRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.ChOrderStatus;
import com.caspian.moderngateway.core.coreservice.dto.ChStatementSearchRequestBean;
import com.caspian.moderngateway.core.domainmodel.dto.deposit.ChDepositDetail;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/28/2020 1:55 PM
 */
@Service
@RequiredArgsConstructor
public class AccountConverterUtils {

 private final ParsModelMapper mapper;

    /**
     * This method used to preparing Inbound message of Channel Manager(ModernGatewayLimitRequestBean object) by client side parameters
     *
     * @param serviceCode input parameter to get type of service name or service code
     * @return is a ModernGatewayLimitRequestBean object after filling by received parameters
     */
    public ChDepositSearchRequestBean.ServicesCode getServiceCode(String serviceCode) {
        if (serviceCode != null) {
            if (serviceCode.equals("NORMAL_TRANSFER")) {
                return ChDepositSearchRequestBean.ServicesCode.NORMAL_TRANSFER;
            } else if (serviceCode.equals("CARD_TRANSFER")) {
                return ChDepositSearchRequestBean.ServicesCode.CARD_TRANSFER;
            } else if (serviceCode.equals("ACH_NORMAL_TRANSFER")) {
                return ChDepositSearchRequestBean.ServicesCode.ACH_NORMAL_TRANSFER;
            } else if (serviceCode.equals("RTGS_NORMAL_TRANSFER")) {
                return ChDepositSearchRequestBean.ServicesCode.RTGS_NORMAL_TRANSFER;
            } else if (serviceCode.equals("GET_STATEMENT")) {
                return ChDepositSearchRequestBean.ServicesCode.GET_STATEMENT;
            } else if (serviceCode.equals("GET_DEPOSITS")) {
                return ChDepositSearchRequestBean.ServicesCode.GET_DEPOSITS;
            } else if (serviceCode.equals("BILL_PAYMENT_BY_ACCOUNT")) {
                return ChDepositSearchRequestBean.ServicesCode.BILL_PAYMENT_BY_ACCOUNT;
            } else if (serviceCode.equals("ADD_PERIOD_PERSONS")) {
                return ChDepositSearchRequestBean.ServicesCode.ADD_PERIOD_PERSONS;
            } else if (serviceCode.equals("OFFLINE_STATEMENT_REQUEST")) {
                return ChDepositSearchRequestBean.ServicesCode.OFFLINE_STATEMENT_REQUEST;
            } else if (serviceCode.equals("BATCH_BILL_PAYMENT_BY_ACCOUNT")) {
                return ChDepositSearchRequestBean.ServicesCode.BATCH_BILL_PAYMENT_BY_ACCOUNT;
            } else if (serviceCode.equals("REFERENCE_CODE_STATEMENT_BY_CHEQUE")) {
                return ChDepositSearchRequestBean.ServicesCode.REFERENCE_CODE_STATEMENT_BY_CHEQUE;
            } else if (serviceCode.equals("TRANSFER_CHEQUE_LIST")) {
                return ChDepositSearchRequestBean.ServicesCode.TRANSFER_CHEQUE_LIST;
            } else if (serviceCode.equals("STATEMENT_WITH_REFERENCE_CODE_REPORT")) {
                return ChDepositSearchRequestBean.ServicesCode.STATEMENT_WITH_REFERENCE_CODE_REPORT;
            } else if (serviceCode.equals("PERIOD_LIST")) {
                return ChDepositSearchRequestBean.ServicesCode.PERIOD_LIST;
            } else if (serviceCode.equals("LOAD_PERIOD_PERSONS")) {
                return ChDepositSearchRequestBean.ServicesCode.LOAD_PERIOD_PERSONS;
            } else if (serviceCode.equals("OFFLINE_STATEMENT_REQUEST_WITH_PAYMENT_ID")) {
                return ChDepositSearchRequestBean.ServicesCode.OFFLINE_STATEMENT_REQUEST_WITH_PAYMENT_ID;
            } else if (serviceCode.equals("PAY_BILL_BY_ACCOUNT")) {
                return ChDepositSearchRequestBean.ServicesCode.PAY_BILL_BY_ACCOUNT;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    //TODO, WILL USE MAPPER LATER
    public ChStatementSearchRequestBean convertNormalStatementRequestDto(StatementRequestDto requestDto) {
        ChStatementSearchRequestBean criteria = new ChStatementSearchRequestBean();

        criteria.setDepositNumber(requestDto.getAccountNumber());

        if (!StringUtils.isNullOrEmpty(requestDto.getOrderType())) {
            criteria.setOrder(ChOrderStatus.fromValue(requestDto.getOrderType()));
        }

        criteria.setOffset(requestDto.getFromRow());
        criteria.setLength(requestDto.getToRow());

        criteria.setFromDate(DateUtils.getTimeValue(requestDto.getFromDate(), 0, 0, 0));
        criteria.setToDate(DateUtils.getTimeValue(requestDto.getToDate(), 23, 59, 59));
        criteria.setFromDateTime(DateUtils.getTimeValue(requestDto.getFromDateTime(), 0, 0, 0));
        criteria.setToDateTime(DateUtils.getTimeValue(requestDto.getToDateTime(), 23, 59, 59));

        criteria.setFromAmount(requestDto.getFromAmount());
        criteria.setToAmount(requestDto.getToAmount());

        if (!StringUtils.isNullOrEmpty(requestDto.getActionType()) && !requestDto.getActionType().equals("BOTH")) {
            criteria.setAction(Enum.valueOf(ChActionType.class, requestDto.getActionType()));
        }

        criteria.setDescription(requestDto.getDescription());
        criteria.setCustomerDescription(requestDto.getCustomerDescription());
        criteria.setSerialNumber(requestDto.getChequeSerial());
        criteria.setSerial(requestDto.getReceiptNo());

        return criteria;
    }

    public ChDepositDetail convertCustomerDepositDetails(SetCustomerDepositDetailRequestDto requestDto) {

        ChDepositDetail requestBean = new ChDepositDetail();
        requestBean.setSerial(requestDto.getSerial());
        requestBean.setDate(DateUtils.getTimeValue(requestDto.getDate(), 0, 0, 0));
        requestBean.setSequence(0);
        requestBean.setDescription(requestDto.getCustomerDescription());

        //branch code - branch name
        String branchCode = requestDto.getBranchCode();
        if (branchCode.contains("-")) {
            branchCode = branchCode.split("-")[0].trim();
        }
        requestBean.setBranchCode(branchCode);

        return requestBean;
    }

    public IbanInquiryByCentralBankResponseDto IbanEnquiryByCBConverter(ChCBIbanInquiryResponseBean responseBean) {
        if (responseBean == null ||
                responseBean.getChAccountOwners() == null ||
                responseBean.getChAccountOwners().size() == 0) {
            return null;
        }
        IbanInquiryByCentralBankResponseDto responseDto;
        responseDto = mapper.map(responseBean, IbanInquiryByCentralBankResponseDto.class);

        return getIbanInquiry(responseBean.getChAccountOwners(), responseDto);

    }

    private IbanInquiryByCentralBankResponseDto getIbanInquiry(List<ChAccountOwner> accountOwners, IbanInquiryByCentralBankResponseDto responseDto) {
        if (accountOwners.size() == 1) {
            if (accountOwners.get(0).getFirstName().isEmpty() &&
                    accountOwners.get(0).getLastName().isEmpty()) return null;

            responseDto.setOwnerName(accountOwners.get(0).getFirstName().trim());
            responseDto.setOwnerFamily(accountOwners.get(0).getLastName().trim());
            //Joint deposit
        } else {
            final StringBuilder sb = new StringBuilder();
            for (ChAccountOwner owner : accountOwners) {
                if (owner.getFirstName().trim().isEmpty() && owner.getLastName().trim().isEmpty()) continue;

                sb.append(sb.length() == 0 ? "" : " , ")
                        .append(owner.getFirstName().trim())
                        .append(owner.getLastName().trim());

            }
            if (sb.length() == 0) return null;
            responseDto.setAccountOwners(sb.toString());
        }
        return responseDto;
    }

    public IbanInquiryByCentralBankResponseDto cbPaymentIDCheckConverter(ChCBPaymentIDCheckResponseBean responseBean) {
        if (responseBean == null ||
                responseBean.getAccountOwner() == null ||
                responseBean.getAccountOwner().size() == 0) {
            return null;
        }
        IbanInquiryByCentralBankResponseDto responseDto;
        responseDto = mapper.map(responseBean, IbanInquiryByCentralBankResponseDto.class);

        return getIbanInquiry(responseBean.getAccountOwner(), responseDto);
    }
}