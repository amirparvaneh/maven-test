package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import com.caspian.moderngateway.core.coreservice.constant.GroupTransferFileStatus;
import lombok.Data;

/**
 * @author atousa khanjani
 * @since 01/27/2021 07:34 PM
 */
@Data
public class GroupTransferFileDto {
    private Long id;
    private Long groupTransferId;
    private String clientFileName;
    private String fileName;
    private String clientCheksum;
    private GroupTransferFileStatus fileStatus;
}
