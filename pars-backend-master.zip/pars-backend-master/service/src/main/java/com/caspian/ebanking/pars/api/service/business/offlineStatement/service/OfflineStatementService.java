package com.caspian.ebanking.pars.api.service.business.offlineStatement.service;

import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementReportResponseDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementRequestDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementResponseDto;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChOfflineStatementType;

import javax.servlet.http.HttpServletResponse;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۴/۰۱/۲۰۲۱ ۰۸:۵۴ قبل‌ازظهر
 */
public interface OfflineStatementService {
    OfflineStatementResponseDto offlineStatementRequest(OfflineStatementRequestDto requestDto, ChOfflineStatementType offlineStatementType);

    OfflineStatementReportResponseDto getOfflineStatementReport(Date fromDate, Date toDate ,ChOfflineStatementType offlineStatementType);

    void downloadOfflineStatementFile(Long requestId, String fileType, HttpServletResponse response);


}
