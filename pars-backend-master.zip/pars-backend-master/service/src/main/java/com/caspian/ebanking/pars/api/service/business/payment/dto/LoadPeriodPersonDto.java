package com.caspian.ebanking.pars.api.service.business.payment.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/07/2021 07:18 PM
 */
@Data
public class LoadPeriodPersonDto {
    @ApiModelProperty(value = "نام")
    private String firstName;
    @ApiModelProperty(value = "نام خانوادگی")
    private String lastName;
    @ApiModelProperty(value = "کد ملی")
    private String nationalCode;
    @ApiModelProperty(value = "مبلغ")
    private Long amount;
    @ApiModelProperty(value = "وضعبت")
    private Integer status;
    @ApiModelProperty(value = "تاریخ پرداخت")
    private Date paymentDate;
    @ApiModelProperty(value = "نحوه پرداخت ", allowableValues = "چک رمذ دار=5,ساتنا=5,پایا=3,انتقالی=2,نقدی=1")
    private Integer channelPayment;
    @ApiModelProperty(value = "نام شعبه")
    private String branchName;

}