package com.caspian.ebanking.pars.api.service.business.ach.service;

import com.caspian.ebanking.pars.api.service.business.account.dto.GetDestinationIbanResponseDto;
import com.caspian.ebanking.pars.api.service.business.account.dto.GetSourceAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.ach.dto.*;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;

/**
 * @author Atousa Khanjani
 * @author Amir Tajik
 * @version 1.0
 * @since 1/4/2021 12:14 PM
 */
public interface AchService {
    ResultDto cancelAchTransaction(CancelAchTransactionRequestDto requestDto);

    AchTransactionReportResponseDto achTransactionReport(AchTransactionReportRequestDto requestDto);

    AchTransferReportResponseDto achTransferReport(AchTransferReportRequestDto requestDto);

    AchSingleTransferResponseDto achSingleTransfer(AchSingleTransferRequestDto requestDto);

    ResultDto cancelAchRequest(CancelAchRequestDto requestDto);





}
