package com.caspian.ebanking.pars.api.service.business.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/28/2020 2:02 PM
 */
@Data
@AllArgsConstructor
public class GetUserAccountsResponseDto {
    private List<UserAccountDto> accountDtoList;
}
