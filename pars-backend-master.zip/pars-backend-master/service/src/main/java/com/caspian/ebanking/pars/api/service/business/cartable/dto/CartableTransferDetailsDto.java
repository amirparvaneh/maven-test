package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۸/۰۱/۲۰۲۱ ۱۱:۲۱ بعدازظهر
 */
@Data
public class CartableTransferDetailsDto {
    private Long id;
    private String toAccount;
    private String narrative;
    private String destinationNarrative;
    private BigDecimal amount;
    private Long version;
}