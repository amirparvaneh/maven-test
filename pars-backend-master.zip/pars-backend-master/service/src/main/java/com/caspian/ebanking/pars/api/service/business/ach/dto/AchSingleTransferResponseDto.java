package com.caspian.ebanking.pars.api.service.business.ach.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author atousa khanjani
 * @since 12/29/2020 07:34 PM
 */
@Data
public class AchSingleTransferResponseDto {
    private String transferDescription;
    private String referenceId;
    private String sourceIbanNumber;
    private String currency;
    private String transferStatus;
    private String ibanNumber;
    private String ownerName;
    private String factorNumber;
    private BigDecimal amount;
    private String description;
    private String transactionStatus;
    private String transactionDate;
}
