package com.caspian.ebanking.pars.api.service.business.normaltransfer.dto;

import lombok.Data;

import java.util.Date;

/**
 * @author atousa khanjani
 * @since 01/27/2021 07:34 PM
 */
@Data
public class AutoFundTransferResponseDto {
    private String serialNumber;
    private Date transactionDate;

}