package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۷/۰۲/۲۰۲۱ ۰۹:۱۷ قبل‌ازظهر
 */
@Data
public class BlockChequeResponseItemDto {
    @ApiModelProperty(value = "وضعیت انسداد", allowableValues = "SUCCESSFULlY,NOT_FOUND,INVALID_STATE")
    private String blockingStatus;
    private String chequeNumber;
}