package com.caspian.ebanking.pars.api.service.business.user.dto;

import com.caspian.ebanking.pars.api.base.security.dto.Menu;
import com.caspian.ebanking.pars.api.base.security.dto.OrganizationRelDto;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/21/2020 10:47 AM
 */
@Data
@AllArgsConstructor
public class LoginResponseDto {
    private String token;
    private Menu menu;
    private List<OrganizationRelDto> organizations;
}
