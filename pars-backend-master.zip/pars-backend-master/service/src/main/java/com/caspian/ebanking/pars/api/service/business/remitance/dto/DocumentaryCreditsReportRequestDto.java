package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۰۱:۰۴ بعدازظهر
 */
@Data
public class DocumentaryCreditsReportRequestDto {
    private String creditNumber;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "از تاریخ گشایش")
    private Date fromOpeningDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تا تاریخ گشایش")
    private Date toOpeningDate;

    private BigDecimal fromAmount;

    private BigDecimal toAmount;

    @ApiModelProperty(value = "وضعیت",allowableValues = "REGIGSTERD,READY_FOR_ACCEPT,CONFIRMED")
    private String status;

    @ApiModelProperty(value = "شماره ثبت سفارش")
    private String orderNumber;

    @ApiModelProperty(value = "نوع ارز",allowableValues = "IRR,USD")
    private String currencyType;

    private String branch;

    @ApiModelProperty(value = "نوع اعتبار",allowableValues = "DURATIONAL,VISUAL")
    private String creditType;
}