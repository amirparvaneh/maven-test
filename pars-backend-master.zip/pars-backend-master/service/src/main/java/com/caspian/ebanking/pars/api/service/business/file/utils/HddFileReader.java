package com.caspian.ebanking.pars.api.service.business.file.utils;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.*;

@Component
public class HddFileReader {
    private static final Logger log = Logger.getLogger(HddFileReader.class);

    public static int readFileSize(String path) {
        File file = new File(path);
        return (int) file.length();
    }

    public static byte[] read(String path) {
        String basePath = FileReaderWriterModel.getInstance().getLoadedBasePath();
        int fileSize = readFileSize(basePath + path);
        if (fileSize <= 0)
            return null;
        byte[] result = new byte[fileSize];
        FileInputStream fileInputStream = null;
        InputStream fileInput = null;
        try {
            fileInputStream = new FileInputStream(basePath + path);
            fileInput = new BufferedInputStream(fileInputStream);
            int totalBytesRead = 0;
            while (totalBytesRead < result.length) {
                int bytesRemaining = result.length - totalBytesRead;
                //input.read() returns -1, 0, or more :
                int bytesRead = fileInput.read(result, totalBytesRead, bytesRemaining);
                if (bytesRead > 0) {
                    totalBytesRead = totalBytesRead + bytesRead;
                }
            }
        } catch (IOException e) {
            log.error(e);
            result = null;
            return null;
        } finally {
            try {
                if (fileInput != null)
                    fileInput.close();
                if (fileInputStream != null)
                    fileInputStream.close();
            } catch (IOException e) {
                log.error(e);
            }
        }
        return result;
    }
}
