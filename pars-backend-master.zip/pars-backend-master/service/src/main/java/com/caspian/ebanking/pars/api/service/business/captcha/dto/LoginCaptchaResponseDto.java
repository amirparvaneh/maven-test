package com.caspian.ebanking.pars.api.service.business.captcha.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 4:15 PM
 */
@Data
@AllArgsConstructor
public class LoginCaptchaResponseDto {
    private String captcha;
    private String challengeKey;
}
