package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
@AllArgsConstructor
public class RejectChequeCartableResponseDto {
    private boolean result;
}
