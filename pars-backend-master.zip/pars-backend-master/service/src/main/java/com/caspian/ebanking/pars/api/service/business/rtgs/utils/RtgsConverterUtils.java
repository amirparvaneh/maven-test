package com.caspian.ebanking.pars.api.service.business.rtgs.utils;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.service.business.rtgs.dto.*;
import com.caspian.moderngateway.core.coreservice.dto.*;
import com.caspian.moderngateway.core.security.dto.ChSecondPasswordType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۴/۰۱/۲۰۲۱ ۰۱:۱۶ بعدازظهر
 */
@Component
@RequiredArgsConstructor
public class RtgsConverterUtils {
    private final ParsModelMapper mapper;

    public static ChRtgsNormalTransferRequestBean convertToRtgsSingleTransferRequest(RtgsSingleTransferRequestDto requestDto) {
        ChRtgsNormalTransferRequestBean requestBean = new ChRtgsNormalTransferRequestBean();
        requestBean.setAmount(requestDto.getAmount());
        requestBean.setSourceDepositNumber(requestDto.getSourceDepositNumber());
        requestBean.setReceiverName(requestDto.getReceiverName());
        requestBean.setReceiverFamily(requestDto.getReceiverFamily());
        requestBean.setReceiverTelephoneNumber(requestDto.getReceiverTelephoneNumber());
        requestBean.setDestinationIbanNumber(requestDto.getDestinationIbanNumber());
        requestBean.setFactorNumber(requestDto.getFactorNumber());
        requestBean.setDescription(requestDto.getDescription());
        requestBean.setSecondPassword(requestDto.getSecondPassword());
        requestBean.setChSecondPasswordType(ChSecondPasswordType.valueOf(requestDto.getPasswordType()));
        requestBean.setEmail("");
        return requestBean;
    }

    public static RtgsTransferReportResponseDto convertToRtgsTransferReportResponse(ChRtgsTransferResponseBean responseBean) {
        RtgsTransferReportResponseDto responseDto = new RtgsTransferReportResponseDto();
        if (responseBean.getTotalRecord() == null) {
            return responseDto;
        }
        responseBean.setTotalRecord(responseBean.getTotalRecord());
        List<RtgsTransferReportItemDto> details = new ArrayList<>();
        RtgsTransferReportItemDto detail;
        for (ChTransferDetailBean detailBean : responseBean.getTransferDetailsDtos()) {
            detail = new RtgsTransferReportItemDto();
            detail.setSerial(detailBean.getSerial());
            detail.setDestinationDepositNumber(detailBean.getDestinationDepositNumber());
            if (detailBean.getDestinationBank() != null) {
                detail.setDestinationBankCode(detailBean.getDestinationBank().getCode() != null ? detailBean.getDestinationBank().getCode().toString() : "");
                detail.setDestinationBankName(detailBean.getDestinationBank().getName() != null ? detailBean.getDestinationBank().getName() : "");
            }
            detail.setAmount(detailBean.getAmount());
            detail.setSourceDepositNumber(detailBean.getSourceDepositNumber());

            if (detailBean.getStatus() != null)
                detail.setStatus(detailBean.getStatus().value());

            if (detailBean.getSystemCode() != null)
                detail.setSystemCode(detailBean.getSystemCode().value());

            detail.setRegisterDate(detailBean.getRegisterDate());
            detail.setBranchCode(detailBean.getBranchCode());
            detail.setBranchName(detailBean.getBranchName());

            details.add(detail);
        }
        responseDto.setTransferDetailsDtos(details);
        return responseDto;
    }

    public static RtgsTransactionReportResponseDto convertToRtgsTransactionReportResponse(ChRtgsTransferDetailResponseBean responseBean) {
        RtgsTransactionReportResponseDto responseDto = new RtgsTransactionReportResponseDto();
        if (responseBean.getStatusDtos() == null) {
            return responseDto;
        }
        responseDto.setTotalRecord(responseBean.getTotalRecord());
        List<RtgsTransactionReportItemDto> details = new ArrayList<>();
        RtgsTransactionReportItemDto detail;
        for (ChStatusBean entry : responseBean.getStatusDtos()) {
            detail = new RtgsTransactionReportItemDto();
            detail.setActionType(entry.getActionType() != null ? entry.getActionType().toString() : null);
            detail.setDate(entry.getDate());
            detail.setSerial(entry.getSerial());

            details.add(detail);
        }
        return responseDto;
    }
}
