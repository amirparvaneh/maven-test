package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۲/۰۲/۲۰۲۱ ۱۲:۵۵ بعدازظهر
 */
@Data
public class ReferenceCodeReportRequestDto {
    @ApiModelProperty(value = "نوع شناسه", allowableValues = " CONTINUES,TEMPORARY,MIXED")
    private String referenceType;
    @NotNull
    @ApiModelProperty(value = "کد عناوین واریز")
    private String settleTitleCodes;
    @ApiModelProperty(value = "واریز کننده")
    private String liquidator;
    private BigDecimal fromAmount;
    private BigDecimal toAmount;
    private String phoneNumber;
    @NotNull
    @ApiModelProperty(value = "شناسه واریز")
    private String referenceCode;
    private Date fromDate;
    private Date toDate;
}