package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import com.caspian.moderngateway.core.message.dto.CartableApprovalRequestDto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;
/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 01/21/2021 9:53 AM
 */
@Data
public class SingleCartableAchOrderTransferResponseDto {
    private Long id;
    @ApiModelProperty(value = "شماره پیگیری")
    private String requestCode;
    @ApiModelProperty(value = "تاریخ درخواست")
    private Date requestDate;
    @ApiModelProperty(value = "تاریخ انقضا")
    private Date expireDate;
    @ApiModelProperty(value = "یادداشت فرستنده")
    private String description;
    @ApiModelProperty(name = "اولویت", allowableValues = "M,C,I,T", notes = "(1: MAJOR, 2: CRITICAL, 3: MINOR, 4: TRIVIAL)")
    private Character priority;
    @ApiModelProperty(value = "برداشت از")
    private String accountNumber;
    @ApiModelProperty(name = "وضعیت", allowableValues = "R,C,J,D,S,U,X", notes = "(R: REGISTERED, C: CONFORMED, R: REJECTED, C: CANCELED,S:SUCCEEDED,U:UNSUCCESSFUL,X:EXPIRED)")
    private Character status;
    private CartableAchOrderTransferEntry transferRequestEntryDto;
    @ApiModelProperty(value = "شرایط برداشت")
    private String withdrawConditionCode;
    private List<CartableApprovalRequestDto> cartableApprovalRequestDtos;
    private Date updateSysDate;
}