package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class ChequeCartableRequestDto {

    public static class STATUS {
        public static final Character REGISTERED = 'R';
        public static final Character CONFORMED = 'C';
        public static final Character REJECTED = 'J';
        public static final Character CANCELED = 'D';
        public static final Character SUCCEEDED = 'S';
        public static final Character UNSUCCESSFUL = 'U';
        public static final Character EXPIRED = 'X';
    }

    private Long id;
    private String customerNo;
    private String accountNumber;
    private String requestCode;
    private Character chequeRequestStatus;
    private Long creditConditionId;
    private String sayadId;
    private String toIban;
    private BigDecimal amount;
    private Date dueDate;
    private String description;
    private String chequeType;
    private String chequeMediaType;
    private String currencyCode;
}
