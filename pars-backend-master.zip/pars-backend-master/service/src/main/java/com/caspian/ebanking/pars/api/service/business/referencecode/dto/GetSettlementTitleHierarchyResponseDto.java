package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۱/۰۲/۲۰۲۱ ۰۵:۰۷ بعدازظهر
 */
@Data
public class GetSettlementTitleHierarchyResponseDto {
    private List<SettlementTitleHierarchyItemDto> itemDtoList;
}