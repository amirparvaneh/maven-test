package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.Data;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class ChequeCartableSignerDto {
    private Long id;
    private Long chequeCartableRequestId;
    private String customerNo;
    private Long conditionId;
    private Integer place;
    private Integer signNeedNo;
    private Boolean isStamp;
    private String clientTitle;
}
