package com.caspian.ebanking.pars.api.service.business.ach.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class AchTransferReportItemDto {
  private boolean acceptable;
  private boolean cancelable;
  private Date confirmExpireDate;
  private String currency;
  private String referenceId;
  private Date registerDate;
  private boolean resumeable;
  private String sourceDepositNumber;
  private String status;
  private boolean suspendable;
  private String transferDescription;
  private BigDecimal totalDebitAmount;
  private List<AchTransferDetailsDto> detailsDtoList;
}
