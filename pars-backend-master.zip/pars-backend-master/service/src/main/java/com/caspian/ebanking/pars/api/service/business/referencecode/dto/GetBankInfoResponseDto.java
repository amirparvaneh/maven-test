package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/03/2021 11:38 PM
 */
@Data
public class GetBankInfoResponseDto {
    @ApiModelProperty(value = "لیست اطلاعات شعب")
    private List<BankInfoDto> banks;
    private Long totalRecord;
}
