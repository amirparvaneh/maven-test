package com.caspian.ebanking.pars.api.service.business.file.utils;


import com.caspian.ebanking.pars.api.service.business.offlineStatement.enums.ReportFileType;

import javax.annotation.Nullable;

public final class FileStringUtils {

    private FileStringUtils() {
    }
    public static String fixFileName(String s, @Nullable ReportFileType t) {
        String toRet = new String(s);
        toRet = toRet.replace("/", "")
                .replace("\\", "");

        if (t != null) {
            toRet = toRet
                    .replace(".", "")
                    .concat(ReportFileType.getFullExtension(t));
        }
        return toRet;
    }


}