package com.caspian.ebanking.pars.api.service.business.account.exception;

/**
 * @author atousa khanjani
 * @since 01/09/2021 07:34 PM
 */
public class DepartmentAccountException extends RuntimeException {
    public DepartmentAccountException() {
    }

    public DepartmentAccountException(String message) {
        super(message);
    }

    public DepartmentAccountException(String message, Throwable cause) {
        super(message, cause);
    }

    public DepartmentAccountException(Throwable cause) {
        super(cause);
    }

    public DepartmentAccountException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
