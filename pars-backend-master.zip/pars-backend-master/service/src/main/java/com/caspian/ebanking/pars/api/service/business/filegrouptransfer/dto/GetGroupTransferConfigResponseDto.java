package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import lombok.Data;

@Data
public class GetGroupTransferConfigResponseDto {
    private boolean isRequiredAmountAndCount;
}
