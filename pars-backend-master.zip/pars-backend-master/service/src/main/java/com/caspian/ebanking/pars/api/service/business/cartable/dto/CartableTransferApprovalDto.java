package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۸/۰۱/۲۰۲۱ ۱۱:۱۸ بعدازظهر
 */
@Data
public class CartableTransferApprovalDto {
    private Long id;
    private Long clientId;
    private String clientName;
    private Character status;
    private String description;
    private Long version;
}