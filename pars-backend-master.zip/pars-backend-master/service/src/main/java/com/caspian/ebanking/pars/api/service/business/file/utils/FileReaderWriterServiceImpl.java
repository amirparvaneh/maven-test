package com.caspian.ebanking.pars.api.service.business.file.utils;

import com.caspian.ebanking.pars.api.service.business.file.dto.ClientFileDto;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

@Service
public class FileReaderWriterServiceImpl implements FileReaderWriterService {

    private static final Logger log = Logger.getLogger(FileReaderWriterServiceImpl.class);
    //    private static final String basePath = FileUtils.fixPath(FileReaderWriterModel.getInstance().getLoadedBasePath());
    private ClientFileDto file;

    public String getFileReaderWriterPath() {
        FileReaderWriterModel readerWriterModel = FileReaderWriterModel.getInstance();
        return readerWriterModel.getLoadedBasePath();
    }

    @Override
    public String writeToFile(ClientFileDto fileModel, ByteArrayOutputStream outputStream) {
        FileReaderWriterModel readerWriterModel = FileReaderWriterModel.getInstance();
        file = fileModel;
        if (FileReaderWriterModel.ReaderWriterType.HDD == readerWriterModel.getReaderWriterType())
            return writeToHDD(outputStream);
        else
            return writeToFTP(outputStream);
    }

    @Override
    public InputStream readFromFile(ClientFileDto fileModel) {
        FileReaderWriterModel readerWriterModel = FileReaderWriterModel.getInstance();
        file = fileModel;
        if (FileReaderWriterModel.ReaderWriterType.HDD == readerWriterModel.getReaderWriterType()) {
            return new ByteArrayInputStream(readFromHDD());

        } else {
            return new ByteArrayInputStream(readFromFTP());
        }
    }

    public boolean deleteFile(ClientFileDto fileModel) {
        final String basePath = FileUtils.fixPath(FileReaderWriterModel.getInstance().getLoadedBasePath());
        String completeFileName = basePath + file.getFileName() + "." + file.getExtension().toString();
        File file = new File(completeFileName);
        if (!file.delete()) {
            log.error(String.format("File could not delete: [%s]", file.getName()));
            return false;
        } else {
            log.error(String.format("File deleted: [%s]", file.getName()));
            return true;
        }
    }

    private String writeToHDD(ByteArrayOutputStream outputStream) {
        Long start = System.currentTimeMillis();
        Boolean successfulWrite = false;

        byte[] writeDate = outputStream.toByteArray();

        if (writeDate != null) {
            String completeFileName = file.getFileName() + "." + file.getExtension().toString();
            successfulWrite = HddFileWriter.write(completeFileName, file.getFilePath(), writeDate);
        }

        if (successfulWrite) {
            log.debug(String.format("HDD File [%s] successfully write in [%s] millis", file.getFileName(), System.currentTimeMillis() - start));
            return file.getFileName() + "." + file.getExtension().toString();
        } else {
            log.error(String.format("File [%s] failed to write in [%s] millis", file.getFileName(), System.currentTimeMillis() - start));
            return null;
        }
    }

    private byte[] readFromHDD() {
        Long start = System.currentTimeMillis();
        String fileName = file.getFilePath();
        byte[] readData = HddFileReader.read(fileName);

        if (readData != null)
            log.debug(String.format("HDD File [%s] read in [%s] millis", file.getFileName(), System.currentTimeMillis() - start));
        else
            log.error(String.format("File [%s] failed read in [%s] millis", file.getFileName(), System.currentTimeMillis() - start));

        return readData;
    }

    private String writeToFTP(ByteArrayOutputStream outputStream) {
        Long start = System.currentTimeMillis();
        FtpFileWriter ftpFileWriter = new FtpFileWriter();
        Boolean successfulWrite = false;

        byte[] writeData = outputStream.toByteArray();

        if (writeData != null) {
            String completeFileName = file.getFileName() + "." + file.getExtension().toString();
            successfulWrite = ftpFileWriter.write(completeFileName, file.getFilePath(), writeData);
        }

        ftpFileWriter.disconnect();

        if (successfulWrite) {
            log.debug(String.format("FTP File [%s] successfully write in [%s] millis", file.getFileName(), System.currentTimeMillis() - start));
            return file.getFileName() + "." + file.getExtension().toString();
        } else {
            log.error(String.format("File [%s] failed to write  in [%s] millis", file.getFileName(), System.currentTimeMillis() - start));
            return null;
        }
    }

    private byte[] readFromFTP() {
        Long start = System.currentTimeMillis();
        FtpFileReader fileReader = new FtpFileReader();
        String completeFileName = file.getFilePath();
        byte[] readData = fileReader.read(completeFileName);

        if (readData != null)
            log.debug(String.format("File [%s] successfully read in [%s] millis", file.getFileName(), System.currentTimeMillis() - start));
        else
            log.error(String.format("File [%s] failed read in [%s] millis", file.getFileName(), System.currentTimeMillis() - start));

        return readData;
    }

    @Override
    public byte[] readFileBytes(ClientFileDto fileModel) {
        FileReaderWriterModel readerWriterModel = FileReaderWriterModel.getInstance();
        file = fileModel;
        if (FileReaderWriterModel.ReaderWriterType.HDD == readerWriterModel.getReaderWriterType()) {
            return readFromHDD();
        } else {
            return readFromFTP();
        }
    }
}
