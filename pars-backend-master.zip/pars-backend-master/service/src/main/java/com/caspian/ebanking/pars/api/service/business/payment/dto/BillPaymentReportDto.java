package com.caspian.ebanking.pars.api.service.business.payment.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class BillPaymentReportDto {
    @ApiModelProperty(value = "شناسه پرداخت")
    private String paymentNumber;
    @ApiModelProperty(value = "شناسه قبض")
    private String billNumber;
    @ApiModelProperty(value = "کدشعبه")
    private String branchCode;
    @ApiModelProperty(value = "توع")
    private String channelType;
    @ApiModelProperty(value = "شماره پیگیری")
    private Integer trackingNumber;
    @ApiModelProperty(value = "تاریخ پرداخت")
    private Date paymentDate;
    @ApiModelProperty(value = "مبلغ")
    private BigDecimal billAmount;

}
