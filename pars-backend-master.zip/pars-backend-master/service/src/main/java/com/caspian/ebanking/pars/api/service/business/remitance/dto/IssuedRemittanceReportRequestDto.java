package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۶/۰۱/۲۰۲۱ ۰۹:۵۱ قبل‌ازظهر
 */
@Data
public class IssuedRemittanceReportRequestDto {
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "از تاریخ صدور")
    private Date fromIssueDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تا تاریخ صدور")
    private Date toIssueDate;

    @ApiModelProperty(value = "نوع حواله",allowableValues = "INWARD_TRANSFER,TELEGRAPHIC_TRANSFER,DEMAND_DRAFT")
    private String remittanceType;

    private BigDecimal fromAmount;

    private BigDecimal toAmount;

    @ApiModelProperty(value = "نوع ارز",allowableValues = "IRR,USD")
    private String currencyType;

    private String branch;

    @ApiModelProperty(value = "وضعیت",allowableValues = "REGIGSTERD,READY_FOR_ACCEPT,CONFIRMED")
    private String status;
}