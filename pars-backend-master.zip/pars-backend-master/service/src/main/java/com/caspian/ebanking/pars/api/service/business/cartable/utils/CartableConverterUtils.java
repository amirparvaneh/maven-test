package com.caspian.ebanking.pars.api.service.business.cartable.utils;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.utils.DateUtils;
import com.caspian.ebanking.pars.api.service.business.cartable.dto.CartableRequestDto;
import com.caspian.ebanking.pars.api.service.business.cartable.dto.DoCartableRequestDto;
import com.caspian.ebanking.pars.api.service.business.cartable.dto.*;
import com.caspian.ebanking.pars.api.service.business.cartable.enums.Priority;
import com.caspian.ebanking.pars.api.service.business.cartable.enums.RequestStatus;
import com.caspian.ebanking.pars.api.service.business.cartable.enums.RequestType;
import com.caspian.moderngateway.core.message.dto.*;
import com.caspian.moderngateway.core.message.dto.groupfiletransfer.CartableGroupFileTransferDetailDto;
import com.caspian.moderngateway.core.security.dto.ChSecondPasswordType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @author atousa khanjani
 * @version 1.0
 * @since ۱۳/۰۱/۲۰۲۱ ۰۳:۲۵ قبل‌ازظهر
 */
@Component
@RequiredArgsConstructor
public class CartableConverterUtils {
    private final ParsModelMapper mapper;

    public CartableRequestSearchDto convertToCartableSearchDto(CartableRequestDto requestDto) {
        CartableRequestSearchDto searchDto = new CartableRequestSearchDto();
        searchDto.setRequestCode(requestDto.getRequestCode());
        searchDto.setRequestType(RequestType.getCharacterOf(requestDto.getRequestType()));
        searchDto.setStatus(RequestStatus.getCharacterOf(requestDto.getStatus()));
        searchDto.setFromRequestDate(DateUtils.getTimeValue(requestDto.getFromRequestDate(), 0, 0, 0));
        searchDto.setToRequestDate(DateUtils.getTimeValue(requestDto.getToRequestDate(), 23, 59, 59));
        searchDto.setFromExpireDate(DateUtils.getTimeValue(requestDto.getFromExpireDate(), 0, 0, 0));
        searchDto.setToExpireDate(DateUtils.getTimeValue(requestDto.getToExpireDate(), 23, 59, 59));
        searchDto.setPriority(Priority.getCharacterOf(requestDto.getPriority()));
        searchDto.setOperational(requestDto.getOperational());
        searchDto.setLoadApproval(requestDto.getLoadApproval());
        searchDto.setClientId(requestDto.getClientId());
        searchDto.setDescription(requestDto.getDescription());
        return searchDto;
    }

    public CartableNormalTransferDetailResponseDto convertToCartableTransferDetailResponse(CartableTransferRequestDto cartableTransferRequestDto) {
        CartableNormalTransferDetailResponseDto responseDto = new CartableNormalTransferDetailResponseDto();
        if (cartableTransferRequestDto != null) {
            responseDto = mapper.map(cartableTransferRequestDto, CartableNormalTransferDetailResponseDto.class);
            responseDto.setTransferDetailsDto(cartableTransferRequestDto.getTransferRequestEntryDto() != null ?
                    mapper.map(cartableTransferRequestDto.getTransferRequestEntryDto(), CartableTransferDetailsDto.class) : null);
            responseDto.setTransferApprovalDtos(cartableTransferRequestDto.getCartableApprovalRequestDtos() != null ?
                    mapper.mapList(cartableTransferRequestDto.getCartableApprovalRequestDtos(), CartableTransferApprovalDto.class) : null);
        }
        return responseDto;
    }

    public CartableNormalBatchTransferDetailResponseDto convertToCartableBatchTransferDetailResponse(CartableBatchTransferRequestDetailsDto cartableTransferRequestDtos) {
        CartableNormalBatchTransferDetailResponseDto responseDto = new CartableNormalBatchTransferDetailResponseDto();
        if (cartableTransferRequestDtos != null) {
            responseDto = mapper.map(cartableTransferRequestDtos, CartableNormalBatchTransferDetailResponseDto.class);
            responseDto.setTransferDetailsDtos(cartableTransferRequestDtos.getCartableTransferRequestEntriesDto() != null ?
                    mapper.mapList(cartableTransferRequestDtos.getCartableTransferRequestEntriesDto(), CartableTransferDetailsDto.class) : null);
            responseDto.setApprovalRequestDtos(cartableTransferRequestDtos.getCartableApprovalRequestDtos() != null ?
                    mapper.mapList(cartableTransferRequestDtos.getCartableApprovalRequestDtos(), CartableTransferApprovalDto.class) : null);
        }
        return responseDto;
    }

    public CartableAchBatchTransferDetailResponseDto convertToCartableAchBatchTransferDetailResponse(CartableBatchAchOrderTransferDetailsDto cartableBatchTransferDetailsDto) {
        CartableAchBatchTransferDetailResponseDto responseDto = new CartableAchBatchTransferDetailResponseDto();
        if (cartableBatchTransferDetailsDto != null) {
            responseDto = mapper.map(cartableBatchTransferDetailsDto, CartableAchBatchTransferDetailResponseDto.class);
            responseDto.setTransferDetailsDtos(cartableBatchTransferDetailsDto.getCartableAchOrderTransferEntriesDto() != null ?
                    mapper.mapList(cartableBatchTransferDetailsDto.getCartableAchOrderTransferEntriesDto(), CartableAchTransferDetailsDto.class) : null);
            responseDto.setApprovalRequestDtos(cartableBatchTransferDetailsDto.getCartableApprovalRequestDtos() != null ?
                    mapper.mapList(cartableBatchTransferDetailsDto.getCartableApprovalRequestDtos(), CartableTransferApprovalDto.class) : null);
        }
        return responseDto;
    }


    public CartableAchNormalTransferDetailResponseDto convertToCartableAchNormalTransferDetailResponse(CartableAchOrderTransferDto cartableAchOrderTransferDto) {
        CartableAchNormalTransferDetailResponseDto responseDto = new CartableAchNormalTransferDetailResponseDto();
        if (cartableAchOrderTransferDto != null) {
            responseDto = mapper.map(cartableAchOrderTransferDto, CartableAchNormalTransferDetailResponseDto.class);
            responseDto.setTransferDetailsDto(cartableAchOrderTransferDto.getCartableAchOrderTransferEntryDto() != null ?
                    mapper.map(cartableAchOrderTransferDto.getCartableAchOrderTransferEntryDto(), CartableAchTransferDetailsDto.class) : null);
            responseDto.setApprovalRequestDtos(cartableAchOrderTransferDto.getCartableApprovalRequestDtos() != null ?
                    mapper.mapList(cartableAchOrderTransferDto.getCartableApprovalRequestDtos(), CartableTransferApprovalDto.class) : null);
        }
        return responseDto;
    }

    public CartableFileGroupTransferDetailResponseDto convertToFileGroupTransferDetailResponse(CartableGroupFileTransferDetailDto cartableGroupFileTransferDetailDto) {
        CartableFileGroupTransferDetailResponseDto responseDto = new CartableFileGroupTransferDetailResponseDto();
        if (cartableGroupFileTransferDetailDto != null) {
            responseDto = mapper.map(cartableGroupFileTransferDetailDto, CartableFileGroupTransferDetailResponseDto.class);
            responseDto.setTransferDetailsDto(cartableGroupFileTransferDetailDto.getCartableGroupFileTransferEntryDto() != null ?
                    mapper.map(cartableGroupFileTransferDetailDto.getCartableGroupFileTransferEntryDto(), CartableFileGroupTransferDetailsDto.class) : null);
            responseDto.setApprovalRequestDtos(cartableGroupFileTransferDetailDto.getCartableApprovalRequestDtos() != null ?
                    mapper.mapList(cartableGroupFileTransferDetailDto.getCartableApprovalRequestDtos(), CartableTransferApprovalDto.class) : null);
        }
        return responseDto;
    }

    public ApproveCartableRequestBean convertToApproveCartableRequestBean(ApproveCartableRequestDto requestDto) {
        ApproveCartableRequestBean requestBean = new ApproveCartableRequestBean();
        requestBean.setCartableRequestCode(requestDto.getCartableRequestCode());
        requestBean.setSecondPassword(requestDto.getSecondPassword());
        requestBean.setChSecondPasswordType(ChSecondPasswordType.valueOf(requestDto.getChSecondPasswordType()));
        return requestBean;
    }


    public CartableAchOrderTransferDto convertSingleCartableAchTransferRequest(SingleCartableAchOrderTransferRequestDto requestDto) {
        final CartableAchOrderTransferDto criteria = new CartableAchOrderTransferDto();
        criteria.setExpireDate(requestDto.getExpireDate());
        criteria.setPriority(requestDto.getPriority());
        criteria.setDescription(requestDto.getCartableDescription());
        criteria.setWithdrawConditionCode(requestDto.getConditionId());
        criteria.setAccountNumber(requestDto.getSourceAccount());
        CartableAchOrderTransferEntryDto entry = new CartableAchOrderTransferEntryDto();
        entry.setDescription(requestDto.getDescription());
        entry.setIbanNumber(requestDto.getIban());
        String ownerName = requestDto.getOwnerName();
        entry.setOwnerName(ownerName.length() > 30 ? ownerName.substring(0, 30) : ownerName);
        entry.setAmount(requestDto.getAmount());
        entry.setFactorNumber(requestDto.getFactorNumber());
        criteria.setCartableAchOrderTransferEntryDto(entry);
        return criteria;
    }

    public CartableBatchAchOrderTransferDto convertBatchCartableAchTransferRequest(BatchCartableAchOrderTransferRequestDto requestDto) {
        final CartableBatchAchOrderTransferDto criteria = new CartableBatchAchOrderTransferDto();
        criteria.setExpireDate(requestDto.getExpireDate());
        criteria.setPriority(requestDto.getPriority());
        criteria.setDescription(requestDto.getCartableDescription());
        criteria.setWithdrawConditionCode(requestDto.getConditionId());
        criteria.setAccountNumber(requestDto.getSourceAccount());
        List<CartableAchOrderTransferEntryDto> entries = new ArrayList<CartableAchOrderTransferEntryDto>();
        CartableAchOrderTransferEntryDto entry;
        for (CartableAchOrderTransferEntryDto item : requestDto.getCartableAchOrderTransferEntriesDto()) {
            entry = new CartableAchOrderTransferEntryDto();
            entry.setIbanNumber(item.getIbanNumber());
            entry.setOwnerName(item.getOwnerName().length() > 30 ? item.getOwnerName().substring(0, 30) : item.getOwnerName());
            entry.setAmount(item.getAmount());
            entry.setDescription(item.getDescription());
            entry.setFactorNumber(item.getFactorNumber());
            entries.add(entry);
        }
        criteria.setCartableAchOrderTransferEntriesDto(entries);
        return criteria;

    }

    public com.caspian.moderngateway.core.message.dto.DoCartableRequestDto convertDoCartableRequest(DoCartableRequestDto requestDto) {
        com.caspian.moderngateway.core.message.dto.DoCartableRequestDto cartableRequestDto = new com.caspian.moderngateway.core.message.dto.DoCartableRequestDto();
        cartableRequestDto.setCartableRequestCode(requestDto.getCartableRequestCode());
        cartableRequestDto.setCheckUniqueTrackingCode(requestDto.isCheckUniqueTrackingCode());
        cartableRequestDto.setChSecondPasswordType(ChSecondPasswordType.valueOf(requestDto.getPasswordType()));
        cartableRequestDto.setSecondPassword(requestDto.getSecondPassword());
        cartableRequestDto.setUniqueTrackingCode(requestDto.getUniqueTrackingCode());
        return cartableRequestDto;
    }

    public CartableTransferRequestDto convertSingleCartableTransferRequest(SingleCartableNormalFundTransferRequestDto requestDto) {
        final CartableTransferRequestDto criteria = new CartableTransferRequestDto();

        criteria.setExpireDate(requestDto.getExpireDate());
        criteria.setWithdrawConditionCode(requestDto.getConditionId());
        criteria.setAccountNumber(requestDto.getSourceAccount());
        criteria.setPriority(requestDto.getPriority());

        CartableTransferRequestEntryDto entry = new CartableTransferRequestEntryDto();
        entry.setToAccount(requestDto.getDestinationAccount());
        entry.setAmount(requestDto.getAmount());
        entry.setDestinationNarrative(requestDto.getDestinationComment());
        entry.setNarrative(requestDto.getSourceComment());

        criteria.setTransferRequestEntryDto(entry);

        return criteria;

    }

    public CartableBatchTransferRequestDto convertBatchCartableTransferRequest(BatchCartableNormalFundTransferRequestDto requestDto) {
        final CartableBatchTransferRequestDto criteria = new CartableBatchTransferRequestDto();
        criteria.setExpireDate(requestDto.getExpireDate());
        criteria.setPriority(requestDto.getPriority());
        criteria.setWithdrawConditionCode(requestDto.getConditionId());
        criteria.setAccountNumber(requestDto.getSourceAccount());
        criteria.setIgnoreError(requestDto.getIgnoreError());
        criteria.setDescription(requestDto.getDescription());
        List<CartableTransferRequestEntryDto> entries = new ArrayList<CartableTransferRequestEntryDto>();
        CartableTransferRequestEntryDto entry;
        for (CartableTransferRequestEntry item : requestDto.getCartableTransferRequestEntriesDto()) {
            entry = new CartableTransferRequestEntryDto();
            entry.setDestinationNarrative(item.getDestinationNarrative());
            entry.setAmount(item.getAmount());
            entry.setNarrative(item.getNarrative());
            entry.setToAccount(item.getToAccount());
            entries.add(entry);
        }
        criteria.setCartableTransferRequestEntriesDto(entries);
        return criteria;

    }
}