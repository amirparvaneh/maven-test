package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChStatementSearchDirection;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/05/2021 11:38 AM
 */
@Data
public class GetReferenceCodeStatementByChequeRequestDto {
    @ApiModelProperty("شماره حساب")
    private String accountNumber;
    @ApiModelProperty("از تاریخ")
    private Date passChequeFrom;
    @ApiModelProperty("تا تاریخ")
    private Date passChequeTo;
    @ApiModelProperty("از مبلغ")
    private BigDecimal fromAmount;
    @ApiModelProperty("تا مبلغ")
    private BigDecimal toAmount;
    @ApiModelProperty("شناسه پرداخت")
    private String referenceCode;
    @ApiModelProperty("شماره سند")
    private String dealReference;
    @ApiModelProperty("شماره چک")
    private String chequeNumber;
    @ApiModelProperty("بانک ذینفع")
    private String chequeBankCode;
    @ApiModelProperty("شعبه واگذارنده")
    private String chequeOpBranchCode;
    private Integer length;
    private Integer offset;
    @ApiModelProperty(value = "ترتیب", allowableValues = "ASC,DESC")
    private String searchDirection;
    private Boolean withCheque;
}
