package com.caspian.ebanking.pars.api.service.business.normaltransfer.dto;

import lombok.Data;

import java.util.List;

/**
 * @author atousa khanjani
 * @since 01/27/2021 07:34 PM
 */
@Data
public class AutoNormalTransferReportResponseDto {
    private String total;
    private List<AutoNormalTransferResponseDetail> orderDetails;
}