package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import lombok.Data;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 9:38 AM
 */
@Data
public class GetSettlementTitleListRequestDto {
    private Boolean isActive;
    private String operationCode;
}
