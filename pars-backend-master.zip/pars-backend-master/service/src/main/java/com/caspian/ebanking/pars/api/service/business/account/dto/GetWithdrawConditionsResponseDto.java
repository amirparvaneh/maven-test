package com.caspian.ebanking.pars.api.service.business.account.dto;

import lombok.Data;

import java.util.List;

/**
 * @author atousa khanjani
 * @since 12/29/2020 07:34 PM
 */
@Data
public class GetWithdrawConditionsResponseDto {
    List<WithdrawConditionDto> withdrawConditionDtoList;
}
