package com.caspian.ebanking.pars.api.service.business.ach.dto;

import lombok.Data;

import java.util.List;

@Data
public class AchTransferReportResponseDto {
    private Long totalRecord;
    private List<AchTransferReportItemDto> reportItemList;
}
