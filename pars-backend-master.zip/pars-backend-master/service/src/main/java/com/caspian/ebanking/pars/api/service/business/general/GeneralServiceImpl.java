package com.caspian.ebanking.pars.api.service.business.general;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.utils.StringUtils;
import com.caspian.ebanking.pars.api.service.business.general.dto.ExceptionTranslationResponseDto;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.ChExceptionTranslationRequestBean;
import com.caspian.moderngateway.core.message.TranslateExceptionMsg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/19/2020 12:18 AM
 */
@Service
public class GeneralServiceImpl extends BaseService implements GeneralService {

    private static final Logger logger = LoggerFactory.getLogger(GeneralServiceImpl.class);

    private final CurrentUserService currentUserService;

    @Autowired
    public GeneralServiceImpl(CurrentUserService currentUserService) {
        this.currentUserService = currentUserService;
    }


    @Override
    @Cacheable(cacheNames = "exceptionTranslationCache")
    public ExceptionTranslationResponseDto getExceptionTranslation(String locale, String className) {

        TranslateExceptionMsg.Inbound inbound = new TranslateExceptionMsg.Inbound();

        ChExceptionTranslationRequestBean requestBean = new ChExceptionTranslationRequestBean();
        requestBean.setChannel("VALUABLE_CUSTOMER");

        List<ChExceptionTranslationRequestBean.Locale> locales = new ArrayList<>();

        if (StringUtils.isNullOrEmpty(locale) || locale.equalsIgnoreCase(ClientDataControl.LOCALE_FA)) {
            locales.add(ChExceptionTranslationRequestBean.Locale.fa_IR);
        } else {
            locales.add(ChExceptionTranslationRequestBean.Locale.en_US);
        }

        requestBean.setLocaleList(locales);
        requestBean.setExceptionType(className);

        inbound.setRequestBean(requestBean);

        try {
            TranslateExceptionMsg.Outbound outbound = channelManagerProvider.execute(inbound, TranslateExceptionMsg.Outbound.class);

            //TODO
            String translation = outbound.getResponseBean().getExceptionTransactionBeanList().get(0).getTranslation();
            if (StringUtils.isNullOrEmpty(translation) || translation.equalsIgnoreCase("unknown"))
                translation = requestBean.getLocaleList().get(0) == ChExceptionTranslationRequestBean.Locale.en_US ? "An Unknown Error has occurred." : "امکان انجام درخواست شما وجود ندارد.";

            return new ExceptionTranslationResponseDto(outbound.getResponseBean().getExceptionTransactionBeanList().get(0).getExceptionType(), translation);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Scheduled(fixedRate = 3600000)
    @CacheEvict(value = "exceptionTranslationCache", allEntries = true)
    public void clearCache() {
        logger.info("Exception Translation cache Cleared.");
    }
}
