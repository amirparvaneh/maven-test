package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.AccountNo;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.Validator;
import com.caspian.moderngateway.core.coreservice.constant.GroupTransferStatus;
import com.caspian.moderngateway.core.coreservice.dto.groupfiletransfer.ChGroupTransferFileBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author atousa khanjani
 * @since 01/27/2021 07:34 PM
 */
@Data
public class RegisterGroupTransferRequestDto {
   private GroupTransferDto groupTransferDto;

}