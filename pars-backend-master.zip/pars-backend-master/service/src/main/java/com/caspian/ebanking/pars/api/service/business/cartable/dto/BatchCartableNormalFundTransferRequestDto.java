package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 01/21/2021 9:53 AM
 */
@Data
public class BatchCartableNormalFundTransferRequestDto {

    private Date expireDate;
    private Character priority;
    private String description;
    private String sourceAccount;
    private Boolean ignoreError;
    private String conditionId;
    private List<CartableTransferRequestEntry> cartableTransferRequestEntriesDto;


}
