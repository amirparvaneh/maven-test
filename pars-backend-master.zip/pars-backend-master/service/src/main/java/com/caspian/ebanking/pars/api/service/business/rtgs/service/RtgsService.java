package com.caspian.ebanking.pars.api.service.business.rtgs.service;

import com.caspian.ebanking.pars.api.service.business.rtgs.dto.*;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۴/۰۱/۲۰۲۱ ۰۱:۱۵ بعدازظهر
 */
public interface RtgsService {
    RtgsSingleTransferResponseDto singleTransfer(RtgsSingleTransferRequestDto requestDto);

    RtgsTransferReportResponseDto transferReport(RtgsTransferReportRequestDto requestDto);

    RtgsTransactionReportResponseDto transactionReport(RtgsTransactionReportRequestDto requestDto);

}
