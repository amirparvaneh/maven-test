package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 01/21/2021 9:53 AM
 */
@Data
public class CartableAchOrderTransferEntry {
    private String description;
    private String ibanNumber;
    private String ibanBankName;
    private String ownerName;
    private String factorNumber;
    private BigDecimal amount;
}
