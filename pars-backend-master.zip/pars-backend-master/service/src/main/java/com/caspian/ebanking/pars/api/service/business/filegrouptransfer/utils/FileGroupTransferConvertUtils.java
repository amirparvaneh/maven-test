package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.utils;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.utils.DateUtils;
import com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto.*;
import com.caspian.moderngateway.core.coreservice.constant.GroupTransferDetailStatus;
import com.caspian.moderngateway.core.coreservice.constant.GroupTransferDetailType;
import com.caspian.moderngateway.core.coreservice.constant.GroupTransferOrder;
import com.caspian.moderngateway.core.coreservice.constant.GroupTransferStatus;
import com.caspian.moderngateway.core.coreservice.dto.groupfiletransfer.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/5/2021 11:22 AM
 */
@Component
@RequiredArgsConstructor
public class FileGroupTransferConvertUtils {
    private final ParsModelMapper mapper;

    public ChGroupTransferRegisterRequestBean convertToGroupTransferRegisterRequestBean(RegisterGroupTransferRequestDto requestDto) {
        ChGroupTransferRegisterRequestBean requestBean = new ChGroupTransferRegisterRequestBean();
        ChGroupTransferBean groupTransferBean = new ChGroupTransferBean();
        groupTransferBean.setSourceAccountNumber(requestDto.getGroupTransferDto().getSourceAccountNumber());
        groupTransferBean.setTitle(requestDto.getGroupTransferDto().getTitle());
        groupTransferBean.setEffectiveDate(requestDto.getGroupTransferDto().getEffectiveDate());
        groupTransferBean.setClientTotalNumber(requestDto.getGroupTransferDto().getClientTotalNumber());
        groupTransferBean.setClientTotalAmount(requestDto.getGroupTransferDto().getClientTotalAmount());
        groupTransferBean.setTrackingCode(requestDto.getGroupTransferDto().getTrackingCode());
        groupTransferBean.setDescription(requestDto.getGroupTransferDto().getDescription());
//        groupTransferBean.setGroupTransferFileRequestBeans(null);
        requestBean.setGroupTransferBean(groupTransferBean);
        return requestBean;
    }


    public RegisterGroupTransferResponseDto convertToRegisterGroupTransferResponseDto(ChGroupTransferRegisterResponseBean responseBean) {
        RegisterGroupTransferResponseDto responseDto = new RegisterGroupTransferResponseDto();
        GroupTransferDto groupTransferDto = new GroupTransferDto();
        groupTransferDto.setSourceAccountNumber(responseBean.getGroupTransferBean().getSourceAccountNumber());
        groupTransferDto.setTitle(responseBean.getGroupTransferBean().getTitle());
        groupTransferDto.setEffectiveDate(responseBean.getGroupTransferBean().getEffectiveDate());
        groupTransferDto.setClientTotalNumber(responseBean.getGroupTransferBean().getClientTotalNumber());
        groupTransferDto.setClientTotalAmount(responseBean.getGroupTransferBean().getClientTotalAmount());
        groupTransferDto.setTrackingCode(responseBean.getGroupTransferBean().getTrackingCode());
        groupTransferDto.setDescription(responseBean.getGroupTransferBean().getDescription());
//        groupTransferDto.setGroupTransferFileRequestBeans(null);
        responseDto.setGroupTransferDto(groupTransferDto);
        return responseDto;

    }

    public ChGroupTransferSearchRequestBean convertToGroupTransferSearchRequestBean(SearchGroupTransferRequestDto requestDto) {
        ChGroupTransferSearchRequestBean requestBean = new ChGroupTransferSearchRequestBean();
        requestBean.setSourceAccountNumber(requestDto.getSourceAccountNumber());
        requestBean.setTitle(requestDto.getTitle());
        requestBean.setDescription(requestDto.getDescription());
        requestBean.setFromOrderDate(requestDto.getFromOrderDate());
        requestBean.setToOrderDate(requestDto.getToOrderDate());
        requestBean.setFromEffectiveDate(requestDto.getFromEffectiveDate());
        requestBean.setToEffectiveDate(requestDto.getToEffectiveDate());
        requestBean.setFromTotalNumber(requestDto.getFromTotalNumber());
        requestBean.setToTotalNumber(requestDto.getToTotalNumber());
        requestBean.setTrackingCode(requestDto.getTrackingCode());
        requestBean.setFromTotalAmount(requestDto.getFromTotalAmount());
        requestBean.setToTotalAmount(requestDto.getToTotalAmount());
        if (requestDto.getStatus() != null && !requestDto.getStatus().equalsIgnoreCase("ALL")) {
            requestBean.setStatus(GroupTransferStatus.valueOf(requestDto.getStatus()));
        }
        requestBean.setOrder(GroupTransferOrder.valueOf(requestDto.getOrder()));
        requestBean.setCif(requestDto.getCif());
        return requestBean;
    }

    public SearchGroupTransferResponseDto convertToSearchGroupTransferResponseDto(ChGroupTransferSearchResponseBean responseBean) {
        SearchGroupTransferResponseDto responseDto = new SearchGroupTransferResponseDto();
        final List<GroupTransferDto> list = new ArrayList<>();
        for (ChGroupTransferBean item : responseBean.getGroupTransferBeans()) {
            GroupTransferDto groupTransferDto = mapper.map(item, GroupTransferDto.class);
            groupTransferDto.setStatus(item.getGroupTransferStatus().getCode());
            list.add(groupTransferDto);
        }
        responseDto.setGroupTransferDtoList(list);
        return responseDto;
    }

    public ChGroupTransferDetailSearchRequestBean convertToGroupTransferDetailSearchRequestBean(SearchGroupTransferDetailRequestDto requestDto) {

        ChGroupTransferDetailSearchRequestBean requestBean = new ChGroupTransferDetailSearchRequestBean();
        requestBean.setAccountNumber(requestDto.getAccountNumber());
        requestBean.setParentTrackingCode(requestDto.getParentTrackingCode());
        requestBean.setReference(requestDto.getReference());
        requestBean.setFileName(requestDto.getFileName());
        requestBean.setCoreTrackingCode(requestDto.getCoreTrackingCode());
        requestBean.setDestinationAccount(requestDto.getDestinationAccount());
        requestBean.setFromInsertDate(convertFromDateMidnight(requestDto.getFromInsertDate()));
        requestBean.setToInsertDate(convertToDateMidnight(requestDto.getToInsertDate()));
        requestBean.setFromRejectedDealReferenceDate(convertFromDateMidnight(requestDto.getFromRejectedDealReferenceDate()));
        requestBean.setFromActionDate(convertFromDateMidnight(requestDto.getFromActionDate()));
        requestBean.setToActionDate(convertToDateMidnight(requestDto.getToActionDate()));

        requestBean.setFromAmount(requestDto.getFromAmount());
        requestBean.setToAmount(requestDto.getToAmount());
        requestBean.setPaymentId(requestDto.getPaymentId());

        String status = requestDto.getDetailStatus();
        if (status != null && !status.equalsIgnoreCase("ALL"))
            requestBean.setDetailStatus(GroupTransferDetailStatus.valueOf(status));

        String order = requestDto.getOrder();
        if (order != null)
            requestBean.setOrder(GroupTransferOrder.valueOf(order));

        String type = requestDto.getDetailType();
        if (type != null && !type.equalsIgnoreCase("ALL"))
            requestBean.setDetailType(GroupTransferDetailType.valueOf(type));

        requestBean.setDescription(requestDto.getDescription());
        requestBean.setSourceAccountNumber(requestDto.getSourceAccountNumber());
        requestBean.setStartRow(requestDto.getStartRow());
        requestBean.setEndRow(requestDto.getEndRow());

        return requestBean;
    }


    public SearchGroupTransferDetailResponseDto convertToSearchGroupTransferDetailResponseDto(List<ChGroupTransferDetailBean> groupTransferDetailSearchBeans) {
        SearchGroupTransferDetailResponseDto responseDto = new SearchGroupTransferDetailResponseDto();
        final List<GroupTransferDetailDto> list = new ArrayList<>();

        for (ChGroupTransferDetailBean item : groupTransferDetailSearchBeans) {
            GroupTransferDetailDto reportItem = mapper.map(item, GroupTransferDetailDto.class);
            reportItem.setStatus(item.getDetailStatus().getCode());
            if (item.getDetailType() == null) reportItem.setType("unknown");
            else reportItem.setType(item.getDetailType().getCode());

            reportItem.setFullName((item.getClientName() == null ? "" : item.getClientName()) + " " + (item.getClientFamily() == null ? "" : item.getClientFamily()));
            list.add(reportItem);

        }
        responseDto.setGroupTransferDetailDtos(list);
        return responseDto;
    }

    private Date convertToDateMidnight(Date date) {
        Date dt = null;
        if (date != null) {
            final Calendar c = Calendar.getInstance();
            c.setTime(DateUtils.getTimeValue(date, 0, 0, 0));
            c.add(Calendar.DAY_OF_YEAR, 1);
            dt = c.getTime();
        }
        return dt;
    }

    private Date convertFromDateMidnight(Date date) {
        return date == null ? null : DateUtils.getTimeValue(date, 0, 0, 0);
    }


}