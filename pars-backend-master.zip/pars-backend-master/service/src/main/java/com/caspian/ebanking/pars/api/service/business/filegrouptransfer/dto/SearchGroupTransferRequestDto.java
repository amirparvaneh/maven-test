package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author atousa khanjani
 * @since 02/21/2021 07:34 PM
 */
@Data
public class SearchGroupTransferRequestDto {
    private String sourceAccountNumber;
    private String sourceAccountId;
    private String title;
    private String description;
    private Date fromOrderDate;
    private Date toOrderDate;
    private Date fromEffectiveDate;
    private Date toEffectiveDate;
    private BigDecimal fromTotalAmount;
    private BigDecimal toTotalAmount;
    private String trackingCode;
    private Integer fromTotalNumber;
    private Integer toTotalNumber;
    private String status;
    private String order;
    private Long cif;

}