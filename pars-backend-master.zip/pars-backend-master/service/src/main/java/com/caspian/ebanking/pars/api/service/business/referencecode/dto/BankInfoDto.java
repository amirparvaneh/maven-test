package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/03/2021 11:38 PM
 */
@Data
public class BankInfoDto {
    @ApiModelProperty(value = "کد شعبه")
    private String code;
    @ApiModelProperty(value = "عنوان شعبه")
    private String title;
}
