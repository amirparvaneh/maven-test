package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۰۳:۱۳ بعدازظهر
 */
@Data
public class GuarantyReportResponseDto {
    private List<GuarantyReportItemDto> reportItemDtoList;
}