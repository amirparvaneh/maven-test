package com.caspian.ebanking.pars.api.service.business.general;

import com.caspian.ebanking.pars.api.service.business.general.dto.ExceptionTranslationResponseDto;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/19/2020 12:14 AM
 */
public interface GeneralService {
    ExceptionTranslationResponseDto getExceptionTranslation(String locale, String className);


}
