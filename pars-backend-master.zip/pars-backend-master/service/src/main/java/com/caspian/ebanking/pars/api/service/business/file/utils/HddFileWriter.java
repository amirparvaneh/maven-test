package com.caspian.ebanking.pars.api.service.business.file.utils;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.*;

@Component
public class HddFileWriter {

    private static final Logger log = Logger.getLogger(HddFileReader.class);

    public static Boolean write(String fileName, String path, byte[] data) {
        String basePath = FileReaderWriterModel.getInstance().getLoadedBasePath();
        String destinationFilePath = basePath + path + fileName;
        int readFileSize = FileUtils.readFileSize(destinationFilePath);

        if (readFileSize >= data.length) {
            log.debug(String.format("Destination file size[%10d] is bigger than source file size[%10d] [%s].", readFileSize, data.length, fileName));
            return true;
        }

        File destinationDirectory = new File(basePath + path);
        destinationDirectory.mkdirs();

        OutputStream output = null;
        try {
            output = new BufferedOutputStream(new FileOutputStream(destinationFilePath));
            output.write(data);
            output.flush();
            output.close();
        } catch (IOException e) {
            return false;
        }
        return true;
    }
}
