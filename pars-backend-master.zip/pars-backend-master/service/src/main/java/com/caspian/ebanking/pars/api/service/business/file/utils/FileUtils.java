package com.caspian.ebanking.pars.api.service.business.file.utils;


import com.caspian.ebanking.pars.api.service.business.offlineStatement.enums.ReportFileType;

import javax.servlet.http.HttpServletResponse;
import java.io.*;

public class FileUtils {

    public static String fixPath(String filePath) {
        if (filePath.length() == 0) return "";
        if (filePath.endsWith("/") || filePath.endsWith("\\")) return filePath;
        else {
            if (filePath.contains("/")) {
                filePath += "/";
            } else if (filePath.contains("\\")) {
                filePath += "\\";
            } else filePath += "/";
            return filePath;
        }
    }

    public static int readFileSize(String path) {
        File file = new File(path);
        return (int) file.length();
    }

    public static void writeToResponse(byte[] data, ReportFileType fileType, String fileName, HttpServletResponse response) {
        if (data != null) {
            String fixedFileName = FileStringUtils.fixFileName(fileName, fileType);
            response.reset();
            response.setContentType(ReportFileType.getFileContentType(fileType.value));
            response.setHeader("Content-disposition", "attachment; filename=\"" + fixedFileName + "\"");
            response.addHeader("filename", fixedFileName);
            try {
                response.getOutputStream().write(data);
                response.getOutputStream().flush();
            } catch (IOException e) {
//                throw new WebbankBaseException(e);
            }
        }
    }
}