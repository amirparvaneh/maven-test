package com.caspian.ebanking.pars.api.service.business.pichak.service;

import com.caspian.ebanking.pars.api.service.business.pichak.dto.*;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 24/05/2021 07:18 PM
 */
public interface PichakService {


    PichakIssueChequeResponseDto pichakIssueCheque(PichakIssueChequeRequestDto requestDto);

    PichakTransferChequeResponseDto pichakTransferCheque(PichakTransferChequeRequestDto requestDto);

    PichakChequeInquiryResponseDto pichakChequeInquiry(PichakInquiryChequeRequestDto requestDto);

    PichakSetChequeConfirmStatusResponseDto setChequeConfirmStatus(PichakSetChequeConfirmStatusRequestDto requestDto);

    GetChequeCartableResponseDto getChequeCartable(GetChequeCartableRequestDto requestDto);

    DoChequeCartableResponseDto doChequeCartable(DoChequeCartableRequestDto requestDto);

    ApproveChequeCartableResponseDto approveChequeCartable(ApproveChequeCartableRequestDto requestDto);

    CancelChequeCartableResponseDto cancelChequeCartable(CancelChequeCartableRequestDto requestDto);

    RejectChequeCartableResponseDto rejectChequeCartable(RejectChequeCartableRequestDto requestDto);
}
