package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 01/21/2021 9:53 AM
 */
@Data
public class SingleCartableRtgsOrderTransferRequestDto {
    @ApiModelProperty(value = "تاریخ انقضا")
    private Date expireDate;
    @ApiModelProperty(name = "اولویت", allowableValues = "M,C,I,T", notes = "(1: MAJOR, 2: CRITICAL, 3: MINOR, 4: TRIVIAL)")
    private Character priority;
    @ApiModelProperty(value = "یادداشت فرستنده")
    private String description;
    @ApiModelProperty(value = "برداشت از")
    private String sourceAccount;
    @ApiModelProperty(value = "شرایط برداشت")
    private String conditionId;
    @ApiModelProperty(value = "شرح کارتابل")
    private String cartableDescription;
    @ApiModelProperty(value = "واریز به")
    private String iban;
    @ApiModelProperty(value = "نام دارنده شبا مقصد")
    private String ownerName;
    @ApiModelProperty(value = "مبلغ")
    private BigDecimal amount;
    @ApiModelProperty(value = "شناسه پرداخت")
    private String factorNumber;


}