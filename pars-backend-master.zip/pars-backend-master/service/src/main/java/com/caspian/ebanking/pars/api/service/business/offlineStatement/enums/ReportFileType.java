package com.caspian.ebanking.pars.api.service.business.offlineStatement.enums;


import com.caspian.ebanking.pars.api.service.business.file.dto.ClientFileDto;

/**
 * @author Amir Tajik
 * @author Saman Delfani
 * @version 1.2
 * @since 05/05/2018 10:34 AM
 */
public enum ReportFileType {
    XLS("XLS"), PDF("PDF"), CSV("CSV"), XLSX("XLSX"), JPG("JPG"), PNG("PNG"), BMP("BMP");

    public final String value;

    ReportFileType(String value) {
        this.value = value;
    }

    public static ReportFileType fromValue(String v) {
        return valueOf(v.toUpperCase());
    }

    public static ReportFileType fromExtension(ClientFileDto.Extension extension) {
        return fromValue(extension.value().toUpperCase());
    }

    @Override
    public String toString() {
        return this.value;
    }

    public static String getFullExtension(ReportFileType t) {
        return "." + t.value.toLowerCase();
    }

    public static String getFileContentType(String i) {
        switch (fromValue(i.toUpperCase())) {
            case PDF:
                return "application/pdf";
            case XLS:
                return "application/vnd.ms-excel";
            case XLSX:
                return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case CSV:
                return "application/ms-excel";
            case JPG:
                return "image/jpeg";
            case PNG:
                return "image/png";
            case BMP:
                return "image/bmp";
            default:
                return null;
//                throw new InvalidFileTypeException();
        }
    }
}
