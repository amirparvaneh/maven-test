package com.caspian.ebanking.pars.api.service.business.rtgs.service;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.service.business.rtgs.dto.*;
import com.caspian.ebanking.pars.api.service.business.rtgs.utils.RtgsConverterUtils;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.coreservice.dto.ChOrderStatus;
import com.caspian.moderngateway.core.coreservice.dto.ChRtgTransferSearchRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.ChRtgsTransferStatus;
import com.caspian.moderngateway.core.message.RtgsTransferReportMsg;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۴/۰۱/۲۰۲۱ ۰۱:۱۵ بعدازظهر
 */
@Service
@RequiredArgsConstructor
public class RtgsServiceImpl extends BaseService implements RtgsService {
    private final RtgsConverterUtils rtgsConverterUtils;
    private final ParsModelMapper mapper;

    private static String getRandomAction() {

        String[] arr = {"DASTUR_SABT_SHODE",
                "VIRAYESH_SHODE",
                "TALIGH_DAEM",
                "TAEED_SHODE",
                "ADAM_TAEED_SHOBE",
                "TAEED_SHOBE_SATNA",
                "ADAM_TAEED_SHOBE_SATNA",
                "ERSAL_SHODE_BE_BANK_MAGHSAD",
                "VARIZ_SHODE_BE_BANK_MAGHSAD",
                "VARIZ_NASHODE_BE_BANK_MAGHSAD"};

        return arr[new Random().nextInt(9)];
    }

    public RtgsSingleTransferResponseDto singleTransfer(RtgsSingleTransferRequestDto requestDto) {
//        ChRtgsNormalTransferRequestBean rtgsNormalTransferRequestBean =
//                rtgsConverterUtils.convertToRtgsSingleTransferRequest(requestDto);
//        rtgsNormalTransferRequestBean.setCheckUniqueTrackingCode(Boolean.TRUE);
//        rtgsNormalTransferRequestBean.setUniqueTrackingCode(String.valueOf(System.currentTimeMillis()));
//
//        RtgsNormalTransferMsg.Inbound inbound = new RtgsNormalTransferMsg.Inbound();
//        inbound.setRtgsNormalTransferRequestBean(rtgsNormalTransferRequestBean);
//
//        ChNormalRtgsTransferResponseBean responseBean;
//        try {
//            RtgsNormalTransferMsg.Outbound outbound =
//                    channelManagerProvider.execute(inbound, RtgsNormalTransferMsg.Outbound.class);
//
//            responseBean = outbound.getNormalRtgsTransferResponseBean();
//            RtgsSingleTransferResponseDto responseDto = mapper.map(responseBean, RtgsSingleTransferResponseDto.class);
//            return responseDto;
//
//        } catch (ChannelManagerException e) {
//            throw new GatewayException(e);
//        }
        //TODO MOCK
        RtgsSingleTransferResponseDto responseDto = new RtgsSingleTransferResponseDto();
        responseDto.setBalance(new BigDecimal(new Random().nextInt(99999)));
        responseDto.setCurrency("IRR");
        responseDto.setId("56456456798");
        responseDto.setReceiverBankCode("1051");
        responseDto.setReceiverBankName("پاسارگاد");
        return responseDto;
    }

    @Override
    public RtgsTransferReportResponseDto transferReport(RtgsTransferReportRequestDto requestDto) {
        ChRtgTransferSearchRequestBean requestBean = mapper.map(requestDto, ChRtgTransferSearchRequestBean.class);
        requestBean.setStatus(requestDto.getStatus() != null ? ChRtgsTransferStatus.valueOf(requestDto.getStatus()) : null);
        requestBean.setOrder(requestDto.getOrder() != null ? ChOrderStatus.valueOf(requestDto.getOrder()) : null);

        RtgsTransferReportMsg.Inbound inbound = new RtgsTransferReportMsg.Inbound();
        inbound.setRtgTransferSearchRequestBean(requestBean);
        RtgsTransferReportMsg.Outbound outbound;
//        try {
//            outbound = channelManagerProvider.execute(inbound, RtgsTransferReportMsg.Outbound.class);
//        } catch (ChannelManagerException e) {
//            throw new GatewayException(e);
//        }
//        RtgsTransferReportResponseDto responseDto = RtgsConverterUtils.convertToRtgsTransferReportResponse(outbound.getRtgsTransferResponseBean());
        RtgsTransferReportResponseDto responseDto = new RtgsTransferReportResponseDto();
        List<RtgsTransferReportItemDto> list = new ArrayList<RtgsTransferReportItemDto>();
        for (int i = 0; i < 1000; i++) {
            RtgsTransferReportItemDto item = new RtgsTransferReportItemDto();
            item.setAmount(new BigDecimal(new Random().nextInt(99999999) + 1000));
            item.setBranchCode("1051");
            item.setBranchName("تختی");
            item.setDestinationBankCode("0124");
            item.setSerial("21346875646541");
            item.setSourceDepositNumber("85000005301002");
            item.setDestinationDepositNumber("");
//            item.setDestinationIban("IR68015100000192000014898");
            item.setStatus("SABT_SHODE");
            item.setRegisterDate(new Date());
            list.add(item);
        }
        responseDto.setStatus(true);
        responseDto.setTotalRecord((long) list.size());
        responseDto.setTransferDetailsDtos(list);
        return responseDto;
    }

    @Override
    public RtgsTransactionReportResponseDto transactionReport(RtgsTransactionReportRequestDto requestDto) {
//        ChRtgTransferDetailSearchRequestBean requestBean = mapper.map(requestDto, ChRtgTransferDetailSearchRequestBean.class);
//        RtgsTransferDetailReportMsg.Outbound outbound;
//        RtgsTransferDetailReportMsg.Inbound inbound = new RtgsTransferDetailReportMsg.Inbound();
//        inbound.setSearchRequestBean(requestBean);
//        try {
//            outbound = channelManagerProvider.execute(inbound, RtgsTransferDetailReportMsg.Outbound.class);
//        } catch (ChannelManagerException e) {
//            throw new GatewayException(e);
//        }
//
//        RtgsTransactionReportResponseDto responseDto = RtgsConverterUtils.convertToRtgsTransactionReportResponse(outbound.getResponseBean());
//        return responseDto;

        RtgsTransactionReportResponseDto responseDto = new RtgsTransactionReportResponseDto();
        List<RtgsTransactionReportItemDto> list = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            RtgsTransactionReportItemDto item = new RtgsTransactionReportItemDto();
            item.setActionType(getRandomAction());
            item.setDate(new Date());
            item.setSerial("5156465564");
            list.add(item);
        }
        responseDto.setStatusDtos(list);
        responseDto.setTotalRecord((long) list.size());

        return responseDto;

    }

}
