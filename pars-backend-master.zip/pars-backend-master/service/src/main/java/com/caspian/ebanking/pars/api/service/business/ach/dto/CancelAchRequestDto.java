package com.caspian.ebanking.pars.api.service.business.ach.dto;

import lombok.Data;

/**
 * @author atousa khanjani
 * @since 12/29/2020 07:34 PM
 */
@Data
public class CancelAchRequestDto {
    private String comment;
    private String referenceId;

}
