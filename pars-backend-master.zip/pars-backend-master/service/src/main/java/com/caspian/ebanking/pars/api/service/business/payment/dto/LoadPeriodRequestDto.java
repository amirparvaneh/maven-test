package com.caspian.ebanking.pars.api.service.business.payment.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/07/2021 07:18 PM
 */
@Data
public class LoadPeriodRequestDto {
    @ApiModelProperty(value = "شماره حساب")
    private String accountId;
    private String periodCode;
}
