package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.service;

import com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto.*;


/**
 * @author atousa khanjani
 * @version 1.0
 * @since 1/4/2021 12:36 PM
 */
public interface FileGroupTransferService {
    RegisterGroupTransferResponseDto registerGroupTransfer(RegisterGroupTransferRequestDto requestDto);

    SearchGroupTransferResponseDto searchGroupTransfer(SearchGroupTransferRequestDto requestDto);

    SearchGroupTransferDetailResponseDto searchGroupTransferDetail(SearchGroupTransferDetailRequestDto requestDto);

    GroupTransferDto cancelGroupTransfer(CancelGroupTransferDto cancelGroupTransferDto);

    GroupTransferDetailDto cancelGroupTransferDetail(CancelGroupTransferDetailDto cancelGroupTransferDetailDto);

    GetGroupTransferConfigResponseDto getGroupTransferConfig();

    FinalConfirmGroupTransferResponseDto finalConfirmGroupTransfer(FinalConfirmGroupTransferRequestDto requestDto);

    RegisterCartableGroupFileTransferResponseDto registerCartableGroupFileTransfer(RegisterCartableGroupFileTransferRequestDto requestDto);


}
