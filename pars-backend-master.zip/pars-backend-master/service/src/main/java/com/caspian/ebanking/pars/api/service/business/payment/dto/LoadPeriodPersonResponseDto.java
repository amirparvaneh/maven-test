package com.caspian.ebanking.pars.api.service.business.payment.dto;

import com.caspian.moderngateway.core.coreservice.dto.epayment.ChPeriodPersonBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/07/2021 07:18 PM
 */
@Data
public class LoadPeriodPersonResponseDto {
    private List<LoadPeriodPersonDto> periodPersonDtoList;
}