package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 11:38 PM
 */
@Data
public class DocumentsIssuedDto {
    private String accountNumber;
    private String settleTitle;
    private Date date;
    private Date registrationDocTime;
    private Integer branchCode;
    private String liquidator;
    private String referenceCode;
    private String docNumber;
    private BigDecimal amount;
}
