package com.caspian.ebanking.pars.api.service.business.user;

import com.caspian.ebanking.pars.api.base.exception.BadRequestException;
import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import com.caspian.ebanking.pars.api.base.persistence.repositories.ClientDataControlRepository;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.security.captcha.CaptchaVerificationService;
import com.caspian.ebanking.pars.api.base.security.dto.LoginRequest;
import com.caspian.ebanking.pars.api.base.security.dto.LoginResponse;
import com.caspian.ebanking.pars.api.base.security.dto.OrganizationRelDto;
import com.caspian.ebanking.pars.api.base.utils.CollectionUtils;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.GetUserOrganizationsResponseDto;
import com.caspian.ebanking.pars.api.service.business.user.dto.ChangePasswordRequestDto;
import com.caspian.ebanking.pars.api.service.business.user.dto.ChangeUsernameRequestDto;
import com.caspian.ebanking.pars.api.service.business.user.enums.SecondPasswordType;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.ChChangePasswordRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.ChChangeUsernameRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.ChSecondPasswordRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.ChUserInfoRequestBean;
import com.caspian.moderngateway.core.domainmodel.dto.valuablecustomer.UserOrganizationRelBean;
import com.caspian.moderngateway.core.message.*;
import com.caspian.moderngateway.core.message.valuablecustomer.GetUserOrganizationRelListMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.SetVCOrganizationInContextMsg;
import com.caspian.moderngateway.infrastructurespi.common.message.ChMessageHeader;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

import static com.caspian.ebanking.pars.api.base.utils.ChannelUtils.convertClientDataControlToChMessageHeader;
import static com.caspian.ebanking.pars.api.base.utils.ConvertUtils.convertHeadersToClientDataControl;


/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 2:32 PM
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class UserServiceImpl extends BaseService implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    private final ClientDataControlRepository clientDataControlRepository;
    private final CurrentUserService currentUserService;
    private final CaptchaVerificationService captchaVerificationService;

    @Override
    public LoginResponse login(LoginRequest requestDto, HttpServletRequest request) {
        logger.info("********** Login Service Called ************");
        logger.info("session id: " + request.getSession().getId());

        captchaVerificationService.validateLoginCaptcha(requestDto.getCaptchaChallengeKey(), requestDto.getCaptcha());

        final ClientDataControl clientDataControl = convertHeadersToClientDataControl(request);

        ChUserInfoRequestBean userInfoRequestBean = new ChUserInfoRequestBean();
        userInfoRequestBean.setUsername(requestDto.getUsername());
        userInfoRequestBean.setPassword(requestDto.getPassword());

        LoginStaticMsg.Inbound inbound = new LoginStaticMsg.Inbound();
        inbound.setChUserInfoRequestBean(userInfoRequestBean);

        try {
            final ChMessageHeader headers = convertClientDataControlToChMessageHeader(clientDataControl);
            LoginStaticMsg.Outbound loginData = channelManagerProvider.execute(headers, inbound, LoginStaticMsg.Outbound.class, false);
            logger.info("********** Login Service Successful for user: " + requestDto.getUsername() + "************");
            final GetUserOrganizationsResponseDto organizationData = this.handleOrganizationData(headers, requestDto.getUsername(), loginData.getChLoginResponseBean().getSessionId());

            final Date dt = new Date();
            final String customerNo = String.valueOf(loginData.getChLoginResponseBean().getCustomerNo());

            final LoginResponse response = mapper.map(loginData.getChLoginResponseBean(), LoginResponse.class);
            response.setIssuedAt(dt.getTime());

            if (organizationData != null && !CollectionUtils.isNullOrEmpty(organizationData.getOrganizationRelDtoList())) {
                response.setOrganizations(organizationData.getOrganizationRelDtoList());
                if (organizationData.getOrganizationRelDtoList().size() == 1) {
                    clientDataControl.setSelectedOrganizationId(organizationData.getOrganizationRelDtoList().get(0).getOrganizationId());
                    clientDataControl.setSelectedDepartmentId(organizationData.getOrganizationRelDtoList().get(0).getDepartmentId());
                }
            }

            clientDataControl.setUsername(requestDto.getUsername());
            clientDataControl.setCustomerCode(customerNo);
            clientDataControl.setLastActiveTime(dt);
            clientDataControl.setRequestsNum(0);
            clientDataControl.setFailedRequestsNum(0);
            clientDataControl.setChannelSessionId(loginData.getChLoginResponseBean().getSessionId());

            clientDataControlRepository.deleteAllByCustomerCode(customerNo);
            clientDataControlRepository.save(clientDataControl);

            return response;
        } catch (ChannelManagerException e) {
            e.printStackTrace();
            throw new GatewayException();
        } catch (Exception e) {
            e.printStackTrace();
            logger.warn(e.getMessage());
            throw e;
        }
    }

    private GetUserOrganizationsResponseDto handleOrganizationData(ChMessageHeader headers, String username, String sessionId) throws ChannelManagerException {
        GetUserOrganizationRelListMsg.Inbound inbound = new GetUserOrganizationRelListMsg.Inbound();
        inbound.setUserName(username);

        final GetUserOrganizationRelListMsg.Outbound userOrganizationsList = channelManagerProvider.execute(headers, inbound, GetUserOrganizationRelListMsg.Outbound.class, false);

        if (userOrganizationsList.getResponseBean() != null) {
            if (userOrganizationsList.getResponseBean().size() == 1) {
                UserOrganizationRelBean userOrganizationRelBean = userOrganizationsList.getResponseBean().get(0);
                SetVCOrganizationInContextMsg.Inbound i = new SetVCOrganizationInContextMsg.Inbound();
                i.setRequestBean(userOrganizationRelBean);

                channelManagerProvider.execute(headers, i, SetVCOrganizationInContextMsg.Outbound.class, sessionId);
            }
            return new GetUserOrganizationsResponseDto(mapper.mapList(userOrganizationsList.getResponseBean(), OrganizationRelDto.class));
        }
        return null;
    }

    @Override
    public ResultDto changeUsername(ChangeUsernameRequestDto requestDto) {
        ChangeUsernameMsg.Inbound inbound = new ChangeUsernameMsg.Inbound();
        inbound.setRequestBean(mapper.map(requestDto, ChChangeUsernameRequestBean.class));

        try {
            channelManagerProvider.execute(inbound, ChangeUsernameMsg.Outbound.class);
            currentUserService.removeAllClientDataControlData();
            return ResultDto.success();
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto changePassword(ChangePasswordRequestDto requestDto) {
        try {
            final SecondPasswordType secondPasswordType = Enum.valueOf(SecondPasswordType.class, requestDto.getPasswordType());

            switch (secondPasswordType) {
                case LOGIN:
                    return changeLoginPassword(requestDto);
                case TRANSFER_SECOND_PASS:
                    return changeTransferSecondPassword(requestDto);
                default:
                    throw new BadRequestException();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    private ResultDto changeTransferSecondPassword(ChangePasswordRequestDto requestDto) throws ChannelManagerException {
        SaveOrUpdateSecondPasswordMsg.Inbound inbound = new SaveOrUpdateSecondPasswordMsg.Inbound();
        inbound.setRequestBean(mapper.map(requestDto, ChSecondPasswordRequestBean.class));
        channelManagerProvider.execute(inbound, SaveOrUpdateSecondPasswordMsg.Outbound.class);
        return ResultDto.success();
    }

    private ResultDto changeLoginPassword(ChangePasswordRequestDto requestDto) throws ChannelManagerException {
        ChangePasswordMsg.Inbound inbound = new ChangePasswordMsg.Inbound();
        inbound.setRequestBean(mapper.map(requestDto, ChChangePasswordRequestBean.class));
        channelManagerProvider.execute(inbound, ChangePasswordMsg.Outbound.class);
        return ResultDto.success();
    }

    @Override
    public ResultDto logout() {
        try {
            channelManagerProvider.execute(new LogoutMsg.Inbound(), LogoutMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        } finally {
            currentUserService.removeAllClientDataControlData();
        }
        return ResultDto.success();
    }
}
