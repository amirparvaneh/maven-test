package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import com.caspian.moderngateway.core.message.dto.CartableApprovalRequestDto;
import com.caspian.moderngateway.core.message.dto.CartableTransferRequestEntryDto;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/5/2021 1:45 PM
 */
@Data
public class SingleCartableNormalFundTransferResponseDto {
    private Long id;
    private String requestCode;
    private Date requestDate;
    private Date expireDate;
    private String description;
    private Character priority;
    private String accountNumber;
    private Character status;
    private CartableTransferRequestEntryDto transferRequestEntryDto;
    private String withdrawConditionCode;
    private List<CartableApprovalRequestDto> cartableApprovalRequestDtos;
    private Long version;
    private Date updateSysDate;
}
