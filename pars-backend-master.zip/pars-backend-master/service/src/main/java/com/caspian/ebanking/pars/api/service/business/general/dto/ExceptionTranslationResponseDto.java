package com.caspian.ebanking.pars.api.service.business.general.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/23/2020 7:58 PM
 */
@Data
@AllArgsConstructor
public class ExceptionTranslationResponseDto {
    private String exceptionType, translation;
}
