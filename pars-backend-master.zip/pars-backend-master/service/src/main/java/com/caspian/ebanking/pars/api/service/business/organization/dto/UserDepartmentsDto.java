package com.caspian.ebanking.pars.api.service.business.organization.dto;

import com.caspian.ebanking.pars.api.service.business.account.dto.UserAccountDto;
import com.caspian.moderngateway.core.message.valuablecustomer.dto.DepartmentDTO;
import com.caspian.moderngateway.core.message.valuablecustomer.dto.VCAccountDTO;
import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۱۲:۲۶ بعدازظهر
 */
@Data
public class UserDepartmentsDto {
    private Date insertSysdate;
    private Date updateSysdate;
    private Long organization;
    private String organizationTitle;
    private Long parentId;
    private List<UserDepartmentsDto> children = new ArrayList();
    private String insertUser;
    private String nodeFullParentPath;
    private String nodeFullParentTitles;
    private String title;
    private String updateUser;
    private long id;
    private List<UserAccountDto> accountDTOs = new ArrayList();
    private List<UserAccountDto> transitiveAccountDTOs = new ArrayList();
    private BigDecimal totalBalance;
    private Date totalBalanceUpdate;
    private String customerNumber;
}