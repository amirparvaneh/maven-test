package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۳/۰۱/۲۰۲۱ ۰۳:۱۴ قبل‌ازظهر
 */
@Data
public class CartableRequestDto {
    private String requestCode;
    @ApiModelProperty(value = "نوع درخواست", allowableValues = " TRANSFER,BATCH_TRANSFER,STANDING_ORDER,ACH_NORMAL_TRANSFER,ACH_BATCH_TRANSFER," +
            "ACH_BATCH_TRANSFER,ACH_STANDING_ORDER_TRANSFER,FILE_GROUP_TRANSFER")
    private String requestType;

    @ApiModelProperty(value = "وضعیت", allowableValues = "REGISTERED,CONFORMED,REJECTED,CANCELED,UBSUCCEEDED,SUCCEEDED,EXPIRED")
    private String status;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fromRequestDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date toRequestDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fromExpireDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date toExpireDate;

    @ApiModelProperty(value = "اولویت", allowableValues = "MAJOR,CRITICAL,MINOR,TRIVIAL")
    private String priority;

    private Boolean operational;
    private Boolean loadApproval;

    @ApiModelProperty(value = "درخواست کننده")
    private Long clientId;

    private String description;
}