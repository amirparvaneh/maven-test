package com.caspian.ebanking.pars.api.service.business.payment.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class BillPaymentReportRequestDto {

    @ApiModelProperty(value = "شناسه قبض")
    private String billNumber;
    @ApiModelProperty(value = "نوع ", allowableValues = "billType_Water,billType_Electricity," +
            "billType_Gas,billType_IMmobilePhone,billType_MobilePhone,billType_MunicipalityDue,billType_InternalBills,billType_OtherBillIssuers")
    private Integer billType;
    @ApiModelProperty(value = "شماره پیگیری")
    private Integer tracingNumber;
    @ApiModelProperty(value = "از تاریخ")
    private Date fromDate;
    @ApiModelProperty(value = "تا تاریخ")
    private Date toDate;
    @ApiModelProperty(value = "ازمبلغ")
    private BigDecimal fromBillAmount;
    @ApiModelProperty(value = "تا مبلغ")
    private BigDecimal toBillAmount;
    @ApiModelProperty(value = "شناسه پرداخت")
    private String paymentNumber;
    private String configCode;
}
