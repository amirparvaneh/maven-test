package com.caspian.ebanking.pars.api.service.business.offlineStatement.service;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.service.business.file.dto.ClientFileDto;
import com.caspian.ebanking.pars.api.service.business.file.utils.FileReaderWriterService;
import com.caspian.ebanking.pars.api.service.business.file.utils.FileUtils;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementReportResponseDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementRequestDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementResponseDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.enums.ReportFileType;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.utils.OfflineStatementConverterUtils;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.ChStatementSearchDirection;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChGetOfflineStatementDownloadInfoRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChGetOfflineStatementReportRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChOfflineStatementRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChOfflineStatementType;
import com.caspian.moderngateway.core.message.offlinestatement.GetOfflineStatementDownloadInfoMsg;
import com.caspian.moderngateway.core.message.offlinestatement.GetOfflineStatementReportMsg;
import com.caspian.moderngateway.core.message.offlinestatement.OfflineStatementRequestMsg;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۴/۰۱/۲۰۲۱ ۰۸:۵۵ قبل‌ازظهر
 */
@Service
@RequiredArgsConstructor
public class OfflineStatementServiceImpl extends BaseService implements OfflineStatementService {

    private final OfflineStatementConverterUtils offlineUtils;
    private final CurrentUserService currentUserService;
    private final FileReaderWriterService fileReaderWriterService;



    @Override
    public OfflineStatementResponseDto offlineStatementRequest(OfflineStatementRequestDto requestDto,ChOfflineStatementType offlineStatementType) {
        OfflineStatementRequestMsg.Inbound inbound = new OfflineStatementRequestMsg.Inbound();
        ChOfflineStatementRequestBean requestBean = offlineUtils.convertToOfflineStatementRequest(requestDto);
        requestBean.setChStatementSearchDirection(ChStatementSearchDirection.START_TO_END);
        requestBean.setChOfflineStatementType(offlineStatementType);
        inbound.setChOfflineStatementRequestBean(requestBean);
        OfflineStatementResponseDto responseDto = new OfflineStatementResponseDto();
       try {
            final OfflineStatementRequestMsg.Outbound result = channelManagerProvider.execute(inbound,
                    OfflineStatementRequestMsg.Outbound.class);
            responseDto.setRequestId(result.getChOfflineStatementRequestResultBean().getRequestId());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        return responseDto;
    }

    @Override
    public OfflineStatementReportResponseDto getOfflineStatementReport(Date fromDate, Date toDate,ChOfflineStatementType offlineStatementType) {

        ChGetOfflineStatementReportRequestBean getOfflineStatementReportRequestBean = OfflineStatementConverterUtils.getOfflineStatementReportRequest(fromDate,toDate);
        getOfflineStatementReportRequestBean.setChOfflineStatementType(offlineStatementType);
        GetOfflineStatementReportMsg.Inbound inbound = new GetOfflineStatementReportMsg.Inbound();
        inbound.setChGetOfflineStatementReportRequestBean(getOfflineStatementReportRequestBean);

        try {
            GetOfflineStatementReportMsg.Outbound result = channelManagerProvider.execute(inbound, GetOfflineStatementReportMsg.Outbound.class);
            return OfflineStatementConverterUtils.getOfflineStatementReportResponseDto(result.getChGetOfflineStatementReportResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public void downloadOfflineStatementFile(Long requestId, String fileType, HttpServletResponse response) {
        GetOfflineStatementDownloadInfoMsg.Inbound inbound = new GetOfflineStatementDownloadInfoMsg.Inbound();
        final ChGetOfflineStatementDownloadInfoRequestBean requestBean = new ChGetOfflineStatementDownloadInfoRequestBean();
        requestBean.setType(ChOfflineStatementType.NORMAL);
        requestBean.setRequestId(requestId);

        inbound.setChGetOfflineStatementReportRequestBean(requestBean);

        final ClientFileDto.Extension extension = ClientFileDto.Extension.convert(fileType);

        try {
            final GetOfflineStatementDownloadInfoMsg.Outbound execute = channelManagerProvider.execute(inbound, GetOfflineStatementDownloadInfoMsg.Outbound.class);

            final ClientFileDto dto = new ClientFileDto((extension == ClientFileDto.Extension.xls || extension == ClientFileDto.Extension.xlsx) ? execute.getChGetOfflineStatementReportResponseBean().getDownloadUrl() : execute.getChGetOfflineStatementReportResponseBean().getPdfDownloadUrl(), "Offline_Statement_Report", extension);

            final byte[] data = fileReaderWriterService.readFileBytes(dto);

            final Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(System.currentTimeMillis());
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            if (data != null) {
                FileUtils.writeToResponse(data,
                        ReportFileType.fromExtension(dto.getExtension()),
                        "Offline_Statement_Report-" + currentUserService.getCustomerCode() + "-" + format.format(calendar.getTime()),
                        response);
            } else {
                throw new GatewayException();
            }
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

}
