package com.caspian.ebanking.pars.api.service.business.payment.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/07/2021 07:18 PM
 */
@Data
public class LoadPeriodHistoryResponseDto {
    private List<PeriodRequestDto> periodDtoList;
}
