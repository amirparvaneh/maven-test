package com.caspian.ebanking.pars.api.service.business.user.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/6/2021 10:51 AM
 */
@Data
@ApiModel
public class ChangeUsernameRequestDto {
    private String currentUsername, newUsername;
}
