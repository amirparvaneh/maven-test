package com.caspian.ebanking.pars.api.service.business.captcha;

import com.caspian.ebanking.pars.api.service.business.captcha.dto.LoginCaptchaResponseDto;
import nl.captcha.Captcha;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 11:33 AM
 */
public interface CaptchaService {

    LoginCaptchaResponseDto generateCaptchaForLogin(String id);

    Captcha generateCaptchaForVerification();

}
