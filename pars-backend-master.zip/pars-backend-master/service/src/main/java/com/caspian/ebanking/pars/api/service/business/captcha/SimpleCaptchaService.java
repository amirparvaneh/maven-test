package com.caspian.ebanking.pars.api.service.business.captcha;

import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.security.captcha.CaptchaVerificationService;
import com.caspian.ebanking.pars.api.base.security.dto.enums.CaptchaType;
import com.caspian.ebanking.pars.api.base.utils.CryptoUtils;
import com.caspian.ebanking.pars.api.base.utils.ImageUtils;
import com.caspian.ebanking.pars.api.service.business.captcha.dto.LoginCaptchaResponseDto;
import nl.captcha.Captcha;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 11:33 AM
 */
@Service
public class SimpleCaptchaService implements CaptchaService {

    private static final Logger logger = LoggerFactory.getLogger(SimpleCaptchaService.class);

    private final CurrentUserService currentUserService;
    private final CaptchaVerificationService captchaVerificationService;

    @Autowired
    public SimpleCaptchaService(CaptchaVerificationService captchaVerificationService, CurrentUserService currentUserService) {
        this.captchaVerificationService = captchaVerificationService;
        this.currentUserService = currentUserService;
    }

    @Override
    public LoginCaptchaResponseDto generateCaptchaForLogin(String uniqueId) {
        Captcha captcha = captchaVerificationService.generateCaptchaImage();
        String challengeKey = CryptoUtils.hashSHA256(uniqueId + UUID.randomUUID().toString());
        captchaVerificationService.persist(challengeKey, captcha.getAnswer(), CaptchaType.LOGIN);
        return new LoginCaptchaResponseDto(ImageUtils.imgToBase64String(captcha.getImage(), "PNG"), challengeKey);
    }

    @Override
    public Captcha generateCaptchaForVerification() {
        Captcha captcha = captchaVerificationService.generateCaptchaImage();
        captchaVerificationService.persist(currentUserService.getClientDataControl().getUniqueInfo(), captcha.getAnswer(), CaptchaType.VERIFICATION);
        return captcha;
    }
}
