package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChGetReferenceCodeStatementByChequeResponseBean;
import lombok.Data;

import java.util.List;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/05/2021 11:38 AM
 */
@Data
public class GetReferenceCodeStatementByChequeResponseDto {
    private List<GetReferenceCodeStatementByChequeDto> responseBeanList;
    private String total;

}
