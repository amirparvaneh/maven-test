package com.caspian.ebanking.pars.api.service.business.file.exception;


public class InvalidFileTypeException extends RuntimeException {

    public InvalidFileTypeException() {
    }

}
