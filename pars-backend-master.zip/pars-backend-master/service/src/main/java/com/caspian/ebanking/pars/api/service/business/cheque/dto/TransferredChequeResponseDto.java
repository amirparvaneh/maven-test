package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChTransferChequeBean;
import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۷/۰۲/۲۰۲۱ ۰۱:۵۶ بعدازظهر
 */
@Data
public class TransferredChequeResponseDto {
    private Integer totalRecord;
    private List<TransferredChequeResponseItemDto> itemDtoList;
}