package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 01/21/2021 9:53 AM
 */
@Data
public class CartableRequestCodeDto {
    private String requestCode;
}
