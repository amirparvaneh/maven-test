package com.caspian.ebanking.pars.api.service.business.payment.dto;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class BillPaymentRequestDto {

    private String captcha;
    private String cvv2;
    @ApiModelProperty(name = "تارخ انقضا کارت")
    private String expireDate;
    @ApiModelProperty(name = "رمز کارت")
    private String pin;
    @ApiModelProperty(name = "مبلغ قبض")
    private BigDecimal billAmount;
    @ApiModelProperty(name = "شماره کارت")
    private String sourceCardNumber;
    private Boolean requireVerification = false;
    private Long verificationExpirationTimeOut;
    @ApiModelProperty(name = "ایمیل")
    private String email;
    @ApiModelProperty(name = "شناسه قبض")
    private String billId;
    @ApiModelProperty(name = "شناسه پرداخت")
    private String paymentId;

}
