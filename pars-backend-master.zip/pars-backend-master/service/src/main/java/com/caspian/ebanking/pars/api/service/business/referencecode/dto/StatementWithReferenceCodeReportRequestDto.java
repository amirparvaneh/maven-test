package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChStatementSearchDirection;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۳/۰۲/۲۰۲۱ ۰۹:۴۳ قبل‌ازظهر
 */
@Data
public class StatementWithReferenceCodeReportRequestDto {
    @ApiModelProperty(value = "شماره حساب")
    @NotNull
    private String accountNumber;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fromDate;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date toDate;
    @ApiModelProperty(value = "از ساعت")
    private String fromDateTime;
    @ApiModelProperty(value = "تا ساعت")
    private String toDateTime;
    private BigDecimal fromAmount;
    private BigDecimal toAmount;
    private Long length;
    private Long offset;
    @ApiModelProperty(value = "ترتیب", allowableValues = "ASC,DESC")
    private String statementSearchDirection;
}