package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۶/۰۱/۲۰۲۱ ۰۹:۵۲ قبل‌ازظهر
 */
@Data
public class IssuedRemittanceReportResponseDto {
    private List<IssuedRemittanceReportItemDto> reportItemDtoList;
}