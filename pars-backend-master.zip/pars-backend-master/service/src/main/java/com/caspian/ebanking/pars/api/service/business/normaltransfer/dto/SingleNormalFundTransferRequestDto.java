package com.caspian.ebanking.pars.api.service.business.normaltransfer.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/5/2021 9:56 AM
 */
@Data
@ApiModel
public class SingleNormalFundTransferRequestDto {

    @ApiModelProperty("شماره حساب مبدا")
    private String sourceAccount;

    @ApiModelProperty("شماره حساب مقصد")
    private String destinationAccount;

    @ApiModelProperty("رمز انتقال")
    private String password;

    @ApiModelProperty("مبلغ")
    private BigDecimal amount;

    @ApiModelProperty("یادداشت فرستنده")
    private String sourceComment;

    @ApiModelProperty("یادداشت گیرنده")
    private String destinationComment;

    private String additionalDocumentDesc;
    private String referenceNumber;

    @ApiModelProperty("ایمیل")
    private String email;

    @ApiModelProperty(value = "نوع رمز", allowableValues = "TRANSFER_SECOND_PASS,OTP")
    private String passwordType;

    private String uniqueTrackingNumber;
    private boolean checkTrackingCode;
}
