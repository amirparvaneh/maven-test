package com.caspian.ebanking.pars.api.service.business.normaltransfer.dto;

import lombok.Data;

import java.util.Date;

/**
 * @author atousa khanjani
 * @since 01/27/2021 07:34 PM
 */
@Data
public class AutoNormalTransferResponseDetail {
    private String sourceDepositNumber;
    private String sourceDestinationNumber;
    private String serial;
    private Short successTransactionNumber;
    private String note;
    private Date endDate;
    private Date startDate;
    private String status;
    private Short transactionCount;
    private Boolean disable;
    private Date registerDate;
    private Long unProcessedCount;
    private Long failedCount;
    private Long suspendedCount;
    private Boolean cancelable;
}