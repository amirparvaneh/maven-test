package com.caspian.ebanking.pars.api.service.business.organization.service;

import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.UserDepartmentsDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.GetUserOrganizationsResponseDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.OrganizationUsersResponseDto;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/6/2021 10:13 AM
 */
public interface OrganizationService {
    GetUserOrganizationsResponseDto getUserOrganizations();

    ResultDto setOrganization(Long organizationId);

    OrganizationUsersResponseDto getOrganizationUsers();

    UserDepartmentsDto getUserDepartments();
}
