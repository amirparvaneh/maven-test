package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import lombok.Data;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۱/۰۲/۲۰۲۱ ۱۰:۵۵ قبل‌ازظهر
 */
@Data
public class CreateReferenceCodeResponseDto {
    private String referenceCode;
}