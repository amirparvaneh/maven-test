package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author atousa khanjani
 * @since 01/27/2021 07:34 PM
 */
@Data
public class GroupTransferDto {
    private String title;
    private String sourceAccountNumber;
    private Date effectiveDate;
    private Integer clientTotalNumber;
    private BigDecimal clientTotalAmount;
    private String trackingCode;
    private String description;
    private String Status;
    private List<GroupTransferFileDto> groupTransferFileDtoList;
}
