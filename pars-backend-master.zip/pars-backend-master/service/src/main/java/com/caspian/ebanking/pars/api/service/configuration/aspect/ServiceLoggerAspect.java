package com.caspian.ebanking.pars.api.service.configuration.aspect;

import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import com.caspian.ebanking.pars.api.base.persistence.entities.ServiceLog;
import com.caspian.ebanking.pars.api.base.persistence.repositories.ServiceLogRepository;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

import java.util.Date;

import static com.caspian.ebanking.pars.api.base.utils.AspectUtils.getMethodName;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/17/2020 11:12 PM
 */
@Aspect
@Service
@Order(1)
@ConditionalOnProperty(prefix = "logging", name = "enable-service-logging", havingValue = "true")
public class ServiceLoggerAspect {

    private static final Logger logger = LoggerFactory.getLogger(ServiceLoggerAspect.class);

    private final ServiceLogRepository repository;
    private final CurrentUserService currentUserService;

    @Autowired
    public ServiceLoggerAspect(ServiceLogRepository repository, CurrentUserService currentUserService) {
        this.repository = repository;
        this.currentUserService = currentUserService;
    }

    @Pointcut("within(com.caspian.ebanking.pars.api.service.business..*)")
    private void businessServiceExecution() {
    }

    @Around(value = "businessServiceExecution()", argNames = "joinPoint")
    public Object aroundBusinessService(ProceedingJoinPoint joinPoint) throws Throwable {
        final long start = System.currentTimeMillis();
        final String signature = getMethodName(joinPoint);
        boolean isSuccess = true;

        final ServiceLog serviceLog = new ServiceLog();
        final ClientDataControl clientDataControl = currentUserService.getClientDataControl();
        if (clientDataControl != null)
            serviceLog.setClientFullInfo(clientDataControl.toString());
        serviceLog.setServiceName(signature);

        logger.info("Executing Service: " + signature);

        try {
            return joinPoint.proceed();
        } catch (Throwable e) {
            logger.warn("Exception in Service: " + e.getMessage());
            isSuccess = false;
            throw e;
        } finally {
            final long totalTime = System.currentTimeMillis() - start;
            logger.info("Service Execution finished: " + signature);
            logger.info("Execution Time: " + totalTime);
            if (totalTime > 1000) {
                logger.warn("Long Running Request: " + signature);
            }
            serviceLog.setExecutionTime(totalTime);
            serviceLog.setIsSuccessful(isSuccess);
            serviceLog.setCreated(new Date());
            try {
                repository.save(serviceLog);
            } catch (Exception e){
                e.printStackTrace();
                logger.warn("Service Log Failed to persist Data: " + e.getMessage());
            }
        }
    }
}
