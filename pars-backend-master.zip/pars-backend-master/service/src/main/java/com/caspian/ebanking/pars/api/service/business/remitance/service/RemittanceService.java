package com.caspian.ebanking.pars.api.service.business.remitance.service;

import com.caspian.ebanking.pars.api.service.business.remitance.dto.*;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۱۰:۰۷ قبل‌ازظهر
 */
public interface RemittanceService {
    CurrencyRemittanceReportResponseDto currencyRemittanceReport(CurrencyRemittanceReportRequestDto requestDto);

    DocumentaryCreditsReportResponseDto documentaryCreditsReport(DocumentaryCreditsReportRequestDto requestDto);

    GuarantyReportResponseDto guarantyReport(GuarantyReportRequestDto requestDto);

    IssuedRemittanceReportResponseDto issuedRemittanceReport(IssuedRemittanceReportRequestDto requestDto);
}
