package com.caspian.ebanking.pars.api.service.business.test;

//import com.caspian.ebanking.pars.api.base.spi.ParsChannelManagerProvider;

import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import com.caspian.ebanking.pars.api.base.persistence.repositories.ClientDataControlRepository;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.spi.ParsChannelManagerProvider;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.test.dto.AddRequestDto;
import com.caspian.ebanking.pars.api.service.business.test.dto.AddResponseDto;
import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.exception.ChAccountNotFoundException;
import com.caspian.moderngateway.core.coreservice.exception.ChInvalidAmountException;
import com.caspian.moderngateway.core.valuablecustomer.service.exception.ChInvalidDepartmentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/13/2020 3:09 PM
 */
@Service
@Profile("dev")
public class TestServiceImpl implements TestService {

    private static final Logger logger = LoggerFactory.getLogger(TestServiceImpl.class);

    private final ParsChannelManagerProvider channelManagerProvider;
    private final ClientDataControlRepository clientDataControlRepository;
    private final CurrentUserService currentUserService;

    @Autowired
    public TestServiceImpl(ParsChannelManagerProvider channelManagerProvider, ClientDataControlRepository clientDataControlRepository, CurrentUserService currentUserService) {
        this.channelManagerProvider = channelManagerProvider;
        this.clientDataControlRepository = clientDataControlRepository;
        this.currentUserService = currentUserService;
    }


    @Override
    public List<ClientDataControl> getClientDataControl() {
        return clientDataControlRepository.getAllByCustomerCode(currentUserService.getCustomerCode());
    }


    @Override
    public AddResponseDto add(AddRequestDto requestDto) {
        return new AddResponseDto() {{
            setResult(requestDto.getA() + requestDto.getB());
        }};
    }

    @Override
    public ResultDto subtract(int a, int b) throws Exception {
        if (a < b)
            throw new Exception("test");
        return ResultDto.success(a - b);
    }

    @Override
    public ResultDto randomException() {
        final int random = new Random().nextInt(5);

        if (random == 0)
            throw new GatewayException(new ChannelManagerException("Unknown Error"));

        if (random == 1)
            throw new GatewayException(new ChInvalidAmountException("invalid amount"));

        if (random == 3)
            throw new GatewayException(new ChInvalidDepartmentException());

        if (random == 4)
            throw new GatewayException(new ChAccountNotFoundException("account not found"));

        return ResultDto.success();
    }
}
