package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۷/۰۲/۲۰۲۱ ۰۹:۱۶ قبل‌ازظهر
 */
@Data
public class BlockChequeRequestDto {
    @ApiModelProperty(value = "َعلت انسداد", allowableValues = "FORGE,ROBBERY,FRAUD,LOSS")
    private String blockedReason;
    @ApiModelProperty(value = "شماره چک ها(به صورت لیست جدا شده با کاما)")
    private String chequeNumbers;
    private String depositNumber;
}
