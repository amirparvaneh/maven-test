package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۰۱:۰۵ بعدازظهر
 */
@Data
public class DocumentaryCreditsReportItemDto {
    private String creditNumber;

    @ApiModelProperty(value = "تاریخ گشایش")
    private Date openingDate;

    private Date expireDate;

    private BigDecimal amount;

    @ApiModelProperty(value = "مبلغ اعتبار زمان گشایش")
    private BigDecimal openingTimeAmount;

    @ApiModelProperty(value = "نوع ارز")
    private String currencyType;

    @ApiModelProperty(value = "نرخ ارز")
    private BigDecimal currencyRate;

    @ApiModelProperty(value = "نوع اعتبار")
    private String creditType;



}