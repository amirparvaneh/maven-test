package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class RegisterChequeDto {

    private String account;
    private String noteNumber;
    private BigDecimal amount;
    private String payee;
    private String description;
    private Date date;
}
