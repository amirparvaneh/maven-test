package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۱۰:۰۵ قبل‌ازظهر
 */
@Data
public class CurrencyRemittanceReportRequestDto {
    @ApiModelProperty(value = "شماره برات")
    private String remittanceNumber;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "از تاریخ گشایش")
    private Date fromOpeningDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تا تاریخ گشایش")
    private Date toOpeningDate;

    @ApiModelProperty(value = "وضعیت",allowableValues = "REGIGSTERD,READY_FOR_ACCEPT,CONFIRMED")
    private String status;

    @ApiModelProperty(value = "نوع برات",allowableValues = "GUARANTEED,CURRENCY")
    private String remittanceType;

    private BigDecimal fromAmount;
    private BigDecimal toAmount;

    @ApiModelProperty(value = "نوع ارز",allowableValues = "IRR,USD")
    private String currencyType;

    private String branch;



}