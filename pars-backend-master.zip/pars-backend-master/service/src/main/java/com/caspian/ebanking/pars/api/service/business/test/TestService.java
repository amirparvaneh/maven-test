package com.caspian.ebanking.pars.api.service.business.test;

import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.test.dto.AddRequestDto;
import com.caspian.ebanking.pars.api.service.business.test.dto.AddResponseDto;

import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/13/2020 3:09 PM
 */
public interface TestService {

    List<ClientDataControl> getClientDataControl();

    AddResponseDto add(AddRequestDto requestDto);

    ResultDto subtract(int a, int b) throws Exception;

    ResultDto randomException();
}
