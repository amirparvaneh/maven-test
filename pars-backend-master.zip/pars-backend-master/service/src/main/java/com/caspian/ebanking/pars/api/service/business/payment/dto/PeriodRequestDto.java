package com.caspian.ebanking.pars.api.service.business.payment.dto;

import com.caspian.moderngateway.core.coreservice.dto.epayment.ChPeriodAccountBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/07/2021 07:18 PM
 */
@Data
public class PeriodRequestDto {
    private Long id;
    @ApiModelProperty(value = "عنوان")
    private String title;
    @ApiModelProperty(value = "حداقل مبلغ")
    private Long minAmount;
    @ApiModelProperty(value = "حداکثر مبلغ")
    private Long maxAmount;
    @ApiModelProperty(value = "کددوره")
    private String periodCode;
    @ApiModelProperty(value = "تاربخ شروع")
    private Date startDate;
    @ApiModelProperty(value = "تاریخ پایان")
    private Date endDate;
    @ApiModelProperty(value = "شماره حساب")
    private String externalRef;
}
