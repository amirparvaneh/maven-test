package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۲:۵۱ بعدازظهر
 */
@Data
public class ChequeBookDto {
    @ApiModelProperty(value = "تاریخ صدور")
    private Date issueDate;
    @ApiModelProperty(value = "محدوده برگه چک")
    private String number;
    @ApiModelProperty(value = "تعداد بخشی نقد شده")
    private Short numberOfPartialCashCheque;
    @ApiModelProperty(value = "تعداد پاس شده")
    private Short numberOfPassCheque;
    @ApiModelProperty(value = "تعداد مسدود دائم")
    private Short numberOfPermanentBlockedCheque;
    @ApiModelProperty(value = "تعداد برگشتی ")
    private Short numberOfRejectCheque;
    @ApiModelProperty(value = "تعداد مسدود موقت ")
    private Short numberOfTemporaryBlockCheque;
    @ApiModelProperty(value = "تعداد قابل استفاده ")
    private Short numberOfUnusedCheque;
    @ApiModelProperty(value = "تعداد برگه")
    private Long pageCount;
}