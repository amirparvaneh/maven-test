package com.caspian.ebanking.pars.api.service.business.ach.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/31/2020 10:06 AM
 */
@Data
public class AchTransactionReportRequestDto {

    @ApiModelProperty(name = "شماره پیگیری")
    private String referenceId;

    private String factorNumber;
    private String sourceDepositNumber;
    private String sourceDepositIban;
    private String destinationIbanNumber;
    private String destinationOwnerName;
    private BigDecimal fromTransactionAmount;
    private BigDecimal toTransactionAmount;
    private Date fromRegisterDate;
    private Date toRegisterDate;
    private Date fromIssueDate;
    private Date toIssueDate;
    private String description;
    private String transferDescription;
    private String transactionId;

    @ApiModelProperty(name = "وضعیت تراکنش", allowableValues = "READY_FOR_PROCESS,SUSPENDED,CANCELED,PROCESS_FAIL,READY_TO_TRANSFER,TRANSFERRED,SETTLED,NOT_SETTLED,REJECTED")
    private String transactionStatus;

}
