
package com.caspian.ebanking.pars.api.service.business.offlineStatement.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Atousa khanjani
 * @since 12/29/2020 02:14 PM
 */
@Data
public class OfflineStatementReportResponseDto implements Serializable {
    private List<OfflineStatementReportItemsDto> items;
    private int totalCount;
}
