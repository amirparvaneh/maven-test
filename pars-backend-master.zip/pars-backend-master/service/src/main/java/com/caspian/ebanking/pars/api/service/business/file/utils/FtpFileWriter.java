package com.caspian.ebanking.pars.api.service.business.file.utils;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.log4j.Logger;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class FtpFileWriter extends FtpFileBase {

    private static final Logger log = Logger.getLogger(FtpFileWriter.class);
    private static String basePath;

    private FtpFileReader ftpFileReader;

    public FtpFileWriter() {
        super(new FTPClient());
        basePath = FileReaderWriterModel.getInstance().getLoadedBasePath();
        ftpFileReader = new FtpFileReader(ftpClient);
    }

    public FtpFileWriter(FTPClient ftpClient) {
        super(ftpClient);
        ftpFileReader = new FtpFileReader(ftpClient);
    }

    public Boolean write(String fileName, String path, byte[] data) {
        String destinationFilePath = basePath + path + fileName;
        int readFileSize = ftpFileReader.readFileSize(destinationFilePath);

        if (readFileSize >= data.length) {
            log.debug(String.format("Destination file size[%10d] is bigger than or equal source file size[%10d] [%s].", readFileSize, data.length, fileName));
            return true;
        }

        try {
            ftpCreateDirectoryTree(basePath + path);

            OutputStream output = null;
            output = new BufferedOutputStream(ftpClient.storeFileStream(fileName));
            output.write(data);
            output.flush();
            output.close();
        } catch (IOException e) {
            log.error(e);
            return false;
        } catch (Exception e) {
            log.debug(e);
            return false;
        }
        return true;
    }

    private void ftpCreateDirectoryTree(String dirTree) throws IOException {
        String[] directories = dirTree.split("/");
        for (String dir : directories) {
            if (!dir.isEmpty()) {
                ftpClient.makeDirectory(dir);
                if (!ftpClient.changeWorkingDirectory(dir)) {
                    throw new IOException("Unable to change into newly created remote directory '" + dir + "'.  error='" + ftpClient.getReplyString() + "'");
                }
            }
        }
    }
}
