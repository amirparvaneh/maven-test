package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۲:۵۹ بعدازظهر
 */
@Data
public class ActiveChequeBookRequestDto {
    @ApiModelProperty(value = "شماره حساب")
    private String depositNumber;
    private Long length;
    private Long offset;
}