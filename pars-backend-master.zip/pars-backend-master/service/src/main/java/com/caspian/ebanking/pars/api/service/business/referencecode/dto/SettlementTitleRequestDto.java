package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 9:38 AM
 */
@Data
public class SettlementTitleRequestDto {
    private Long parentId;
    @ApiModelProperty(value = "کد واریز")
    private String settleTitleCode;
    @ApiModelProperty(value = "عنوان واریز")
    private String settleTitle;
    @ApiModelProperty(value = "کد عملیات")
    private String operationCode;
}
