package com.caspian.ebanking.pars.api.service.business.payment.service;

import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.payment.dto.*;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
public interface PaymentService {
    BillPaymentResponseDto singleBillPayment(BillPaymentRequestDto requestDto);

    BillPaymentReportResponseDto getPayedBillsReport(BillPaymentReportRequestDto requestDto);

    Long addPeriod(PeriodRequestDto requestDto);

    ResultDto updatePeriod(PeriodRequestDto requestDto);

    ResultDto removePeriod(Long id);

    LoadPeriodResponseDto loadPeriod(LoadPeriodRequestDto requestDto);

    LoadPeriodHistoryResponseDto loadPeriodHistory(Long id);

    AddPeriodPersonResponseDto addPeriodPerson(AddPeriodPersonRequestDto requestDto);

    ResultDto removePeriodPerson(Long id);

    ResultDto updatePeriodPerson(PeriodPersonRequestDto requestDto);

    ResultDto inactivePeriodPerson(Long id);

    LoadPeriodPersonResponseDto loadPeriodPerson(LoadPeriodPersonRequestDto requestDto);


}
