package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class TransferredChequeRequestDto {
    private String accounts;
    private String banks;
    private Date fromRegisterDate;
    private Date toRegisterDate;
    private Date fromDueDate;
    private Date toDueDate;
    private Date fromPassDate;
    private Date toPassDate;
    private String fromChequeNumber;   //fromNumber
    private String toChequeNumber;     //toNumber
    private BigDecimal fromChequeAmount;   //fromBalance
    private BigDecimal toChequeAmount;     //toBalance
    private String branchCode;
    private String deviseeBankCode;
    private String includeStatus;
    private String includeType;
    private String orderMethod;
    private String orderType;

}