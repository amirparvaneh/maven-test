package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 01/21/2021 9:53 AM
 */
@Data
public class DoCartableRequestDto {
    private String cartableRequestCode;
    @ApiModelProperty(value = "رمز انتقال وجه")
    private String secondPassword;
    @ApiModelProperty(value = "نوع رمز", allowableValues = "TRANSFER_SECOND_PASS,OTP")
    private String passwordType;
    private String uniqueTrackingCode;
    private boolean checkUniqueTrackingCode;
}
