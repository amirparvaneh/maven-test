package com.caspian.ebanking.pars.api.service.business.normaltransfer.service;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.dto.*;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.utils.NormalTransferConvertUtils;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.ChAutoTransferRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.ChNormalTransferRequestBean;
import com.caspian.moderngateway.core.message.AutoTransferMsg;
import com.caspian.moderngateway.core.message.GetAutoTransferListMsg;
import com.caspian.moderngateway.core.message.NormalTransferMsg;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/4/2021 12:36 PM
 */
@Service
@RequiredArgsConstructor
public class NormalTransferServiceImpl extends BaseService implements NormalTransferService {

    private final NormalTransferConvertUtils normalTransferConvertUtils;
    private final static long DEFAULT_REPORT_LENGTH = 1000;

    @Override
    public SingleNormalFundTransferResponseDto singleNormalFundTransfer(SingleNormalFundTransferRequestDto requestDto) {

        NormalTransferMsg.Inbound inbound = new NormalTransferMsg.Inbound();
        final ChNormalTransferRequestBean requestBean = normalTransferConvertUtils.getSingleNormalFundTransferRequestBean(requestDto);
        inbound.setNormalTransferRequestBean(requestBean);

        try {
            NormalTransferMsg.Outbound result = channelManagerProvider.execute(inbound, NormalTransferMsg.Outbound.class);
            return mapper.map(result.getResponseBean(), SingleNormalFundTransferResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    public AutoNormalTransferReportResponseDto autoNormalTransferReport(AutoNormalTransferReportRequestDto requestDto) {
        GetAutoTransferListMsg.Inbound inbound = new GetAutoTransferListMsg.Inbound();
        inbound.setSearchAutoTransferRequestBean(normalTransferConvertUtils.getAutoNormalTransferReportCriteria(requestDto, DEFAULT_REPORT_LENGTH));

        try {
            GetAutoTransferListMsg.Outbound result = channelManagerProvider.execute(inbound, GetAutoTransferListMsg.Outbound.class);
            return normalTransferConvertUtils.autoNormalTransferReportConverter(result.getAutoTransferDetailsResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    public AutoFundTransferResponseDto autoFundTransfer(AutoFundTransferRequestDto requestDto) {
        ChAutoTransferRequestBean requestBean = normalTransferConvertUtils.convertAutoFundTransferRequest(requestDto);

        AutoTransferMsg.Inbound inbound = new AutoTransferMsg.Inbound();
        inbound.setAutoTransferRequestBean(requestBean);

        try {
            final AutoTransferMsg.Outbound outbound = channelManagerProvider.execute(inbound, AutoTransferMsg.Outbound.class);
            return normalTransferConvertUtils.convertAutoFundTransferResponse(outbound.getResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

}
