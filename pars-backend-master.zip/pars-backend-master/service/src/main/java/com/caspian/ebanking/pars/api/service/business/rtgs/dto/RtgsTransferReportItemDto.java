package com.caspian.ebanking.pars.api.service.business.rtgs.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class RtgsTransferReportItemDto {
    private BigDecimal amount;
    private String destinationBankCode;
    private String DestinationBankName;
    private String destinationDepositNumber;
    private Date registerDate;
    private String serial;
    private String sourceDepositNumber;
    @ApiModelProperty(allowableValues = "SABT_SHODE, TAEED_SHOBE_SHODE,ADAM_TAEED_SHOBE,HAZF_SHODE,TAEED_SHOBE_SATNA,ADAM_TAEED_SHOBE_SATNA,ERSAL_SHODE,TASFIYEH_SHODE,TASFIYEH_NASHODE,ENTEZAR_BARAYE_TAEED")
    private String status;
    private String systemCode;
    private String branchCode;
    private String branchName;
}
