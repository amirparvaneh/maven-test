package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۶/۰۱/۲۰۲۱ ۰۹:۵۲ قبل‌ازظهر
 */
@Data
public class IssuedRemittanceReportItemDto {
    private String remittanceNumber;
    @ApiModelProperty(value = "بانک کارگزار")
    private String brokerBank;

    @ApiModelProperty(value = "بانک ذینفع")
    private String beneficiaryBank;

    @ApiModelProperty(value = "مبلغ حواله")
    private BigDecimal amount;

    @ApiModelProperty(value = "نوع ارز")
    private String currencyType;

    @ApiModelProperty(value = "نرخ ارز")
    private BigDecimal currencyRate;

    @ApiModelProperty(value = "تاریخ صدور")
    private Date issueDate;
    private String status;
}