package com.caspian.ebanking.pars.api.service.business.account.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/6/2021 2:20 PM
 */
@Data
@ApiModel
public class SetCustomerDepositDetailRequestDto {
    @ApiModelProperty(name = "شماره مرجع", example = "B9910091001585128173")
    private String serial;

    @ApiModelProperty(name = "کد شعبه")
    private String branchCode;

    @ApiModelProperty(name = "تاریخ در رکورد صورت حساب")
    private Date date;

    @ApiModelProperty(name = "یادداشت مشتری")
    private String customerDescription;
}
