package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.Data;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class ChequeCartableApprovalDto {

    public static class STATUS {
        public static final Character WAITING_FOR_CONFORMATION = 'W';
        public static final Character CONFORMED = 'C';
        public static final Character REJECTED = 'J';
        public static final Character REQUESTER = 'R';
    }

    private Long id;
    private Long chequeCartableRequestId;
    private String customerNo;
    private Character status;
    private String description;
    private String customerName;
    private Boolean requester;
}
