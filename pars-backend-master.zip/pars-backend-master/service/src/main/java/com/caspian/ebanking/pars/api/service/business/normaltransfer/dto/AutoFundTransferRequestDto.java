package com.caspian.ebanking.pars.api.service.business.normaltransfer.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author atousa khanjani
 * @since 01/27/2021 07:34 PM
 */
@Data
public class AutoFundTransferRequestDto {
    private String captcha;
    @ApiModelProperty(name = "برداشت از")
    private String sourceAccountNumber;
    @ApiModelProperty(name = "واریزبه")
    private String destinationAccountNumber;
    @ApiModelProperty(name = "مبلغ انتقال ")
    private BigDecimal transferAmount;
    @ApiModelProperty(name = "تاریخ اولین انتقال")
    private Date firstTransferDate;
    @ApiModelProperty(name = "کد شعبه")
    private String paymentId;
    @ApiModelProperty(name = "طول دوره")
    private Short periodDuration;
    @ApiModelProperty(name = "دوره پرداخت")
    private String paymentPeriod;
    @ApiModelProperty(name = "تعداد دوره پرداخت")
    private Short paymentPeriodCount;
    @ApiModelProperty(value = "نوع رمز", allowableValues = "LOGIN,TRANSFER_SECOND_PASS")
    private String passwordType;
    @ApiModelProperty(name = "رمز انتقال")
    private String transferPassword;
    @ApiModelProperty(name = "کد شعبه")
    private String uniqueTrackingCode;
}