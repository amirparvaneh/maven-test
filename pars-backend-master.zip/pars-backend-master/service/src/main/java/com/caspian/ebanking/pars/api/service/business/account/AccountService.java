package com.caspian.ebanking.pars.api.service.business.account;

import com.caspian.ebanking.pars.api.service.business.account.dto.*;
import com.caspian.ebanking.pars.api.service.business.ach.dto.GetIbanFromAccountRequestDto;
import com.caspian.ebanking.pars.api.service.business.ach.dto.GetIbanFromAccountResponseDto;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.normaltransfer.dto.GetDestinationAccountsResponseDto;

import java.math.BigDecimal;

/**
 * @author Amir Tajik
 * @author atousa khanjani
 * @version 1.0
 * @since 12/28/2020 12:34 PM
 */
public interface AccountService {
    GetUserAccountsResponseDto getUserAccounts(String serviceCode);

    GetIbanFromAccountResponseDto getIbanFromUserAccount(GetIbanFromAccountRequestDto requestDto);

    StatementResponseDto getNormalStatement(StatementRequestDto requestDto);

    GetSourceAccountResponseDto getSourceAccount(String serviceName, String accountType);

    GetDestinationIbanResponseDto getDestinationIban(Long accountId);

    GetDestinationAccountsResponseDto getDestinationAccounts(Long accountId);

    ResultDto setCustomerDepositDetail(SetCustomerDepositDetailRequestDto requestDto);

    IbanInquiryByCentralBankResponseDto ibanInquiryByCentralBank(String iban, BigDecimal amount, String paymentCode);

    SummaryStatementResponseDto getSummaryStatement(SummaryStatementRequestDto requestDto);

    GetDepositOwnerNameResponseDto getDepositOwnerName(String accountNo);
}
