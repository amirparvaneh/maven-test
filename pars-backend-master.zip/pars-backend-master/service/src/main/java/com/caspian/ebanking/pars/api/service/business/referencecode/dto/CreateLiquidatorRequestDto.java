package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.Validator;
import lombok.Data;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۲/۰۲/۲۰۲۱ ۰۹:۵۷ قبل‌ازظهر
 */
@Data
public class CreateLiquidatorRequestDto {
    private Long id;
    private Long parentId;
    private String liquidatorCode;
    private String liquidator;
    private String description;
    private String telNo;
    private String email;
    private String address;
    private Long organizationId;
    private Long departmentId;
}