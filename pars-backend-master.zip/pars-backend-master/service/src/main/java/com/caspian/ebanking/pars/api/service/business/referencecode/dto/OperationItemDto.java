package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 9:38 AM
 */
@Data
public class OperationItemDto {
    private Long operationId;
    @ApiModelProperty(value = "شماره حساب")
    private String accountNumber;
    @ApiModelProperty(value = "نام دارنده حساب")
    private String ownerName;
    @ApiModelProperty(value = "کد شعبه")
    private Integer branchCode;
    @ApiModelProperty(value = "عنوان عملیات")
    private String operationTitle;
    @ApiModelProperty(value = "کدعملیات")
    private String operationCode;
}
