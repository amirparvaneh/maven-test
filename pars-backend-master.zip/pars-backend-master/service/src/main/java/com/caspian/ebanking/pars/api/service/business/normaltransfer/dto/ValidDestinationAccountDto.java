package com.caspian.ebanking.pars.api.service.business.normaltransfer.dto;

import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/4/2021 10:20 PM
 */
@Data
public class ValidDestinationAccountDto {
    private String destinationAccountNumber;
}
