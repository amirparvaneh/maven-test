package com.caspian.ebanking.pars.api.service.business.account.dto;

import com.caspian.moderngateway.core.channelmanagerserviceaggregator.dto.ChAccountOwner;
import lombok.Data;

import java.util.List;

/**
 * @author atousa khanjani
 * @since 12/29/2020 07:34 PM
 */

@Data
public class IbanInquiryByCentralBankResponseDto {
    private String requestedIban;
    private String accountNumber;
    private String accountStatus;
    private String paymentCode;
    private String paymentCodeValid;
    private String accountComment;
    private String errorCode;
    private String accountOwners;
    private String referenceNumber;
    private String ownerName;
    private String ownerFamily;
}
