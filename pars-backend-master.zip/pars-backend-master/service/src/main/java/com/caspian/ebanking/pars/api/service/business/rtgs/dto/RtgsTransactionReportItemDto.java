package com.caspian.ebanking.pars.api.service.business.rtgs.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChRtgsActionType;
import lombok.Data;

import java.util.Date;

@Data
public class RtgsTransactionReportItemDto {
    private String actionType;
    private Date date;
    private String serial;
}
