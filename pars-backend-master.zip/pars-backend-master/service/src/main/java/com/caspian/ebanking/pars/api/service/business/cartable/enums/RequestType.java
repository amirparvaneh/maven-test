package com.caspian.ebanking.pars.api.service.business.cartable.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۶/۰۱/۲۰۲۱ ۰۲:۳۱ قبل‌ازظهر
 */
@Getter
public enum RequestType {
    TRANSFER("TRANSFER", 'T'),
    BATCH_TRANSFER("BATCH_TRANSFER", 'C'),
    STANDING_ORDER("STANDING_ORDER", 'S'),
    ACH_NORMAL_TRANSFER("ACH_NORMAL_TRANSFER", 'N'),
    ACH_BATCH_TRANSFER("ACH_BATCH_TRANSFER", 'A'),
    ACH_STANDING_ORDER_TRANSFER("ACH_STANDING_ORDER_TRANSFER", 'P'),
    FILE_GROUP_TRANSFER("FILE_GROUP_TRANSFER", 'F');

    String name;
    Character ch;

    RequestType(String name, Character ch) {
        this.name = name;
        this.ch = ch;
    }

    public static Character getCharacterOf(String name) {
        Optional<Character> ch = Arrays.stream(RequestType.values()).filter(item -> item.name.equals(name)).map(i -> i.getCh()).findFirst();
        if (ch.isPresent())
            return ch.get();
        else
            return null;

    }

    public static String getNameOf(Character ch){
        Optional<String> name = Arrays.stream(RequestType.values()).filter(item -> item.ch.equals(ch)).map(i -> i.getName()).findFirst();
        if (name.isPresent())
            return name.get();
        else
            return null;
    }
}