package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChOperationsBean;
import com.caspian.moderngateway.core.coreservice.dto.SettlementTitleHierarchyBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۱/۰۲/۲۰۲۱ ۰۵:۱۴ بعدازظهر
 */
@Data
public class SettlementTitleHierarchyItemDto {
    private Long id;
    private Long parentId;
    @ApiModelProperty(value = "کد عنوان واریز")
    private String settleTitleCode;
    @ApiModelProperty(value = "عنوان واریز")
    private String settleTitle;
    @ApiModelProperty(value = "کد عملیات")
    private String operationCode;
    private Long organizationId;
    private Character status;
    private ChOperationsBean chOperationsBean;
    private List<SettlementTitleHierarchyItemDto> children = new ArrayList();
    private Date insertSysDate;
    private String insertUser;
    private Date updateSysDate;
    private String updateUser;
    private Long version;
}