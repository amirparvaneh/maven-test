
package com.caspian.ebanking.pars.api.service.business.offlineStatement.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Atousa khanjani
 * @since 12/09/2020 02:14 PM
 */
@Data
public class OfflineStatementReportRequestDto implements Serializable {
    private Date fromDate;
    private Date toDate;
}

