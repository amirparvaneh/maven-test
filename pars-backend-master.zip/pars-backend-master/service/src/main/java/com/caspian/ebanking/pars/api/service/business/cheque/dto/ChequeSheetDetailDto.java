package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChChequeStatus;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۴:۴۵ بعدازظهر
 */
@Data
public class ChequeSheetDetailDto {
    @ApiModelProperty(value = "مبلغ")
    protected BigDecimal balance;
    @ApiModelProperty(value = "تاریخ تغییر وضعیت")
    protected Date changeStatusDate;
    protected String description;
    @ApiModelProperty(value = "شماره")
    protected String number;
    @ApiModelProperty(value = "تاریخ سررسید")
    protected Date registerChequeDate;
    @ApiModelProperty(value = "وضعیت")
    protected ChChequeStatus status;
    @ApiModelProperty(value = "در وجه")
    protected String payeeName;
    protected Boolean registerable;
    private String stopDescription;
}