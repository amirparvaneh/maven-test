package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۴:۴۵ بعدازظهر
 */
@Data
public class ChequeSheetDetailResponseDto {
    private List<ChequeSheetDetailDto> detailDtoList;
    private Long totalRecord;
}