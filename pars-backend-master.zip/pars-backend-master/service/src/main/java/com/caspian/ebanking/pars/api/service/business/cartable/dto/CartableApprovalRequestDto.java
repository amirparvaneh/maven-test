package com.caspian.ebanking.pars.api.service.business.cartable.dto;

public class CartableApprovalRequestDto {
}
