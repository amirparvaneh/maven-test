package com.caspian.ebanking.pars.api.service.business.offlineStatement.dto;

import lombok.Data;

@Data
public class OfflineStatementResponseDto {
    private Long requestId;
}
