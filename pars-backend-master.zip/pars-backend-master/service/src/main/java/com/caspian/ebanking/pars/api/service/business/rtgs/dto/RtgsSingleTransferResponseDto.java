package com.caspian.ebanking.pars.api.service.business.rtgs.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class RtgsSingleTransferResponseDto {
    private String id;
    private BigDecimal balance;
    private String currency;
    private String receiverBankCode;
    private String receiverBankName;
}
