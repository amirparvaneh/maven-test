package com.caspian.ebanking.pars.api.service.business.rtgs.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class RtgsSingleTransferRequestDto {
    private String sourceDepositNumber;
    private String destinationIbanNumber;
    private BigDecimal amount;
    private String receiverName;
    private String receiverFamily;
    private String description;
    private String receiverTelephoneNumber;
    @ApiModelProperty(value = "شناسه پرداخت")
    private String factorNumber;
    @ApiModelProperty(value = "رمز انتقال وجه")
    private String secondPassword;
    @ApiModelProperty(value = "نوع رمز", allowableValues = "TRANSFER_SECOND_PASS,OTP")
    private String passwordType;
}
