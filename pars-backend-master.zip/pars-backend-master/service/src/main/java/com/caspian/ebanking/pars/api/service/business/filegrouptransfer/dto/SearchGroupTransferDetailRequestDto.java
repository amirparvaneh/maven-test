package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author atousa khanjani
 * @since 02/21/2021 07:34 PM
 */
@Data
public class SearchGroupTransferDetailRequestDto {
    @ApiModelProperty(value = "حساب  معادل مقصد")
    private String destinationAccount;
    private String parentTrackingCode;
    private String reference;
    @ApiModelProperty(value = "نام فایل")
    private String fileName;
    @ApiModelProperty(value = "حساب  مقصد")
    private String accountNumber;
    @ApiModelProperty(value = "تاریخ ثبت  از")
    private Date fromInsertDate;
    @ApiModelProperty(value = "تاریخ ثبت تا")
    private Date toInsertDate;
    private String coreTrackingCode;
    @ApiModelProperty(value = "تاریخ برگشت سند از")
    private Date fromRejectedDealReferenceDate;
    @ApiModelProperty(value = "تاریخ برگشت سند تا")
    private Date toRejectedDealReferenceDate;
    @ApiModelProperty(value = "تاریخ عملیات از")
    private Date fromActionDate;
    @ApiModelProperty(value = " تاریخ عملیات تا")
    private Date toActionDate;
    @ApiModelProperty(value = "تاریخ پایان پردازش از")
    private Date fromEndProcessDate;
    @ApiModelProperty(value = "تاریخ پایان پردازش تا")
    private Date toEndProcessDate;
    @ApiModelProperty(value = "از مبلغ")
    private BigDecimal fromAmount;
    @ApiModelProperty(value = "تا مبلغ")
    private BigDecimal toAmount;
    private String paymentId;
    @ApiModelProperty(allowableValues = "ALL,READ_RECORD,REGISTER,PROCESS_ERROR,TRANSFER_ERROR,ALL_ERROR,CANCELED,SUCCESS,PRE_PROCESS,CONFLICT")
    private String detailStatus;
    @ApiModelProperty(value = "شرح")
    private String description;
    @ApiModelProperty(allowableValues = "DESC,ASC")
    private String order;
    @ApiModelProperty(value = "حساب  مبدا")
    private String sourceAccountNumber;
    @ApiModelProperty(allowableValues = "ALL,TRANSFER_IBAN,TRANSFER_ACCOUNT,TRANSFER,ACH,RTGS")
    private String detailType;
    @ApiModelProperty(value = "از ردیف")
    private Integer startRow;
    @ApiModelProperty(value = "تا ردیف")
    private Integer endRow;
    private String rejectedDealReference;
}