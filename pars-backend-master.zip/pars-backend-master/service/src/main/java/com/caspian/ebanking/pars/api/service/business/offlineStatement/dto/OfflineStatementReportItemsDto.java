package com.caspian.ebanking.pars.api.service.business.offlineStatement.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa khanjani
 * @since 12/09/2020 02:14 PM
 */
@Data
public class OfflineStatementReportItemsDto implements Serializable {

    private String depositNumber;
    private Date requestDate;
    private Date fromDate;
    private Date toDate;
    private Date fromDateTime;
    private Date toDateTime;
    private BigDecimal fromAmount;
    private BigDecimal toAmount;
    private String customerDescription;
    private String description;
    private String dealReference;
    private String chequeNo;
    private String receiptNo;
    private String action;
    private String order;
    private String statementSearchDirection;
    private Integer status;
    private String offlineStatementType;
    private String statusName;
    private Long requestId;
    private boolean downloadable;

}