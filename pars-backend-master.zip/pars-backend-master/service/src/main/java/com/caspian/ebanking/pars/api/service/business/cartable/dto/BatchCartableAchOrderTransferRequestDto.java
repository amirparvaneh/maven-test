package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import com.caspian.moderngateway.core.message.dto.CartableAchOrderTransferEntryDto;
import lombok.Data;
import java.util.Date;
import java.util.List;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 01/21/2021 9:53 AM
 */
@Data
public class BatchCartableAchOrderTransferRequestDto {

    private Date expireDate;
    private Character priority;
    private String cartableDescription;
    private String sourceAccount;
    private String conditionId;
    private List<CartableAchOrderTransferEntryDto> cartableAchOrderTransferEntriesDto;

}