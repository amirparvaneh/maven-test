package com.caspian.ebanking.pars.api.service.business.payment.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChBillType;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class BillPaymentResponseDto {

    private BigDecimal amount;
    private String billForeignTitle;
    private String billId;
    private String billTitle;
    private ChBillType billType;
    private String cycle;
    private Date transactionDate;
    private String fileCode;
    private String payId;
    private String transactionNum;

}