package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class TransferredCheque {
    private Date passDate;
    private Date registerDate;
    private Date dueDate;
    private String number;
    private BigDecimal amount;
    private String depositNumber;
    private String status;
    private String deviseeDepositNumber;
    private String deviseeBank;
    private String type;
    private String deviseeBankCode;
    private Integer transferredBranchCode;
}