package com.caspian.ebanking.pars.api.service.business.ach.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class GetIbanFromAccountResponseDto {
    @ApiModelProperty(value = "شماره شبا")
    private String iban;
}
