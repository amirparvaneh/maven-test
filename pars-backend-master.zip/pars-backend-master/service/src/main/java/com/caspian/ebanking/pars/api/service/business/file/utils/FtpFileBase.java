package com.caspian.ebanking.pars.api.service.business.file.utils;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.log4j.Logger;

import java.io.IOException;

public abstract class FtpFileBase {

    private static final Logger log = Logger.getLogger(FtpFileBase.class);

    protected FTPClient ftpClient;

    private final String server;
    private final Integer port;
    private final String user;
    private final String pass;
    private final Integer connectTimeout;
    private final Integer readTimeout;

    public FtpFileBase(FTPClient ftpClient) {
        this.ftpClient = ftpClient;
        this.server = FileReaderWriterModel.getInstance().getFtpServer();
        this.port = FileReaderWriterModel.getInstance().getFtpPort();
        this.user = FileReaderWriterModel.getInstance().getFtpUser();
        this.pass = FileReaderWriterModel.getInstance().getFtpPassword();
        this.connectTimeout = FileReaderWriterModel.getInstance().getFtpConnectTimeout();
        this.readTimeout = FileReaderWriterModel.getInstance().getFtpReadTimeout();
        connect();
    }

    public synchronized void connect() {
        try {
            if (ftpClient.getReplyCode() == 0) {
                ftpClient.connect(server, port);
                ftpClient.setDefaultTimeout(connectTimeout);
                ftpClient.setDataTimeout(readTimeout);
                if (!ftpClient.login(user, pass)) {
                    log.error(String.format("FTP Login with username [%s] failed.", user));
                }
                ftpClient.enterLocalPassiveMode();
                ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
            }
        } catch (IOException e) {
            log.error(e);
        }
    }

    public synchronized void disconnect() {
        try {
            if (ftpClient.getReplyCode() != 0) {
                ftpClient.disconnect();
            }
        } catch (IOException e) {
            log.error(e);
        }
    }


}
