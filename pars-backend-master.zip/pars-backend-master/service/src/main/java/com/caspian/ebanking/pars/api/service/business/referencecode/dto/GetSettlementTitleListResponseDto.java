package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 2/01/2021 11:38 AM
 */
@Data
public class GetSettlementTitleListResponseDto {
    private List<SettlementTitleDto> settlementTitleDtos;
}
