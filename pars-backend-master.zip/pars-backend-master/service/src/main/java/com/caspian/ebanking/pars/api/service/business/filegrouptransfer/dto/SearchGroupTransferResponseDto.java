package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import lombok.Data;

import java.util.List;

/**
 * @author atousa khanjani
 * @since 02/21/2021 07:34 PM
 */
@Data
public class SearchGroupTransferResponseDto {
    private List<GroupTransferDto> groupTransferDtoList;
}
