package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class GetReferenceCodeStatementByChequeDto {
    private String referenceType;
    @ApiModelProperty("کد شناسه")
    private String referenceCode;
    private String description;
    @ApiModelProperty("مبلغ")
    private BigDecimal amount;
    private String receiptNumber;
    private String dealNarrative;
    @ApiModelProperty("شماره سند")
    private String dealReference;
    @ApiModelProperty("تاریخ سند")
    private Date dealDate;
    private String businessTime;
    private String entryNarrative;
    private String extraNarrative;
    @ApiModelProperty("شماره چک")
    private String chequeNumber;
    @ApiModelProperty("شعبه عامل سند")
    private String operatorBranchCode;
    @ApiModelProperty("بانک ذینفع")
    private String chequeBankCode;
    @ApiModelProperty("شعبه ذینفع")
    private String chequeBranchCode;
    @ApiModelProperty("شعبه واگذارنده")
    private String chequeOpBranchCode;
    @ApiModelProperty("تاریخ چک")
    private Date chequeDate;
    @ApiModelProperty("تاریخ ثبت چک")
    private Date chequeRegisterDate;
    private String chequeSeri;
    private String chequeType;

}
