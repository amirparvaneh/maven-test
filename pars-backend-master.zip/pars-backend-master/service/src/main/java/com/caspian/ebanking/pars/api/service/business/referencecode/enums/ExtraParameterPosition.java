package com.caspian.ebanking.pars.api.service.business.referencecode.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۱/۰۲/۲۰۲۱ ۱۲:۰۵ بعدازظهر
 */
@Getter
public enum ExtraParameterPosition {
    ENDOFREFERENCECODE("ENDOFREFERENCECODE", 'E'),
    BEGINOFREFERENCECODE("BEGINOFREFERENCECODE", 'B');


    String name;
    Character ch;

    ExtraParameterPosition(String name, Character ch) {
        this.name = name;
        this.ch = ch;
    }

    public static Character getCharacterOf(String name) {
        Optional<Character> ch = Arrays.stream(ExtraParameterPosition.values()).filter(item -> item.name.equals(name)).map(i -> i.getCh()).findFirst();
        if (ch.isPresent())
            return ch.get();
        else
            return null;

    }

    public static String getNameOf(Character ch) {
        Optional<String> name = Arrays.stream(ExtraParameterPosition.values()).filter(item -> item.ch.equals(ch)).map(i -> i.getName()).findFirst();
        if (name.isPresent())
            return name.get();
        else
            return null;
    }
}
