package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author atousa khanjani
 * @since 02/27/2021 07:34 PM
 */
@Data
public class CartableGroupFileTransferItemDto {
    private Long id;
    private Long groupTransferId;
    private String clientId;
    private String trackingCode;
    private String title;
    private String description;
    private Date effectiveDate;
    private String sourceAccountNumber;
    private Integer clientTotalNumber;
    private BigDecimal clientTotalAmount;
}
