package com.caspian.ebanking.pars.api.service.business.rtgs.dto;

import lombok.Data;

import java.util.List;

@Data
public class RtgsTransferReportResponseDto {
    private Long totalRecord;
    private List<RtgsTransferReportItemDto> transferDetailsDtos;
    private Boolean status;
}
