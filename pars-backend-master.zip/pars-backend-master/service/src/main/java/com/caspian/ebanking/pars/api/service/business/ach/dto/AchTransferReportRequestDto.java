package com.caspian.ebanking.pars.api.service.business.ach.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChOrderStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۴/۰۱/۲۰۲۱ ۰۸:۴۹ قبل‌ازظهر
 */
@Data
public class AchTransferReportRequestDto {
    @JsonIgnore
    private String cif;
    private String description;
    private String destinationIbanNumber;
    private String destinationOwnerName;
    @JsonIgnore
    private String factorNumber;
    @ApiModelProperty(value = "تاریخ انجام انتقال از")
    private Date fromIssueDate;
    private Date fromRegisterDate;
    private BigDecimal fromTransactionAmount;
    private Long length;
    private Long offset;
    @ApiModelProperty(value = "شماره ارجاع")
    private String referenceId;
    private String sourceDepositNumber;
    @JsonIgnore
    private String sourceDepositIban;
    @ApiModelProperty(value = "وضعیت انتقال",allowableValues = "WAIT_FOR_CUSTOMER_ACCEPT,WAIT_FOR_BRANCH_ACCEPT," +
            "BRANCH_REJECT,READY_TO_TRANSFER,SUSPEND,CANCEL,PROCESSED")
    private String statusList;
    @ApiModelProperty(value = "تاریخ انجام انتقال تا")
    private Date toIssueDate;
    private Date toRegisterDate;
    private BigDecimal toTransactionAmount;
    @ApiModelProperty(value = "وضعیت تراکنش",allowableValues = "READY_FOR_PROCESS,SUSPENDED,CANCELED,PROCESS_FAIL,\n" +
            "    READY_TO_TRANSFER,TRANSFERRED,SETTLED,NOT_SETTLED,REJECTED")
    private String transactionStatusList;
    private String transferDescription;
}

