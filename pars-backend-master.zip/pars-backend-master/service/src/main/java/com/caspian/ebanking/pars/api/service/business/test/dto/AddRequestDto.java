package com.caspian.ebanking.pars.api.service.business.test.dto;

import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/13/2020 3:10 PM
 */
@Data
public class AddRequestDto {
    private int a, b;
}
