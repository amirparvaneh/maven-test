package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.SecondPassword;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.SecondPasswordType;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.SecurityData;
import com.caspian.moderngateway.core.security.dto.ChSecondPasswordType;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۰/۰۱/۲۰۲۱ ۱۲:۱۰ قبل‌ازظهر
 */
@Data
public class ApproveCartableRequestDto {
    @NotNull
    private String cartableRequestCode;
    @NotNull
    private String secondPassword;
    @NotNull
    @ApiModelProperty(value = "نوع رمز",allowableValues = "OTP,TRANSFER_SECOND_PASS")
    private String chSecondPasswordType;
}