package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۱/۰۲/۲۰۲۱ ۰۲:۲۸ بعدازظهر
 */
@Data
public class LiquidatorDto {
    private Long id;
    private Long parentId;
    @ApiModelProperty(value = "واریز کننده")
    private String liquidator;
    @ApiModelProperty(value = "کد واریز کننده")
    private String liquidatorCode;
    private String description;
    private String telNo;
    private String email;
    private String address;
    private Long organizationId;
    private Long departmentId;
    private Date insertSysDate;
    private String insertUser;
    private Date updateSysDate;
    private String updateUser;
    private Long version;

}