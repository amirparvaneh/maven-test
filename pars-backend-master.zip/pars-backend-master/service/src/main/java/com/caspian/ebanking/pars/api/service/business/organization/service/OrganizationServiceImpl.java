package com.caspian.ebanking.pars.api.service.business.organization.service;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.security.dto.OrganizationRelDto;
import com.caspian.ebanking.pars.api.service.business.general.dto.ResultDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.UserDepartmentsDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.GetUserOrganizationsResponseDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.OrganizationUserDto;
import com.caspian.ebanking.pars.api.service.business.organization.dto.OrganizationUsersResponseDto;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.domainmodel.dto.valuablecustomer.UserOrganizationRelBean;
import com.caspian.moderngateway.core.message.valuablecustomer.GetDepartmentInfoMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.GetOrganizationUsersMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.GetUserOrganizationRelListMsg;
import com.caspian.moderngateway.core.message.valuablecustomer.SetVCOrganizationInContextMsg;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 1/6/2021 10:15 AM
 */
@Service
@RequiredArgsConstructor
public class OrganizationServiceImpl extends BaseService implements OrganizationService {

    private final CurrentUserService currentUserService;


    @Override
    public GetUserOrganizationsResponseDto getUserOrganizations() {

        GetUserOrganizationRelListMsg.Inbound inbound = new GetUserOrganizationRelListMsg.Inbound();
        inbound.setUserName(currentUserService.getUsername());

        try {
            final GetUserOrganizationRelListMsg.Outbound outbound = channelManagerProvider.execute(inbound, GetUserOrganizationRelListMsg.Outbound.class);
            final List<OrganizationRelDto> organizationRelDtos = mapper.mapList(outbound.getResponseBean(), OrganizationRelDto.class);
            return new GetUserOrganizationsResponseDto(organizationRelDtos);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ResultDto setOrganization(Long organizationId) {
        GetUserOrganizationRelListMsg.Inbound inbound = new GetUserOrganizationRelListMsg.Inbound();
        inbound.setUserName(currentUserService.getUsername());
        final GetUserOrganizationRelListMsg.Outbound outbound;

        try {
            outbound = channelManagerProvider.execute(inbound, GetUserOrganizationRelListMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }

        final UserOrganizationRelBean organizationRelBean = outbound.getResponseBean()
                .stream()
                .filter((x) -> x.getOrganizationId().equals(organizationId))
                .findFirst()
                .orElseThrow(() -> new AccessDeniedException("Organization Id is not valid"));

        SetVCOrganizationInContextMsg.Inbound i = new SetVCOrganizationInContextMsg.Inbound();
        i.setRequestBean(organizationRelBean);

        try {
            channelManagerProvider.execute(i, SetVCOrganizationInContextMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }

        this.currentUserService.setCurrentOrganization(organizationId, organizationRelBean.getDepartmentId());

        return ResultDto.success();
    }

    @Override
    public OrganizationUsersResponseDto getOrganizationUsers() {
        /*WebUser user = LoginService.getUser(getHttpSession());
        if (user == null) {
            throw new WebServiceException("relogin");
        }
*/
        GetOrganizationUsersMsg.Inbound inbound = new GetOrganizationUsersMsg.Inbound();
        inbound.setOrganizationId(currentUserService.getCurrentOrganizationId());

        GetOrganizationUsersMsg.Outbound result;
        try {
            result = channelManagerProvider.execute(inbound, GetOrganizationUsersMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
        OrganizationUsersResponseDto responseDto = new OrganizationUsersResponseDto();
        responseDto.setUserDtoList(result.getUsers() != null ? mapper.mapList(result.getUsers(), OrganizationUserDto.class) : null);
        return responseDto;
    }

    @Override
    public UserDepartmentsDto getUserDepartments() {
        GetDepartmentInfoMsg.Inbound inbound = new GetDepartmentInfoMsg.Inbound();
        inbound.setId(Long.parseLong(currentUserService.getCurrentDepartmentId()));
        GetDepartmentInfoMsg.Outbound result;
        try {
                result = channelManagerProvider.execute(inbound, GetDepartmentInfoMsg.Outbound.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }

        UserDepartmentsDto userDepartmentsDto;
        userDepartmentsDto=mapper.map(result.getDepartmentDTO(),UserDepartmentsDto.class);
        return userDepartmentsDto;
    }
}
