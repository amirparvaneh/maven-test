package com.caspian.ebanking.pars.api.service.business.rtgs.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class RtgsTransferReportRequestDto {
    @ApiModelProperty(allowableValues = "SABT_SHODE,TAEED_SHOBE_SHODE,ADAM_TAEED_SHOBE,\n" +
            "    TAEED_SHOBE_SATNA,ADAM_TAEED_SHOBE_SATNA,ERSAL_SHODE,TASFIYEH_SHODE,TASFIYEH_NASHODE,\n" +
            "    ENTEZAR_BARAYE_TAEED")
    private String status;
    private Short branchCode;
    private String branchName;
    private String depositNumber;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fromDate;

    private Long length;
    private Long offset;
    private String serial;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date toDate;

    @ApiModelProperty(allowableValues = "DESC,ASC")
    private String order;
}
