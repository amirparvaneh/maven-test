package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto;

import lombok.Data;

/**
 * @author atousa khanjani
 * @since 01/27/2021 07:34 PM
 */
@Data
public class FinalConfirmGroupTransferResponseDto {
    private GroupTransferDto groupTransferDto;
}
