package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۰/۰۱/۲۰۲۱ ۱۲:۱۳ قبل‌ازظهر
 */
@Data
public class ApproveCartableRequestResponseDto {
    private Boolean result;
}