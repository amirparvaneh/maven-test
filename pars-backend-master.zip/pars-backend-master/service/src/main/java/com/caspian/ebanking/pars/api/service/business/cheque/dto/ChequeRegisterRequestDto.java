package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.AccountNo;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.FinancialSourceNoProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۶:۲۲ بعدازظهر
 */
@Data
public class ChequeRegisterRequestDto {
    @ApiModelProperty(value = "مبلغ چک")
    protected BigDecimal amount;
    @ApiModelProperty(value = "شرح")
    protected String comment;
    @ApiModelProperty(value = "شماره حساب")
    @NotNull
    protected String depositNumber;
    @ApiModelProperty(value = "تاریخ چک")
    @NotNull
    protected Date dueDate;
    @ApiModelProperty(value = "شماره چک")
    @NotNull
    protected String number;
    @ApiModelProperty(value = "در وجه")
    protected String owner;
}