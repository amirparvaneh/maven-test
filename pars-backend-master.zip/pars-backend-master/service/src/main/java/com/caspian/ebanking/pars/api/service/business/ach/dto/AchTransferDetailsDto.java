package com.caspian.ebanking.pars.api.service.business.ach.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۲/۰۱/۲۰۲۱ ۱۲:۱۳ بعدازظهر
 */
@Data
public class AchTransferDetailsDto {
    private String transactionStatus;
    private Long count;
    private BigDecimal totalAmount;
}
