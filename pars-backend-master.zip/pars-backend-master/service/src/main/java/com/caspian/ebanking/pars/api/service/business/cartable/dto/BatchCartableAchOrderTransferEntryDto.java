package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 01/21/2021 9:53 AM
 */
@Data
public class BatchCartableAchOrderTransferEntryDto {
    private String iban;
    private String ownerName;
    private BigDecimal amount;
    private String description;
    private String factorNumber;

}
