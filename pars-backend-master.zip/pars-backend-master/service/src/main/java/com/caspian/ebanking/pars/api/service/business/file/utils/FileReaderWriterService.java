package com.caspian.ebanking.pars.api.service.business.file.utils;


import com.caspian.ebanking.pars.api.service.business.file.dto.ClientFileDto;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public interface FileReaderWriterService {

    String getFileReaderWriterPath();

    String writeToFile(ClientFileDto fileModel, ByteArrayOutputStream outputStream);

    InputStream readFromFile(ClientFileDto fileModel);

    byte[] readFileBytes(ClientFileDto fileModel);

    boolean deleteFile(ClientFileDto fileModel);

}
