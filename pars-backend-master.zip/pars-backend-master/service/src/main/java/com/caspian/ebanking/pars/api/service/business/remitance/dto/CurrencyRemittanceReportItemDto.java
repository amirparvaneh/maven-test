package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۱۰:۳۵ قبل‌ازظهر
 */
@Data
public class CurrencyRemittanceReportItemDto {
    @ApiModelProperty(value = "شماره برات")
    private String remittanceNumber;

    private BigDecimal amount;

    @ApiModelProperty(value = "نوع ارز")
    private String currencyType;

    private String applicantName;

    private BigDecimal amountEquivalent;

    @ApiModelProperty(value = "شماره ثبت سفارش")
    private String orderNumber;

    private String branch;
}