package com.caspian.ebanking.pars.api.service.business.offlineStatement.utils;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.utils.DateUtils;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementReportItemsDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementReportResponseDto;
import com.caspian.ebanking.pars.api.service.business.offlineStatement.dto.OfflineStatementRequestDto;
import com.caspian.moderngateway.core.coreservice.dto.ChActionType;
import com.caspian.moderngateway.core.coreservice.dto.ChOrderStatus;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChGetOfflineStatementReportRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChGetOfflineStatementReportResponseBean;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChOfflineStatementReportItem;
import com.caspian.moderngateway.core.coreservice.dto.vc.ChOfflineStatementRequestBean;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Atousa khanjani
 * @since 12/09/2020 02:14 PM
 */
@Component
@RequiredArgsConstructor
public class OfflineStatementConverterUtils {

    private final ParsModelMapper mapper;

    public ChOfflineStatementRequestBean convertToOfflineStatementRequest(OfflineStatementRequestDto requestDto) {
        ChOfflineStatementRequestBean requestBean = new ChOfflineStatementRequestBean();
        requestBean.setDepositNumber(requestDto.getDepositNumber());
        requestBean.setOrder(requestDto.getOrder().equals("1") ? ChOrderStatus.ASC : ChOrderStatus.DESC);
        requestBean.setFromDate(DateUtils.getTimeValue(requestDto.getFromDate(), 0, 0, 0));
        requestBean.setToDate(DateUtils.getTimeValue(requestDto.getToDate(), 23, 59, 59));
        requestBean.setFromDateTime(DateUtils.getTimeValue(requestDto.getFromDate(), requestDto.getFromDateTime()));
        requestBean.setToDateTime(DateUtils.getTimeValue(requestDto.getToDate(), requestDto.getToDateTime()));
        requestBean.setFromAmount(requestDto.getFromAmount());
        requestBean.setToAmount(requestDto.getToAmount());
        requestBean.setDescription(requestDto.getDescription());
        requestBean.setCustomerDescription("");

        if (requestDto.getActionType() != null && !requestDto.getActionType().equals("") && !requestDto.getActionType().equals("BOTH")) {
            requestBean.setChActionType(ChActionType.valueOf(requestDto.getActionType()));
        }

        requestBean.setChequeNumber(requestDto.getChequeNumber());
        return requestBean;
    }

    public static ChGetOfflineStatementReportRequestBean getOfflineStatementReportRequest(Date fromDate, Date toDate) {
        ChGetOfflineStatementReportRequestBean requestBean = new ChGetOfflineStatementReportRequestBean();
        requestBean.setFromDate(fromDate);
        requestBean.setToDate(toDate);

        return requestBean;
    }

    public static OfflineStatementReportResponseDto getOfflineStatementReportResponseDto(ChGetOfflineStatementReportResponseBean responseBean) {
        OfflineStatementReportResponseDto responseDto = new OfflineStatementReportResponseDto();
        List<OfflineStatementReportItemsDto> items = new ArrayList<>();

        for (ChOfflineStatementReportItem reportItem : responseBean.getItems()) {
            OfflineStatementReportItemsDto dto = new OfflineStatementReportItemsDto();
            dto.setAction(reportItem.getAction());
            dto.setChequeNo(reportItem.getChequeNo());
            dto.setOfflineStatementType(reportItem.getChOfflineStatementType().name());
            dto.setCustomerDescription(reportItem.getCustomerDescription());
            dto.setDealReference(reportItem.getDealReference());
            dto.setDepositNumber(reportItem.getDepositNumber());
            dto.setDescription(reportItem.getDescription());
            dto.setFromAmount(reportItem.getFromAmount());
            dto.setFromDate(reportItem.getFromDate());
            dto.setFromDateTime(reportItem.getFromDateTime());
            dto.setOrder(reportItem.getOrder());
            dto.setReceiptNo(reportItem.getReceiptNo());
            dto.setRequestDate(reportItem.getRequestDate());
            dto.setRequestId(reportItem.getRequestId());
            dto.setStatementSearchDirection(reportItem.getStatementSearchDirection());
            dto.setStatus(reportItem.getStatus());
            dto.setStatusName(reportItem.getStatusName());
            dto.setToAmount(reportItem.getToAmount());
            dto.setToDate(reportItem.getToDate());
            dto.setToDateTime(reportItem.getToDateTime());
            //File Ready
            dto.setDownloadable(reportItem.getStatus() == 3);
            items.add(dto);
        }
        responseDto.setItems(items);
        responseDto.setTotalCount(items.size());
        return responseDto;
    }


}