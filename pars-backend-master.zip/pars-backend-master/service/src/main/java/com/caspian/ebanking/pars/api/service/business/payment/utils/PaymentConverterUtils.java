package com.caspian.ebanking.pars.api.service.business.payment.utils;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.service.business.payment.dto.*;
import com.caspian.moderngateway.core.coreservice.dto.*;
import com.caspian.moderngateway.core.coreservice.dto.epayment.*;
import com.caspian.moderngateway.core.message.valuablecustomer.GetVCUserAccountsMsg;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Component
@RequiredArgsConstructor
public class PaymentConverterUtils {

    private final ParsModelMapper mapper;

    public ChBillPaymentRequestBean convertToBillPaymentRequest(BillPaymentRequestDto requestDto) {

        ChBillPaymentRequestBean requestBean = new ChBillPaymentRequestBean();
        ChCardAuthorizeParamsBean bean = new ChCardAuthorizeParamsBean();
        requestBean.setPan(requestDto.getSourceCardNumber());
        requestBean.setEmail(requestDto.getEmail() != null && !requestDto.getEmail().isEmpty() ? requestDto.getEmail() : null);
        requestBean.setVerificationExpirationTimeOut(requestDto.getVerificationExpirationTimeOut());
        requestBean.setBillId(requestDto.getBillId());
        requestBean.setPayId(requestDto.getPaymentId());
        requestBean.setRequireVerification(requestDto.getRequireVerification());
        bean.setPin(requestDto.getPin());
        bean.setExpDate(requestDto.getExpireDate());
        bean.setCvv2(requestDto.getCvv2());
        bean.setPinType(ChPinType.CARD);
        requestBean.setCardAuthorizeParams(bean);

        return requestBean;
    }

    public BillPaymentResponseDto convertToBillPaymentResponse(ChBillPaymentResponseBean responseBean) {

        BillPaymentResponseDto responseDto = new BillPaymentResponseDto();
        responseDto.setPayId(responseBean.getPayId());
        responseDto.setBillTitle(responseBean.getBillTitle());
        responseDto.setBillForeignTitle(responseBean.getBillForeignTitle());
        responseDto.setBillId(responseBean.getBillId());
        responseDto.setBillType(responseBean.getBillType());
        responseDto.setAmount(responseBean.getAmount());
        responseDto.setCycle(responseBean.getCycle());
        responseDto.setTransactionDate(responseBean.getTransactionDate());
        responseDto.setFileCode(responseBean.getFileCode());
        responseDto.setTransactionNum(responseBean.getReferralNumber());

        return responseDto;

    }

    public BillPaymentReportResponseDto convertToBillPaymentReportResponse(ChPayedBillsResponseBean responseBean) {
        BillPaymentReportResponseDto responseDto = new BillPaymentReportResponseDto();
        responseDto.setBillPaymentReportDtos(mapper.mapList(responseBean.getPayedBills(), BillPaymentReportDto.class));
        responseDto.setTotalCount(responseBean.getTotalCount());
        return responseDto;
    }

    public ChAddPeriodRequestBean convertToAddPeriodRequest(PeriodRequestDto requestDto) {
        ChAddPeriodRequestBean requestBean = mapper.map(requestDto, ChAddPeriodRequestBean.class);
        requestBean.setPeriodAccountBeans(getPeriodRequestBean(requestDto));
        return requestBean;
    }

    private List<ChPeriodAccountBean> getPeriodRequestBean(PeriodRequestDto requestDto) {
        List<ChPeriodAccountBean> accountBeans = new ArrayList<>();
        ChPeriodAccountBean chPeriodAccountBean = new ChPeriodAccountBean();
        chPeriodAccountBean.setPeriodCode(requestDto.getPeriodCode());
        chPeriodAccountBean.setExternalRef(requestDto.getExternalRef());
        accountBeans.add(chPeriodAccountBean);
        return accountBeans;
    }

    public ChUpdatePeriodRequestBean convertToUpdatePeriodRequest(PeriodRequestDto requestDto) {
        ChUpdatePeriodRequestBean requestBean = mapper.map(requestDto, ChUpdatePeriodRequestBean.class);
        requestBean.setPeriodAccountBeans(getPeriodRequestBean(requestDto));
        return requestBean;
    }

    public GetVCUserAccountsMsg.Inbound getUserAccountsConverter(String user, String accountType, Long organizationId) {
        GetVCUserAccountsMsg.Inbound inbound = new GetVCUserAccountsMsg.Inbound();
        inbound.setUserName(user);
        inbound.setAccountTypeFilter(accountType);
        inbound.setOrganizationId(String.valueOf(organizationId));
        return inbound;
    }

    public LoadPeriodResponseDto convertToLoadPeriodResponse(ChLoadPeriodsResponseBean responseBean) {
        LoadPeriodResponseDto responseDto = new LoadPeriodResponseDto();
        List<PeriodRequestDto> periodDtoList = new ArrayList<>();
        for (ChPeriodBean bean : responseBean.getPeriodBeans()) {
            PeriodRequestDto periodDto = getPeriodRequestDto(bean);
            periodDtoList.add(periodDto);
        }

        responseDto.setPeriodDtoList(periodDtoList);
        return responseDto;
    }

    public LoadPeriodHistoryResponseDto convertToLoadPeriodHistoryResponse(ChLoadPeriodHistoryResponseBean responseBean) {
        LoadPeriodHistoryResponseDto responseDto = new LoadPeriodHistoryResponseDto();
        List<PeriodRequestDto> periodDtoList = new ArrayList<>();
        for (ChPeriodHistoryBean bean : responseBean.getPeriodHistoryBeans()) {
            PeriodRequestDto periodDto = getPeriodRequestDto(bean);
            periodDtoList.add(periodDto);
        }

        responseDto.setPeriodDtoList(periodDtoList);
        return responseDto;
    }

    private PeriodRequestDto getPeriodRequestDto(ChPeriodHistoryBean bean) {
        PeriodRequestDto periodDto = new PeriodRequestDto();
        periodDto.setEndDate(bean.getEndDate());
        periodDto.setExternalRef(bean.getExternalRef());
        periodDto.setId(bean.getId());
        periodDto.setMaxAmount(bean.getMaxAmount());
        periodDto.setMinAmount(bean.getMinAmount());
        periodDto.setPeriodCode(bean.getPeriodCode());
        periodDto.setStartDate(bean.getStartDate());
        periodDto.setTitle(bean.getTitle());
        return periodDto;
    }

    private PeriodRequestDto getPeriodRequestDto(ChPeriodBean bean) {
        PeriodRequestDto periodDto = new PeriodRequestDto();
        periodDto.setEndDate(bean.getEndDate());
        periodDto.setExternalRef(bean.getAccountId());
        periodDto.setId(bean.getId());
        periodDto.setMaxAmount(bean.getMaxAmount());
        periodDto.setMinAmount(bean.getMinAmount());
        periodDto.setPeriodCode(bean.getPeriodCode());
        periodDto.setStartDate(bean.getStartDate());
        periodDto.setTitle(bean.getTitle());
        return periodDto;
    }


}


