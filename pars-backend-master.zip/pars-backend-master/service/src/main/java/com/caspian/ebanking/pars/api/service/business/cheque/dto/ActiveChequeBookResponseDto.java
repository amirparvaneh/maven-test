package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۶/۰۲/۲۰۲۱ ۰۲:۵۰ بعدازظهر
 */
@Data
public class ActiveChequeBookResponseDto {
    private List<ChequeBookDto> chequeBookDtos;
    private Long totalRecord;
}