package com.caspian.ebanking.pars.api.service.business.pichak.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Data
public class ChequeCartableDetailDto {
    private ChequeCartableRequestDto chequeCartableRequestDto;
    private List<ChequeCartableApprovalDto> chequeCartableApprovalDtos;
    private List<ChequeCartableStakeholderDto> cartableStakeholderDtos;
    private List<ChequeCartableSignerDto> chequeCartableSignerDtos;
}
