package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۲/۰۲/۲۰۲۱ ۱۲:۵۶ بعدازظهر
 */
@Data
public class ReferenceCodeReportResponseDto {
    List<ReferenceCodeReportItemDto> itemDtoList;
}