package com.caspian.ebanking.pars.api.service.business.cartable.dto;

import lombok.Data;

import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۱۳/۰۱/۲۰۲۱ ۰۳:۱۵ قبل‌ازظهر
 */
@Data
public class CartableResponseDto {
    List<CartableResponseItemDto> dtoList;
}