package com.caspian.ebanking.pars.api.service.business.pichak.service;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.service.business.pichak.dto.*;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.cartable.service.dto.cartablecheque.ChApproveChequeCartableRequestBean;
import com.caspian.moderngateway.core.cartable.service.dto.cartablecheque.ChCancelChequeCartableRequestBean;
import com.caspian.moderngateway.core.cartable.service.dto.cartablecheque.ChDoCartableRequestRequestBean;
import com.caspian.moderngateway.core.cartable.service.dto.cartablecheque.ChRejectChequeCartableRequestBean;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.pichak.*;
import com.caspian.moderngateway.core.message.cartablecheque.*;
import com.caspian.moderngateway.core.message.pichak.PichakAcceptChequeMsg;
import com.caspian.moderngateway.core.message.pichak.PichakInquiryChequeMsg;
import com.caspian.moderngateway.core.message.pichak.PichakIssueChequeMsg;
import com.caspian.moderngateway.core.message.pichak.PichakTransferChequeMsg;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/06/2021 07:18 PM
 */
@Service
@RequiredArgsConstructor
public class PichakServiceImpl extends BaseService implements PichakService {
    private final ParsModelMapper mapper;
    private final CurrentUserService currentUserService;

    @Override
    public PichakIssueChequeResponseDto pichakIssueCheque(PichakIssueChequeRequestDto requestDto) {
        ChPichakIssueChequeRequestBean requestBean = mapper.map(requestDto, ChPichakIssueChequeRequestBean.class);
        PichakIssueChequeResponseDto responseDto;
        try {
            PichakIssueChequeMsg.Inbound inbound = new PichakIssueChequeMsg.Inbound();
            inbound.setRequestBean(requestBean);

            PichakIssueChequeMsg.Outbound outbound = channelManagerProvider.execute(inbound, PichakIssueChequeMsg.Outbound.class);
            responseDto = mapper.map(outbound.getResponseBean(), PichakIssueChequeResponseDto.class);
            return responseDto;
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public PichakTransferChequeResponseDto pichakTransferCheque(PichakTransferChequeRequestDto requestDto) {
        ChPichakTransferChequeRequestBean requestBean = mapper.map(requestDto, ChPichakTransferChequeRequestBean.class);
        requestBean.setHolderClientId(String.valueOf(currentUserService.getCustomerCode()));
        try {
            PichakTransferChequeMsg.Inbound inbound = new PichakTransferChequeMsg.Inbound();
            inbound.setRequestBean(requestBean);
            PichakTransferChequeMsg.Outbound outbound = channelManagerProvider.execute(inbound, PichakTransferChequeMsg.Outbound.class);
            return mapper.map(outbound.getResponseBean(), PichakTransferChequeResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public PichakChequeInquiryResponseDto pichakChequeInquiry(PichakInquiryChequeRequestDto requestDto) {
        PichakInquiryChequeMsg.Inbound inbound = new PichakInquiryChequeMsg.Inbound();
        ChPichakInquiryChequeRequestBean requestBean = mapper.map(requestDto, ChPichakInquiryChequeRequestBean.class);
        inbound.setRequestBean(requestBean);
        try {
            PichakInquiryChequeMsg.Outbound outbound = channelManagerProvider.execute(inbound, PichakInquiryChequeMsg.Outbound.class);
            return mapper.map(outbound.getResponseBean(), PichakChequeInquiryResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public PichakSetChequeConfirmStatusResponseDto setChequeConfirmStatus(PichakSetChequeConfirmStatusRequestDto requestDto) {
        PichakAcceptChequeMsg.Inbound inbound = new PichakAcceptChequeMsg.Inbound();
        ChPichakAcceptChequeRequestBean requestBean = mapper.map(requestDto, ChPichakAcceptChequeRequestBean.class);
        requestBean.setAcceptorClientId(Long.valueOf(currentUserService.getCustomerCode()));
        inbound.setRequestBean(requestBean);
        try {
            PichakAcceptChequeMsg.Outbound outbound = channelManagerProvider.execute(inbound, PichakAcceptChequeMsg.Outbound.class);
            return mapper.map(outbound.getResponseBean(), PichakSetChequeConfirmStatusResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public GetChequeCartableResponseDto getChequeCartable(GetChequeCartableRequestDto requestDto) {
        GetChequeCartableRequestMsg.Inbound inbound = new GetChequeCartableRequestMsg.Inbound();
        try {
            GetChequeCartableRequestMsg.Outbound outbound = channelManagerProvider.execute(inbound, GetChequeCartableRequestMsg.Outbound.class);
            GetChequeCartableResponseDto responseDto = mapper.map(outbound.getResponseBean(), GetChequeCartableResponseDto.class
            );
            if (responseDto != null) {
                responseDto.setCurrentUserCustomerNo(currentUserService.getCustomerCode());
            }
            return responseDto;
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public DoChequeCartableResponseDto doChequeCartable(DoChequeCartableRequestDto requestDto) {
        DoChequeCartableRequestMsg.Inbound inbound = new DoChequeCartableRequestMsg.Inbound();
        inbound.setRequestBean(mapper.map(requestDto, ChDoCartableRequestRequestBean.class));

        try {
            DoChequeCartableRequestMsg.Outbound outbound = channelManagerProvider.execute(inbound, DoChequeCartableRequestMsg.Outbound.class);
            return mapper.map(outbound.getResponseBean(), DoChequeCartableResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public ApproveChequeCartableResponseDto approveChequeCartable(ApproveChequeCartableRequestDto requestDto) {
        ApproveChequeCartableRequestMsg.Inbound inbound = new ApproveChequeCartableRequestMsg.Inbound();
        inbound.setRequestBean(mapper.map(requestDto, ChApproveChequeCartableRequestBean.class));

        try {
            ApproveChequeCartableRequestMsg.Outbound outbound = channelManagerProvider.execute(inbound, ApproveChequeCartableRequestMsg.Outbound.class);
            return mapper.map(outbound.getResponseBean(), ApproveChequeCartableResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public CancelChequeCartableResponseDto cancelChequeCartable(CancelChequeCartableRequestDto requestDto) {
        CancelChequeCartableRequestMsg.Inbound inbound = new CancelChequeCartableRequestMsg.Inbound();
        inbound.setRequestBean(mapper.map(requestDto, ChCancelChequeCartableRequestBean.class));
        try {
            CancelChequeCartableRequestMsg.Outbound outbound = channelManagerProvider.execute(inbound, CancelChequeCartableRequestMsg.Outbound.class);
            return mapper.map(outbound.getResponseBean(), CancelChequeCartableResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public RejectChequeCartableResponseDto rejectChequeCartable(RejectChequeCartableRequestDto requestDto) {
        RejectChequeCartableRequestMsg.Inbound inbound = new RejectChequeCartableRequestMsg.Inbound();
        inbound.setRequestBean(mapper.map(requestDto, ChRejectChequeCartableRequestBean.class));
        try {
            RejectChequeCartableRequestMsg.Outbound outbound = channelManagerProvider.execute(inbound, RejectChequeCartableRequestMsg.Outbound.class);
            return mapper.map(outbound.getResponseBean(), RejectChequeCartableResponseDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }
}
