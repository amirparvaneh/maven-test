package com.caspian.ebanking.pars.api.service.business.file.utils;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.log4j.Logger;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;


public class FtpFileReader extends FtpFileBase {
    private static final Logger log = Logger.getLogger(FtpFileReader.class);

    private static String basePath;

    public FtpFileReader(FTPClient ftpClient) {
        super(ftpClient);
    }

    public FtpFileReader() {
        super(new FTPClient());
        basePath = FileReaderWriterModel.getInstance().getLoadedBasePath();
    }

    public int readFileSize(String path) {
        try {
            FTPFile[] file = ftpClient.listFiles(path);
            if (file != null && file.length > 0 && file[0].isFile())
                return (int) file[0].getSize();
            return -1;
        } catch (IOException e) {
            log.error(e);
            return -1;
        }
    }

    public byte[] read(String path) {
        int fileSize = readFileSize(basePath + path);

        if (fileSize <= 0)
            return null;
        byte[] result = new byte[fileSize];
        InputStream fileInput = null;
        try {
            fileInput = new BufferedInputStream(ftpClient.retrieveFileStream(basePath + path));
            int totalBytesRead = 0;
            while (totalBytesRead < result.length) {
                int bytesRemaining = result.length - totalBytesRead;
                //input.read() returns -1, 0, or more :
                int bytesRead = fileInput.read(result, totalBytesRead, bytesRemaining);
                if (bytesRead > 0) {
                    totalBytesRead = totalBytesRead + bytesRead;
                }
            }
        } catch (IOException e) {
            log.error(e);
            result = null;
            return null;
        } finally {
            try {
                if (fileInput != null)
                    fileInput.close();
            } catch (IOException e) {
                log.error(e);
            }
        }
        return result;
    }

}
