package com.caspian.ebanking.pars.api.service.business.filegrouptransfer.service;

import com.caspian.ebanking.pars.api.base.exception.GatewayException;
import com.caspian.ebanking.pars.api.service.business.filegrouptransfer.dto.*;
import com.caspian.ebanking.pars.api.service.business.filegrouptransfer.utils.FileGroupTransferConvertUtils;
import com.caspian.ebanking.pars.api.service.configuration.service.BaseService;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.groupfiletransfer.ChGroupTransferCancelRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.groupfiletransfer.ChGroupTransferDetailCancelRequestBean;
import com.caspian.moderngateway.core.coreservice.dto.groupfiletransfer.ChGroupTransferFinalConfirmRequestBean;
import com.caspian.moderngateway.core.message.cartable.groupfiletransfer.RegisterCartableGroupFileTransferMsg;
import com.caspian.moderngateway.core.message.dto.groupfiletransfer.CartableGroupFileTransferDto;
import com.caspian.moderngateway.core.message.dto.groupfiletransfer.CartableGroupFileTransferEntryDto;
import com.caspian.moderngateway.core.message.groupfiletransfer.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * @author Atousa khanjani
 * @version 1.0
 * @since 1/4/2021 12:36 PM
 */
@Service
@RequiredArgsConstructor
public class FileGroupTransferServiceImpl extends BaseService implements FileGroupTransferService {

    private final FileGroupTransferConvertUtils fileGroupTransferConvertUtils;


    @Override
    public RegisterGroupTransferResponseDto registerGroupTransfer(RegisterGroupTransferRequestDto requestDto) {
        RegisterGroupTransferMsg.Inbound inbound = new RegisterGroupTransferMsg.Inbound();
        inbound.setGroupTransferRegisterRequestBean(fileGroupTransferConvertUtils.convertToGroupTransferRegisterRequestBean(requestDto));
        try {
            RegisterGroupTransferMsg.Outbound result = channelManagerProvider.execute(inbound, RegisterGroupTransferMsg.Outbound.class);
            return fileGroupTransferConvertUtils.convertToRegisterGroupTransferResponseDto(result.getGroupTransferRegisterResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public SearchGroupTransferResponseDto searchGroupTransfer(SearchGroupTransferRequestDto requestDto) {
        SearchGroupTransferMsg.Inbound inbound = new SearchGroupTransferMsg.Inbound();
        inbound.setGroupTransferSearchRequestBean(fileGroupTransferConvertUtils.convertToGroupTransferSearchRequestBean(requestDto));
        try {
            SearchGroupTransferMsg.Outbound result = channelManagerProvider.execute(inbound, SearchGroupTransferMsg.Outbound.class);
            return fileGroupTransferConvertUtils.convertToSearchGroupTransferResponseDto(result.getGroupTransferSearchResponseBean());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public SearchGroupTransferDetailResponseDto searchGroupTransferDetail(SearchGroupTransferDetailRequestDto requestDto) {
        SearchGroupTransferDetailMsg.Inbound inbound = new SearchGroupTransferDetailMsg.Inbound();
        inbound.setGroupTransferDetailSearchRequestBean(fileGroupTransferConvertUtils.convertToGroupTransferDetailSearchRequestBean(requestDto));
        try {
            SearchGroupTransferDetailMsg.Outbound result = channelManagerProvider.execute(inbound, SearchGroupTransferDetailMsg.Outbound.class);
            return fileGroupTransferConvertUtils.convertToSearchGroupTransferDetailResponseDto(result.getGroupTransferDetailSearchResponseBean().getGroupTransferDetailBeans());
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public GroupTransferDto cancelGroupTransfer(CancelGroupTransferDto cancelGroupTransferDto) {
        CancelGroupTransferMsg.Inbound inbound = new CancelGroupTransferMsg.Inbound();
        ChGroupTransferCancelRequestBean requestBean = new ChGroupTransferCancelRequestBean();
        requestBean.setGroupTransferId(cancelGroupTransferDto.getGroupTransferId());
        inbound.setCancelRequestBean(requestBean);
        try {
            CancelGroupTransferMsg.Outbound result = channelManagerProvider.execute(inbound, CancelGroupTransferMsg.Outbound.class);
            return mapper.map(result.getCancelResponseBean().getGroupTransferBean(), GroupTransferDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public GroupTransferDetailDto cancelGroupTransferDetail(CancelGroupTransferDetailDto cancelGroupTransferDetailDto) {
        CancelGroupTransferDetailMsg.Inbound inbound = new CancelGroupTransferDetailMsg.Inbound();
        ChGroupTransferDetailCancelRequestBean requestBean = new ChGroupTransferDetailCancelRequestBean();
        requestBean.setGroupTransferDetailId(cancelGroupTransferDetailDto.getGroupTransferDetailId());
        inbound.setDetailCancelRequestBean(requestBean);
        try {
            CancelGroupTransferDetailMsg.Outbound result = channelManagerProvider.execute(inbound, CancelGroupTransferDetailMsg.Outbound.class);
            return mapper.map(result.getDetailCancelResponseBean().getGroupTransferDetailBean(), GroupTransferDetailDto.class);
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public GetGroupTransferConfigResponseDto getGroupTransferConfig() {
        GetGroupFileTransferConfigMsg.Inbound inbound = new GetGroupFileTransferConfigMsg.Inbound();
        GetGroupTransferConfigResponseDto responseDto = new GetGroupTransferConfigResponseDto();
        try {
            GetGroupFileTransferConfigMsg.Outbound result = channelManagerProvider.execute(inbound, GetGroupFileTransferConfigMsg.Outbound.class);
            responseDto.setRequiredAmountAndCount(result.getGroupTransferGetConfigResponseBean().isRequiredAmountAndCount());
            return responseDto;
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public FinalConfirmGroupTransferResponseDto finalConfirmGroupTransfer(FinalConfirmGroupTransferRequestDto requestDto) {
        FinalConfirmGroupTransferMsg.Inbound inbound = new FinalConfirmGroupTransferMsg.Inbound();
        ChGroupTransferFinalConfirmRequestBean requestBean = new ChGroupTransferFinalConfirmRequestBean();
        requestBean.setGroupTransferId(requestDto.getGroupTransferId());
        FinalConfirmGroupTransferResponseDto responseDto = new FinalConfirmGroupTransferResponseDto();
        try {
            FinalConfirmGroupTransferMsg.Outbound result = channelManagerProvider.execute(inbound, FinalConfirmGroupTransferMsg.Outbound.class);
//            GroupTransferDto groupTransferDto = mapper.map(result.getFinalConfirmResponseBean().getGroupTransferBean(), GroupTransferDto.class);
//            responseDto.setGroupTransferDto(groupTransferDto);
//            return responseDto;
            return null;
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }

    @Override
    public RegisterCartableGroupFileTransferResponseDto registerCartableGroupFileTransfer(RegisterCartableGroupFileTransferRequestDto requestDto) {
        RegisterCartableGroupFileTransferMsg.Inbound inbound = new RegisterCartableGroupFileTransferMsg.Inbound();
        CartableGroupFileTransferDto requestBean = new CartableGroupFileTransferDto();
        requestBean.setCartableGroupFileTransferEntryDto(mapper.map(requestDto.getCartableGroupFileTransferItemDto(), CartableGroupFileTransferEntryDto.class));
        RegisterCartableGroupFileTransferResponseDto responseDto = new RegisterCartableGroupFileTransferResponseDto();
        try {
            RegisterCartableGroupFileTransferMsg.Outbound result = channelManagerProvider.execute(inbound, RegisterCartableGroupFileTransferMsg.Outbound.class);
            CartableGroupFileTransferItemDto dto = mapper.map(result.getCartableGroupFileTransferDto().getCartableGroupFileTransferEntryDto(), CartableGroupFileTransferItemDto.class);
            responseDto.setCartableGroupFileTransferItemDto(dto);
            return responseDto;
        } catch (ChannelManagerException e) {
            throw new GatewayException(e);
        }
    }
}
