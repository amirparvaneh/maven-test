package com.caspian.ebanking.pars.api.service.configuration.service;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.spi.ParsChannelManagerProvider;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 2:37 PM
 */
@SuppressWarnings("SpringJavaAutowiredFieldsWarningInspection")
@Service
@NoArgsConstructor
public abstract class BaseService {

    @Autowired
    protected ParsChannelManagerProvider channelManagerProvider;

    @Autowired
    protected ParsModelMapper mapper;

}
