package com.caspian.ebanking.pars.api.service.business.payment.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Atousa Khanjani
 * @version 1.0
 * @since 02/09/2021 07:18 PM
 */
@Data
public class PeriodPersonRequestDto {
    private Long id;
    @ApiModelProperty(value = "نام")
    private String firstName;
    @ApiModelProperty(value = "نام خانوادگی")
    private String lastName;
    @ApiModelProperty(value = "شماره شناسنامه")
    private Long identityNo;
    @ApiModelProperty(value = "کد ملی")
    private String nationalCode;
    @ApiModelProperty(value = "نام پدر")
    private String fatherName;
    @ApiModelProperty(value = "محل ثبت")
    private String registrationPlace;
    @ApiModelProperty(value = "شماره شناسایی")
    private String idNo;
    @ApiModelProperty(value = "شماره حواله")
    private String orderNo;
    @ApiModelProperty(value = "شماره موبایل")
    private String mobileNo;
    @ApiModelProperty(value = "مبلغ")
    private Long amount;
    @ApiModelProperty(value = "شناسه پرداخت")
    private String paymentId;
    @ApiModelProperty(value = "کد سهامداری")
    private String stocksCode;
    @ApiModelProperty(value = "حساب تامین وجه")
    private String periodAccountId;
    @ApiModelProperty(value = "دوره پرداخت")
    private String periodCode;
    @ApiModelProperty(value = "نوع مشتری ", allowableValues = "اتباع خارجی=3,حقوقی=2,حقیقی=1")
    private Integer personType;
}
