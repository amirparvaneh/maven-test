package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChReferenceCodeDetailBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۱/۰۲/۲۰۲۱ ۱۰:۵۵ قبل‌ازظهر
 */
@Data
public class CreateReferenceCodeRequestDto {
    @ApiModelProperty(value = "کد واریز کننده")
    private String liquidatorCode;

    @ApiModelProperty(value = "نام واریز کننده")
    private String liquidatorName;

    private String phoneNumber;

    @ApiModelProperty(value = "توضیحات/نشانی")
    private String description;

    @ApiModelProperty(value = "نوع شناسه", allowableValues = " CONTINUES,TEMPORARY,MIXED")
    private String referenceCodeType;

    private String settleTitleCode;
    private List<ReferenceCodeDetailDto> referenceCodeDetailList;

    @ApiModelProperty(value = "پارامتر اضافی")
    private String extraParameter;

    @ApiModelProperty(value = "جایگاه پارامتر اضافی", allowableValues = " ENDOFREFERENCECODE,ENDOFREFERENCECODE")
    private String extraParameterPosition;

    private Date expireDate;
}