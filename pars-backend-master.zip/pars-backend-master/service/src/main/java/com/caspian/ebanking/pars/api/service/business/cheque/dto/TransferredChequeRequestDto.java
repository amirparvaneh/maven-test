package com.caspian.ebanking.pars.api.service.business.cheque.dto;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.AccountNo;
import com.caspian.moderngateway.core.channelmanagerinfrastructure.annotation.FinancialSourceNoProperty;
import com.caspian.moderngateway.core.coreservice.dto.ChChequeFieldOrder;
import com.caspian.moderngateway.core.coreservice.dto.ChChequeType;
import com.caspian.moderngateway.core.coreservice.dto.ChOrderType;
import com.caspian.moderngateway.core.coreservice.dto.ChTransferChequeStatus;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۷/۰۲/۲۰۲۱ ۰۱:۵۶ بعدازظهر
 */
@Data
public class TransferredChequeRequestDto {
    @NotNull
    @ApiModelProperty(value = "شماره حساب")
    private String depositNumber;
    @ApiModelProperty(value = "بانک ذینفع")
    private String deviseeBankCode;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تاریخ چک از")
    private Date fromRegisterDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تاریخ چک تا")
    private Date toRegisterDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تاریخ وصول از")
    private Date fromDueDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تاریخ وصول تا")
    private Date toDueDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تاریخ واگذاری از")
    private Date fromPassDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "تاریخ واگذاری تا")
    private Date toPassDate;

    @ApiModelProperty(value = "شماره چک از")
    private String fromNumber;
    @ApiModelProperty(value = "شماره چک تا")
    private String toNumber;

    @ApiModelProperty(value = "مبلغ چک از")
    private BigDecimal fromBalance;

    @ApiModelProperty(value = "مبلغ چک تا")
    private BigDecimal toBalance;

    @NotNull
    private Long length;
    @NotNull
    private Long offset;


   /* @ApiModelProperty(value = "", allowableValues = "IN_WAY,CASH,REJECT,SEND_TO_CLER,RETURN,RETURN_REJECT,WITHOUT_ACTION,RETURN_WITHOUT_ACTION")
    private String includeStatus;

    @ApiModelProperty(value = "وضعیت چک", allowableValues = "CURRENT_CHEQUE,BANK_DRAFT_CHEQUE,GUARANTEE_CHEQUE,\n" +
            "    TRAVELS_CHEQUE,OTHERS_CHEQUE, BANK_CHEQUE,IRAN_CHEQUE")
    private String includeType;*/

   /* @ApiModelProperty(value = "", allowableValues = "CHECK_NUMBER,CHECK_DATE")
    private String orderMethod;

    @ApiModelProperty(value = "ترتیب", allowableValues = "ASCENDING,DESCENDING")
    private String orderType;*/


}