package com.caspian.ebanking.pars.api.service.business.referencecode.dto;

import com.caspian.moderngateway.core.coreservice.dto.LiquidatorHierarchyResponseBean;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۰۱/۰۲/۲۰۲۱ ۰۳:۲۵ بعدازظهر
 */
@Data
public class LiquidatorHierarchyItemDto {
    private Long id;
    private Long parentId;
    @ApiModelProperty(value = "واریز کننده")
    private String liquidator;
    @ApiModelProperty(value = "کد واریز کننده")
    private String liquidatorCode;
    private String description;
    private String telNo;
    private String email;
    private String address;
    private Long organizationId;
    private Long departmentId;
    private List<LiquidatorHierarchyItemDto> children = new ArrayList();
    private Date insertSysDate;
    private String insertUser;
    private Date updateSysDate;
    private String updateUser;
    private Long version;
}