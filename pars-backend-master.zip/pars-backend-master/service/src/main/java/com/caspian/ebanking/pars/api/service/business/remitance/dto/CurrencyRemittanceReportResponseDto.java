package com.caspian.ebanking.pars.api.service.business.remitance.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author Maryam Rezaei
 * @version 1.0
 * @since ۲۵/۰۱/۲۰۲۱ ۱۰:۰۶ قبل‌ازظهر
 */
@Data
public class CurrencyRemittanceReportResponseDto {
    private List<CurrencyRemittanceReportItemDto> reportItemDtoList;
}