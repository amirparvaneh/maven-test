package com.caspian.ebanking.pars.api.base.annotation;

import com.caspian.ebanking.pars.api.base.security.dto.enums.CaptchaType;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 2:25 PM
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface CaptchaValidateMethod {
    CaptchaType type();
}
