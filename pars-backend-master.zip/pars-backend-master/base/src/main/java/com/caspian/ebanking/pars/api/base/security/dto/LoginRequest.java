package com.caspian.ebanking.pars.api.base.security.dto;

import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 2:33 PM
 */
@Data
public class LoginRequest {
    private String username;
    private String password;
    private String passwordType;
    private String captcha;
    private String captchaChallengeKey;

}
