package com.caspian.ebanking.pars.api.base.security;

import com.caspian.ebanking.pars.api.base.exception.BadRequestException;
import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import com.caspian.ebanking.pars.api.base.persistence.repositories.ClientDataControlRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 11:40 PM
 */
@Service
@Profile("jwtAuth")
public class JwtCurrentUserService implements CurrentUserService {

    private static final Logger logger = LoggerFactory.getLogger(JwtCurrentUserService.class);

    private final ClientDataControlRepository repository;

    @Autowired
    public JwtCurrentUserService(ClientDataControlRepository repository) {
        this.repository = repository;
    }

    @Override
    public String getChannelSessionId() {
        logger.info("JwtCurrentUserService.getChannelSessionId");
        final Jws<Claims> claims = getClaims();
        if (claims != null) {
            //TODO
            logger.info("JwtCurrentUserService.getChannelSessionId: " + String.valueOf(claims.getBody().get("third_party_session_id")));
            return String.valueOf(claims.getBody().get("third_party_session_id"));
        }
        return null;
    }

    @Override
    public String getUsername() {
        logger.info("JwtCurrentUserService.getUsername");
        final User principal = getPrincipal();
        if (principal != null)
            return principal.getUsername();
        return null;
    }

    @Override
    public String getCustomerCode() {
        logger.info("JwtCurrentUserService.getCustomerCode");

        final Jws<Claims> claims = getClaims();
        if (claims != null) {
            //TODO
            logger.info("JwtCurrentUserService.getCustomerCode: " + String.valueOf(claims.getBody().get("cno")));
            return String.valueOf(claims.getBody().get("cno"));
        }
        return null;
    }

    @Override
    public Long getTokenIssuedAt() {
        logger.info("JwtCurrentUserService.getTokenIssuedAt");

        final Jws<Claims> claims = getClaims();
        if (claims != null) {
            //TODO
            logger.info("JwtCurrentUserService.getTokenIssuedAt: " + claims.getBody().getIssuedAt());
            return claims.getBody().getIssuedAt().getTime();
        }
        return null;
    }

    @Override
    public ClientDataControl setCurrentOrganization(Long organizationId, String departmentId) {
        final ClientDataControl clientDataControl = this.getClientDataControl();
        if (clientDataControl != null) {
            clientDataControl.setSelectedOrganizationId(organizationId);
            clientDataControl.setSelectedDepartmentId(departmentId);
            clientDataControl.setUpdated(new Date());
            repository.save(clientDataControl);
        }
        return clientDataControl;
    }

    @Override
    public Long getCurrentOrganizationId() {
        final ClientDataControl clientDataControl = this.getClientDataControl();
        if (clientDataControl == null || clientDataControl.getSelectedOrganizationId() == null)
            throw new BadRequestException("Organization Not Selected.");
        return clientDataControl.getSelectedOrganizationId();
    }

    @Override
    public String getCurrentDepartmentId() {
        final ClientDataControl clientDataControl = this.getClientDataControl();
        if (clientDataControl == null || clientDataControl.getSelectedDepartmentId() == null)
            throw new BadRequestException("Organization Not Selected.");
        return clientDataControl.getSelectedDepartmentId();
    }

    @Override
    public ClientDataControl getClientDataControl() {
        return repository.findFirstByCustomerCodeOrderByCreatedDesc(getCustomerCode());
    }

    @Override
    public ClientDataControl updateLastSuccessfulActive() {
        final ClientDataControl clientDataControl = getClientDataControl();
        if (clientDataControl != null) {
            Date timestamp = new Date();
            clientDataControl.setRequestsNum(clientDataControl.getRequestsNum() + 1);
            clientDataControl.setLastActiveTime(timestamp);
            clientDataControl.setUpdated(timestamp);
            repository.save(clientDataControl);
        }
        return clientDataControl;
    }

    @Override
    public ClientDataControl incrementFailedRequestCount() {
        final ClientDataControl clientDataControl = getClientDataControl();
        if (clientDataControl != null) {
            Date timestamp = new Date();
            clientDataControl.setFailedRequestsNum(clientDataControl.getFailedRequestsNum() + 1);
            clientDataControl.setLastActiveTime(timestamp);
            clientDataControl.setUpdated(timestamp);
            repository.save(clientDataControl);
        }
        return clientDataControl;
    }

    @Override
    public void removeAllClientDataControlData() {
        repository.deleteAllByCustomerCode(getCustomerCode());
    }

    @Scheduled(fixedRate = 60000)
    public void clearInactiveUserData() {
        //TODO
//        logger.info("Start Clear inactive user data");
//        long start = System.currentTimeMillis();
//
//        Calendar c = Calendar.getInstance();
//        c.setTime(new Date());
//        c.add(Calendar.MINUTE, -10); //10 minutes of inactivity will remove the user
//        final Date time = c.getTime();
//
//        repository.deleteByLastActiveTimeLessThan(time);

//        logger.info("Clear inactive user data done.Execution Time: " + (System.currentTimeMillis() - start));
    }

    private Jws<Claims> getClaims() {
        try {
            final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.isAuthenticated()) {
                //noinspection unchecked
                return (Jws<Claims>) authentication.getDetails();
            }
            throw new Exception();
        } catch (Exception e) {
            return null;
        }
    }

    private User getPrincipal() {
        try {
            final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.isAuthenticated()) {
                //noinspection unchecked
                return (User) authentication.getPrincipal();
            }
            throw new Exception();
        } catch (Exception e) {
            return null;
        }
    }
}
