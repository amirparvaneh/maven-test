package com.caspian.ebanking.pars.api.base.persistence.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/23/2020 11:32 AM
 */
@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
public class ServiceLog {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String serviceName;
    private Long executionTime;

    @Column(columnDefinition = "VARCHAR(2048)")
    private String clientFullInfo;

    private Boolean isSuccessful;
    private Date created;

}
