package com.caspian.ebanking.pars.api.base.spi;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.infrastructurespi.common.message.ChMessageHeader;
import com.caspian.moderngateway.spi.service.ChannelManagerProvider;
import org.springframework.security.access.AccessDeniedException;

import java.io.Serializable;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/13/2020 3:45 PM
 */
public interface ParsChannelManagerProvider {

    /**
     * composited method to handle all execute calls ... custom message headers are now only user by LOGIN and LOGOUT
     *
     * @param messageHeader custom message header
     * @param inbound       inbound obj
     * @param outboundClass outbound class type to return
     * @param withSessionId send the message with session id or not
     * @return outbound object
     * @throws ChannelManagerException when any exception thrown in channel
     */
    default <T extends Serializable, I extends Serializable, O extends Serializable> O execute(T messageHeader, I inbound, Class<O> outboundClass, boolean withSessionId) throws ChannelManagerException {
        if (withSessionId) {
            if (messageHeader == null) {
                throw new AccessDeniedException("invalid header data");
            }
            return this.execute(messageHeader, inbound, outboundClass, getChannelSessionId());
        } else {
            return this.getChannelManagerProvider().execute(messageHeader, inbound, outboundClass);
        }
    }

    default <T extends Serializable, I extends Serializable, O extends Serializable> O execute(T messageHeader, I inbound, Class<O> outboundClass, String sessionId) throws ChannelManagerException {
        return this.getChannelManagerProvider().execute(messageHeader, inbound, outboundClass, sessionId);
    }

    /**
     * Send request to channel manager with current session id
     *
     * @see #execute(Serializable, Serializable, Class, boolean)
     */
    default <I extends Serializable, O extends Serializable> O execute(I inbound, Class<O> outboundClass) throws ChannelManagerException {
        return this.execute(getChMessageHeaders(), inbound, outboundClass, true);
    }

    String getChannelSessionId();

    ChannelManagerProvider getChannelManagerProvider();

    ChMessageHeader getChMessageHeaders();

}
