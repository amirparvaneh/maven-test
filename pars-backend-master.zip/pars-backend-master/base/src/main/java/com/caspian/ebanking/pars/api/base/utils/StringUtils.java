package com.caspian.ebanking.pars.api.base.utils;

import java.util.stream.IntStream;

/**
 * String utils service class , all needed string operations is available here
 *
 * @author Amir Tajik
 * @author Saman Delfani
 * @author Homa Sedigh
 * @version 1.0
 * @since 03/19/2018 03:25 PM
 */
public final class StringUtils {

    private StringUtils() {
    }

    /**
     * @param s: the string input
     * @return : the input string is null or empty
     */
    public static boolean isNullOrEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

    /**
     * Fixes the null string with empty space
     *
     * @param s the string input
     * @return output fixed String
     */
    public static String fixNullWithEmpty(String s) {
        return s == null ? "" : s;
    }

    /**
     * Fixes the dashed string inputs such as Account number & Iban and removes dashes
     *
     * @param stringNumber the string input
     * @return output engish format dashed removed string
     */
    public static String fixDashedNumber(String stringNumber) {
        if (!StringUtils.isNullOrEmpty(stringNumber)) {
            return AsciiUtils.asciiPersianNumberToEnglish(stringNumber.replace("-", "")).trim();
        } else {
            return null;
        }
    }

    /**
     * removes commas from string number and fixes ascii characters
     *
     * @param stringNumber the string input
     * @return output string fixed value
     */
    public static String fixStringNumber(String stringNumber) {
        return AsciiUtils.asciiPersianNumberToEnglish(stringNumber.replace(",", "")).replaceAll("[^\\d-]", "").trim();
    }

    /**
     * Validates National Code
     *
     * @param input the input national code
     * @return is correct or not
     */
    public static boolean isValidIranianNationalCode(String input) {
        if (!input.matches("^\\d{10}$"))
            return false;

        int check = Integer.parseInt(input.substring(9, 10));

        int sum = IntStream.range(0, 9)
                .map(x -> Integer.parseInt(input.substring(x, x + 1)) * (10 - x))
                .sum() % 11;

        return (sum < 2 && check == sum) || (sum >= 2 && check + sum == 11);
    }

}