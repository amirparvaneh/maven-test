package com.caspian.ebanking.pars.api.base.security.captcha;

import com.caspian.ebanking.pars.api.base.exception.InvalidCaptchaException;
import com.caspian.ebanking.pars.api.base.persistence.entities.CaptchaManagement;
import com.caspian.ebanking.pars.api.base.persistence.repositories.CaptchaManagementRepository;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.security.dto.enums.CaptchaType;
import com.caspian.ebanking.pars.api.base.utils.StringUtils;
import nl.captcha.Captcha;
import nl.captcha.backgrounds.GradiatedBackgroundProducer;
import nl.captcha.noise.CurvedLineNoiseProducer;
import nl.captcha.text.producer.DefaultTextProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.awt.*;
import java.util.Calendar;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 2:46 PM
 */
@Service
public class SimpleCaptchaVerificationService implements CaptchaVerificationService {

    private static final Logger logger = LoggerFactory.getLogger(SimpleCaptchaVerificationService.class);

    private final CaptchaManagementRepository repository;
    private final CurrentUserService currentUserService;

    @Value("${security.enable-captcha-validator}")
    private boolean enableCaptchaValidation;

    @Autowired
    public SimpleCaptchaVerificationService(CaptchaManagementRepository repository, CurrentUserService currentUserService) {
        this.repository = repository;
        this.currentUserService = currentUserService;
    }

    public void validateLoginCaptcha(String uniqueId, String captcha) throws InvalidCaptchaException {
        if (!enableCaptchaValidation) return;
        logger.info("CaptchaValidationService.validateLoginCaptcha");
        validate(repository.findFirstByUniqueIdOrderByCreatedDesc(uniqueId), captcha);
    }

    public void validateBusinessServiceCaptcha(String captcha) throws InvalidCaptchaException {
        if (!enableCaptchaValidation) return;
        logger.info("CaptchaValidationService.validateBusinessServiceCaptcha");
        String uniqueId = currentUserService.getClientDataControl().getUniqueInfo();
        final CaptchaManagement dbRecord = repository.findFirstByUniqueIdOrderByCreatedDesc(uniqueId);
        validate(dbRecord, captcha);
    }

    public CaptchaManagement persist(String uniqueId, String answer, CaptchaType type) {
        CaptchaManagement dbRecord = new CaptchaManagement();
        dbRecord.setCaptcha(answer);
        dbRecord.setUniqueId(uniqueId);
        dbRecord.setCreated(new Date());
        dbRecord.setType(type.name());

        repository.save(dbRecord);

        return dbRecord;
    }

    public Captcha generateCaptchaImage() {
        final int width = 160;
        final int height = 40;
        return new Captcha.Builder(width, height)
                .addText(new DefaultTextProducer())
                .addBackground(new GradiatedBackgroundProducer(Color.decode("#cecece"), Color.decode("#ececec")))
                .gimp()
                .addNoise(new CurvedLineNoiseProducer(Color.BLACK, 2.0F))
                .addNoise(new CurvedLineNoiseProducer(Color.BLACK, 2.5F))
                .build();

    }

    private void validate(CaptchaManagement dbRecord, String captcha) throws InvalidCaptchaException {
        try {
            if (dbRecord == null || StringUtils.isNullOrEmpty(captcha) || !dbRecord.getCaptcha().equals(captcha))
                throw new InvalidCaptchaException();
        } finally {
            tryDeleteDbRecord(dbRecord);
        }
    }

    private void tryDeleteDbRecord(CaptchaManagement dbRecord) {
        if (dbRecord != null) {
            try {
                repository.delete(dbRecord);
            } catch (Exception e) {
                e.printStackTrace();
                logger.warn(e.getMessage());
            }
        }
    }

    @Scheduled(fixedRate = 60000)
    public void clear() {
        logger.info("Start Clear captcha data");
        long start = System.currentTimeMillis();

        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.MINUTE, -1); //captcha is only valid for a minute
        final Date time = c.getTime();

        repository.deleteAllByCreatedLessThan(time);

        logger.info("Clear captcha data done.Execution Time: " + (System.currentTimeMillis() - start));
    }
}
