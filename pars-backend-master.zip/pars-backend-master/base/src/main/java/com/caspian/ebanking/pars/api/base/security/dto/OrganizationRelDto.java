package com.caspian.ebanking.pars.api.base.security.dto;

import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/19/2020 12:47 AM
 */
@Data
public class OrganizationRelDto {
    private Long organizationId;
    private String organizationName;
    private String departmentId;
}
