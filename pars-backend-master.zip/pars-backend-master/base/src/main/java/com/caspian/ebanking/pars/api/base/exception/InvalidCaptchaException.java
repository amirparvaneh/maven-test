package com.caspian.ebanking.pars.api.base.exception;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 2:49 PM
 */
public class InvalidCaptchaException extends RuntimeException {

    public InvalidCaptchaException() {
        super("Invalid Captcha");
    }
}
