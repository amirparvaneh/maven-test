package com.caspian.ebanking.pars.api.base.persistence.repositories;

import com.caspian.ebanking.pars.api.base.persistence.entities.CaptchaManagement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 11:28 AM
 */
@Transactional
public interface CaptchaManagementRepository extends JpaRepository<CaptchaManagement, Long> {

    CaptchaManagement findFirstByUniqueIdOrderByCreatedDesc(String uniqueId);

    void deleteAllByUniqueId(String uniqueId);

    void deleteAllByCreatedLessThan(Date created);
}
