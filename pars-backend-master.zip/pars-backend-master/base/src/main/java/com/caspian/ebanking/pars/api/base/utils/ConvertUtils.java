package com.caspian.ebanking.pars.api.base.utils;

import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/23/2020 9:50 AM
 */
public final class ConvertUtils {

    private ConvertUtils() {
    }

    public static ClientDataControl convertHeadersToClientDataControl(HttpServletRequest request) {
        ClientDataControl clientDataControl = new ClientDataControl();

        String clientIp = request.getHeader("X-FORWARDED-FOR");
        if (StringUtils.isNullOrEmpty(clientIp)) {
            clientIp = request.getRemoteAddr();
        }

        clientDataControl.setClientIP(clientIp);
        clientDataControl.setRemoteIPAddress(request.getRemoteAddr());
        clientDataControl.setConnectionTimestamp(new Date());
        clientDataControl.setUserAgent(request.getHeader("user-agent"));
//        clientDataControl.setAcceptLanguage(request.getHeader("accept-language"));

        String dnt = request.getHeader("dnt");

        if (!StringUtils.isNullOrEmpty(dnt) && dnt.equals("1")) {
            clientDataControl.setDnt(true);
        } else {
            clientDataControl.setDnt(false);
        }

        String browserMode = request.getParameter("browserMode");
        if (!StringUtils.isNullOrEmpty(browserMode)) {
            clientDataControl.setBrowserMode(browserMode);
        }
        clientDataControl.setCreated(new Date());
        clientDataControl.setLocale(request.getHeader("locale"));

        return clientDataControl;
    }
}
