package com.caspian.ebanking.pars.api.base.utils;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/24/2020 12:39 PM
 */
public final class HttpUtils {

    private HttpUtils() {
    }

    public static boolean isSuccessStatusCode(int statusCode) {
        return statusCode >= 200 && statusCode < 300;
    }
}
