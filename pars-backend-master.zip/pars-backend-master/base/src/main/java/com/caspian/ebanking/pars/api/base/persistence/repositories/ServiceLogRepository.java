package com.caspian.ebanking.pars.api.base.persistence.repositories;

import com.caspian.ebanking.pars.api.base.persistence.entities.ServiceLog;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/23/2020 11:35 AM
 */
public interface ServiceLogRepository extends JpaRepository<ServiceLog, Long> {
}
