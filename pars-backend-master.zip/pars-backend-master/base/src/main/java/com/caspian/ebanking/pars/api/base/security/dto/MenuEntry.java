package com.caspian.ebanking.pars.api.base.security.dto;

import com.caspian.moderngateway.core.domainmodel.dto.menu.MenuEntryDto;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/24/2020 11:59 PM
 */
@Data
public class MenuEntry {
    private Long id;
    private String persianRibbonTitle;
    private List<MenuEntry> children = new ArrayList<>();
}
