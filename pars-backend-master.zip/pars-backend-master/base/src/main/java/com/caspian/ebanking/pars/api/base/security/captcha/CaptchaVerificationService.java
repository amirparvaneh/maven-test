package com.caspian.ebanking.pars.api.base.security.captcha;

import com.caspian.ebanking.pars.api.base.exception.InvalidCaptchaException;
import com.caspian.ebanking.pars.api.base.persistence.entities.CaptchaManagement;
import com.caspian.ebanking.pars.api.base.security.dto.enums.CaptchaType;
import nl.captcha.Captcha;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/26/2020 11:48 AM
 */
public interface CaptchaVerificationService {

    void validateLoginCaptcha(String uniqueId, String captcha) throws InvalidCaptchaException;

    void validateBusinessServiceCaptcha(String captcha) throws InvalidCaptchaException;

    CaptchaManagement persist(String uniqueId, String answer, CaptchaType type);

    Captcha generateCaptchaImage();

}
