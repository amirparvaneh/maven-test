package com.caspian.ebanking.pars.api.base.persistence.entities;

import com.caspian.ebanking.pars.api.base.utils.StringUtils;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/22/2020 10:56 AM
 */
@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
public class ClientDataControl {

    public static final String LOCALE_FA = "FA";
    public static final String LOCALE_EN = "EN";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String customerCode;
    private String username;
    private Long selectedOrganizationId;
    private String selectedDepartmentId;
    private String remoteIPAddress;     // Remote IP address
    private String clientIP;            // Client's IP address
    private String userAgent;           // Client's user agent
    private Date connectionTimestamp;   // Client's connection request timestamp
    private Boolean dnt;                // Client browser DNT(Do Not Track) is active or no
    private String browserMode;         // Client browser mode(Public/Private/undefined)
    private Boolean browserReload;      // Client browser Reload(F5, Back/Forward, close/open, two active tab)
    private Integer requestsNum;
    private Integer failedRequestsNum;
    private Date lastActiveTime;
    private String locale;              //FA for farsi and EN for english
    private String channelSessionId;
    private Date created;
    private Date updated;

    @Transient
    public String getFingerprint() {
        return (StringUtils.fixNullWithEmpty(getClientIP())) + "-" + (StringUtils.fixDashedNumber(getUserAgent())) + "-" + ((getDnt() != null && getDnt()) ? "dnt=true" : "dnt=false") + "-" + (StringUtils.fixNullWithEmpty(browserMode));
    }

    @Transient
    public String getUniqueInfo() {
        return getId() + "-" + getChannelSessionId() + "-" + getCustomerCode();
    }
}
