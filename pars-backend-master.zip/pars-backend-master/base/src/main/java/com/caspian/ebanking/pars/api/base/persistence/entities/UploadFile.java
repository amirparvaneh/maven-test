package com.caspian.ebanking.pars.api.base.persistence.entities;

import com.caspian.ebanking.pars.api.base.utils.StringUtils;
import lombok.*;

import javax.persistence.*;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/22/2020 10:56 AM
 */
@Entity
@Data
@ToString
@NoArgsConstructor
public class UploadFile {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String username;
    private String filePath;
    private String type;

}