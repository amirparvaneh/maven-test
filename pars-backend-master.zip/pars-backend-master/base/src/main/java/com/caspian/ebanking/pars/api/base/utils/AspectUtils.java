package com.caspian.ebanking.pars.api.base.utils;

import org.aspectj.lang.JoinPoint;

import java.util.Arrays;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/23/2020 11:30 AM
 */
public final class AspectUtils {

    private AspectUtils() {
    }

    public static String getMethodNameAndArgs(JoinPoint joinPoint) {
        return getMethodName(joinPoint) + "| Args => " + Arrays.asList(joinPoint.getArgs());
    }

    public static String getMethodName(JoinPoint joinPoint) {
        return joinPoint.getSignature().toShortString();
    }
}
