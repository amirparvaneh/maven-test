package com.caspian.ebanking.pars.api.base.mapper;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/19/2020 1:13 AM
 */
@Configuration
public class ModelMapperConfiguration {

    @Bean
    public ParsModelMapper modelMapper() {
        return new ParsModelMapper();
    }
}
