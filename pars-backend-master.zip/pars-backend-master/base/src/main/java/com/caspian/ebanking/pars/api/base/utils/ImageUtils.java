package com.caspian.ebanking.pars.api.base.utils;

import javax.imageio.ImageIO;
import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 4:51 PM
 */
public final class ImageUtils {

    private ImageUtils() {
    }

    public static String imgToBase64String(final RenderedImage img, final String formatName) {
        String imageString = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            ImageIO.write(img, formatName, bos);
            byte[] imageBytes = bos.toByteArray();

            Base64.Encoder encoder = Base64.getEncoder();
            imageString = encoder.encodeToString(imageBytes);

            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imageString;
    }
}
