package com.caspian.ebanking.pars.api.base.spi;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.exception.ChannelManagerException;
import com.caspian.moderngateway.core.coreservice.dto.ChUserInfoRequestBean;
import com.caspian.moderngateway.core.message.LoginStaticMsg;
import com.caspian.moderngateway.infrastructurespi.common.message.ChMessageHeader;
import com.caspian.moderngateway.spi.service.ChannelManagerProvider;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Mock Class to test Channel Manager Services
 *
 * @author Amir Tajik
 * @version 1.0
 * @since 12/13/2020 3:49 PM
 */
@Service
@Profile("mockAuth")
@ConditionalOnProperty(prefix = "channelManager", name = "provider", havingValue = "Mock")
public class MockChannelManagerProviderImpl implements ParsChannelManagerProvider {

    private static Logger logger = LogManager.getLogger(MockChannelManagerProviderImpl.class);

    private ChannelManagerProvider provider;

    private String channelSessionId;

    @Autowired
    public MockChannelManagerProviderImpl(ChannelManagerProvider provider) {
        this.provider = provider;
    }

    @PostConstruct
    public void init() {
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

        scheduler.schedule(() -> {
            logger.info("********** Initializing Mock Channel Manager Provider ************");
            Map<ChMessageHeader.UserAgent, String> userAgentInfo = new HashMap<>();
            Map<ChMessageHeader.HeaderContext, Object> userDataHeader = new HashMap<>();
            userAgentInfo.put(ChMessageHeader.UserAgent.IDENTIFICATION, "pars2-api");
            userAgentInfo.put(ChMessageHeader.UserAgent.USER_CLIENT_IP, "1.1.1.1");
            userAgentInfo.put(ChMessageHeader.UserAgent.OPERATION_SYSTEM, "windows");
            userAgentInfo.put(ChMessageHeader.UserAgent.USER_CLIENT_SPEC, "mozilla");
            userDataHeader.put(ChMessageHeader.HeaderContext.USER_AGENT, userAgentInfo);

            final ChMessageHeader header = new ChMessageHeader(userDataHeader);

            ChUserInfoRequestBean userInfoRequestBean = new ChUserInfoRequestBean();
            userInfoRequestBean.setUsername("59582537");
            userInfoRequestBean.setPassword("59808748");

            LoginStaticMsg.Inbound inbound = new LoginStaticMsg.Inbound();
            inbound.setChUserInfoRequestBean(userInfoRequestBean);

            LoginStaticMsg.Outbound loginData = null;
            try {
                loginData = execute(header, inbound, LoginStaticMsg.Outbound.class, false);
                this.channelSessionId = loginData.getChLoginResponseBean().getSessionId();
                logger.info("Channel Session ID: " + this.channelSessionId);
            } catch (ChannelManagerException e) {
                e.printStackTrace();
            }
        }, 10, TimeUnit.SECONDS);
    }

    @Override
    public ChannelManagerProvider getChannelManagerProvider() {
        return provider;
    }

    @Override
    public String getChannelSessionId() {
        return channelSessionId;
    }

    @Override
    public ChMessageHeader getChMessageHeaders() {
        return null;
    }
}
