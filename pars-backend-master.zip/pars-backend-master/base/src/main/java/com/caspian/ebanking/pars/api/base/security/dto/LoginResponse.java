package com.caspian.ebanking.pars.api.base.security.dto;

import com.caspian.moderngateway.core.coreservice.dto.ChGender;
import com.caspian.moderngateway.core.domainmodel.dataaccess.dao.valuablecustomer.UserOrganizationRelDao;
import com.caspian.moderngateway.core.domainmodel.dto.menu.MenuDto;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 1:20 PM
 */
@Data
public class LoginResponse {
    private String sessionId;
    private Date lastLoginTime;
    private Long customerNo;
    private ChGender gender;
    private String name;
    private String foreignName;
    private String title;
    private String code;
    private Menu menu;
    private List<UserActivityCode> activities;
    //    private byte[] userProfile;
    private Boolean requiredChangeSecondPassword;
    private Character clientType;
    private long issuedAt;
    private List<OrganizationRelDto> organizations;

}

