package com.caspian.ebanking.pars.api.base.security.dto;

import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 11:09 PM
 */
@Data
public class UserActivityCode {
    private String code;
}
