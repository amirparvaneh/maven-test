package com.caspian.ebanking.pars.api.base.security.interceptor;

import com.caspian.ebanking.pars.api.base.mapper.ParsModelMapper;
import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.utils.ConvertUtils;
import com.caspian.ebanking.pars.api.base.utils.HttpUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/24/2020 12:07 PM
 */
@Component
public class ClientDataControlInterceptor implements HandlerInterceptor {

    @Value("${security.enable-user-data-control}")
    private Boolean enableUserAgentCheck;

    private static final Logger logger = LoggerFactory.getLogger(ClientDataControlInterceptor.class);

    private final CurrentUserService currentUserService;

    @Autowired
    public ClientDataControlInterceptor(CurrentUserService currentUserService, ParsModelMapper mapper) {
        this.currentUserService = currentUserService;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.info("ClientDataControlInterceptor.preHandle");
        logger.info("Request URI: " + request.getRequestURI());

        if (!enableUserAgentCheck) {
            return true;
        }

        ClientDataControl dbRecord = currentUserService.getClientDataControl();
        if (dbRecord != null) {
            logger.info("Database record: " + dbRecord.toString());
        }

        ClientDataControl requestRecord = ConvertUtils.convertHeadersToClientDataControl(request);
        logger.info("Request record: " + requestRecord.toString());

        if (dbRecord == null || !requestRecord.getFingerprint().equals(dbRecord.getFingerprint())) {
            currentUserService.removeAllClientDataControlData();
            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("invalid user agent");
            return false;
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        logger.info("ClientDataControlInterceptor.postHandle");
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        logger.info("ClientDataControlInterceptor.afterCompletion");
        if (HttpUtils.isSuccessStatusCode(response.getStatus())) {
            currentUserService.updateLastSuccessfulActive();
        } else {
            currentUserService.incrementFailedRequestCount();
        }
    }
}
