package com.caspian.ebanking.pars.api.base.security;

import com.caspian.ebanking.pars.api.base.security.dto.LoginResponse;
import com.caspian.ebanking.pars.api.base.security.dto.Menu;
import com.caspian.ebanking.pars.api.base.security.dto.MenuEntry;
import com.caspian.ebanking.pars.api.base.utils.CollectionUtils;
import com.caspian.ebanking.pars.api.base.utils.StringUtils;
import io.jsonwebtoken.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 11:40 PM
 */
@Service
@PropertySource("classpath:security.properties")
public class JwtTokenProvider {

    @Value("${security.jwt.token.expire-length}")
    private long validityInMilliseconds;

    @Value("${security.jwt.token.jks-password}")
    private String storePassword;

    @Value("${security.jwt.token.issuer}")
    private String issuer;

    private Key key;

    @PostConstruct
    protected void init() throws KeyStoreException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, CertificateException {
        KeyStore ks = KeyStore.getInstance("JKS");
        ks.load(getClass().getClassLoader().getResourceAsStream("pars-jwt-keystore.jks"), storePassword.toCharArray());
        key = ks.getKey("selfsigned", storePassword.toCharArray());
    }

    public String createToken(String username, LoginResponse loginResponse) {

        Claims claims = Jwts.claims().setSubject(username);
        claims.put("cno", loginResponse.getCustomerNo());
        claims.put("persian_name", loginResponse.getName());
        claims.put("foreign_name", loginResponse.getForeignName());
        claims.put("third_party_session_id", loginResponse.getSessionId());
        claims.put("last_login_date", loginResponse.getLastLoginTime());
        claims.put("authorities", getAuthorities(loginResponse.getMenu()));

        Date validity = new Date(loginResponse.getIssuedAt() + validityInMilliseconds);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuer(issuer)
                .setIssuedAt(new Date(loginResponse.getIssuedAt()))
                .setExpiration(validity)
                .signWith(SignatureAlgorithm.RS512, key)
                .compact();
    }

    private String getAuthorities(Menu menu) {
        if (menu == null || CollectionUtils.isNullOrEmpty(menu.getMenuEntries()))
            return "";

        List<MenuEntry> flattenMenuEntries = new ArrayList<>();
        fillFlattenMenuEntries(menu.getMenuEntries(), flattenMenuEntries);
        return flattenMenuEntries.stream().map(MenuEntry::getPersianRibbonTitle).collect(Collectors.joining(","));
    }

    private void fillFlattenMenuEntries(List<MenuEntry> entries, List<MenuEntry> result) {
        if (CollectionUtils.isNullOrEmpty(entries)) return;

        result.addAll(entries);
        for (MenuEntry item : entries) {
            if (!CollectionUtils.isNullOrEmpty(item.getChildren()))
                fillFlattenMenuEntries(item.getChildren(), result);
        }
    }


    public Optional<Authentication> createAuthentication(Jws<Claims> jwsClaims) {
        if (jwsClaims == null) {
            return Optional.empty();
        }

        Claims claims = jwsClaims.getBody();

        String scopesString = claims.get("authorities").toString();
        String[] authStrings = scopesString.split(",");

        Collection<? extends GrantedAuthority> authorities =
                Arrays.stream(authStrings)
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());

        String subject = claims.getSubject();
        User principal = new User(subject, "", authorities);

        final UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(principal, "", authorities);
        usernamePasswordAuthenticationToken.setDetails(jwsClaims);

        return Optional.of(usernamePasswordAuthenticationToken);
    }


    public String resolveToken(HttpServletRequest req) {
        String bearerToken = req.getHeader("Authorization");
        if (!StringUtils.isNullOrEmpty(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }

    public Jws<Claims> validateAndParseClaims(String token) {
        try {
            return Jwts.parser().setSigningKey(key).parseClaimsJws(token);
        } catch (JwtException | IllegalArgumentException e) {
            throw new AccessDeniedException("invalid token");
        }
    }
}
