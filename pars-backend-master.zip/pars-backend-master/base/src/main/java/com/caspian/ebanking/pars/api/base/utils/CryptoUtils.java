package com.caspian.ebanking.pars.api.base.utils;

import lombok.SneakyThrows;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 4:17 PM
 */
public final class CryptoUtils {

    @SneakyThrows
    public static String hashSHA256(String s) {
        if (StringUtils.isNullOrEmpty(s))
            throw new IllegalArgumentException();
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(s.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(hash);
    }
}
