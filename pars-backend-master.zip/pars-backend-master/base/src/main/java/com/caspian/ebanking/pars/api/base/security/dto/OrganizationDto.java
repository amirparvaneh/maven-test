package com.caspian.ebanking.pars.api.base.security.dto;

import lombok.Data;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/28/2020 12:47 PM
 */
@Data
public class OrganizationDto {
    private String channelUserId;
    private Long organizationId;
    private String organizationName;
    private String departmentId;
    private Character organizationStatus;
    private Character memberOfBoard;
}
