package com.caspian.ebanking.pars.api.base.spi;

import com.caspian.moderngateway.infrastructurespi.common.message.ChMessageHeader;
import com.caspian.moderngateway.spi.service.ChannelManagerProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * Main Channel Manager Provider
 * This Provider is Session based and works with the current user SessionId
 *
 * @author Amir Tajik
 * @version 1.0
 * @since 12/17/2020 10:29 PM
 */
@Service
@Profile("sessionAuth")
@ConditionalOnProperty(prefix = "channelManager", name = "provider", havingValue = "Session")
public class SessionBasedChannelManagerProvider implements ParsChannelManagerProvider {

    //TODO
    private ChannelManagerProvider provider;

    @Override
    public String getChannelSessionId() {
        return null;
    }

    @Override
    public ChannelManagerProvider getChannelManagerProvider() {
        return null;
    }

    @Override
    public ChMessageHeader getChMessageHeaders() {
        return null;
    }
}
