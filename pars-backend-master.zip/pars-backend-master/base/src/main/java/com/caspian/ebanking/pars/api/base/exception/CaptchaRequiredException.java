package com.caspian.ebanking.pars.api.base.exception;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/24/2020 1:59 PM
 */
public class CaptchaRequiredException extends BadRequestException {
    public CaptchaRequiredException(String message) {
        super(message);
    }
}
