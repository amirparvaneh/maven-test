package com.caspian.ebanking.pars.api.base.spi;

import com.caspian.ebanking.pars.api.base.security.CurrentUserService;
import com.caspian.ebanking.pars.api.base.security.JwtCurrentUserService;
import com.caspian.ebanking.pars.api.base.utils.ChannelUtils;
import com.caspian.moderngateway.infrastructurespi.common.message.ChMessageHeader;
import com.caspian.moderngateway.spi.service.ChannelManagerProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 2:39 PM
 */
@Service
@Profile("jwtAuth")
@ConditionalOnProperty(prefix = "channelManager", name = "provider", havingValue = "JWT", matchIfMissing = true)
public class JwtBasedChannelManagerProvider implements ParsChannelManagerProvider {

    private ChannelManagerProvider provider;
    private CurrentUserService currentUserService;

    @Autowired
    public JwtBasedChannelManagerProvider(ChannelManagerProvider provider, JwtCurrentUserService currentUserService) {
        this.provider = provider;
        this.currentUserService = currentUserService;
    }

    @Override
    public String getChannelSessionId() {
        return currentUserService.getChannelSessionId();
    }

    @Override
    public ChannelManagerProvider getChannelManagerProvider() {
        return provider;
    }

    @Override
    public ChMessageHeader getChMessageHeaders() {
        return ChannelUtils.convertClientDataControlToChMessageHeader(currentUserService.getClientDataControl());
    }
}
