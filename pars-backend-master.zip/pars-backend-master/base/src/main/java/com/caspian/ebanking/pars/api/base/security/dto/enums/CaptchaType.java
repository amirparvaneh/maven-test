package com.caspian.ebanking.pars.api.base.security.dto.enums;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 12:36 PM
 */
public enum CaptchaType {
    LOGIN, VERIFICATION
}
