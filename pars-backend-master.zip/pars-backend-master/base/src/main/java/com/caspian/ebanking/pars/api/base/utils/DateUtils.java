package com.caspian.ebanking.pars.api.base.utils;

import com.caspian.moderngateway.core.channelmanagerinfrastructure.util.calendar.CalendarUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/29/2020 11:46 AM
 */
public final class DateUtils {

    private static final Logger logger = LoggerFactory.getLogger(DateUtils.class);

    private DateUtils() {
    }

    /**
     * method from old webbank which should be deleted or changed later
     *
     * @param date input date
     * @param hour hour of day in 24-h format
     * @param min  minute
     * @param sec  second
     * @return date in gregorian
     */
    public static Date getTimeValue(Date date, int hour, int min, int sec) {
        Calendar calendar = GregorianCalendar.getInstance();
        if (date != null) {
            calendar.setTime(date);
            calendar.set(Calendar.SECOND, sec);
            calendar.set(Calendar.MINUTE, min);
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            return calendar.getTime();
        }
        return null;
    }

    /**
     * method from old webbank which should be deleted or changed later
     *
     * @param date     input date
     * @param dateTime dateTime in string (HH:mm:ss)
     * @return date in gregorian
     */
    public static Date getTimeValue(Date date, String dateTime) {
        if (dateTime != null && !dateTime.equals("") && dateTime.matches("^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$")) {
            Date today = GregorianCalendar.getInstance().getTime();
            Calendar gCal = GregorianCalendar.getInstance();
            gCal.setTime((date != null) ? date : CalendarUtil.resetTime(today));
            try {
                Integer sec = Integer.parseInt(dateTime.substring(6, 8));
                Integer min = Integer.parseInt(dateTime.substring(3, 5));
                Integer hour = Integer.parseInt(dateTime.substring(0, 2));
                return DateUtils.getTimeValue(gCal.getTime(), hour, min, sec);
            } catch (NumberFormatException e) {
                logger.error(e.getMessage());
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * Converts an instance of <code>java.util.Date</code> into a String
     * delimited by <code>delimiter</code>
     *
     * @param date      the date
     * @param delimiter the delimiter
     * @return the string representing the given date
     */
    public static String convertString(Date date, String delimiter) {
        if (date == null || delimiter == null || delimiter.isEmpty()) {
            return null;
        }
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        StringBuilder builder = new StringBuilder();
        builder.append(calendar.get(GregorianCalendar.YEAR));
        builder.append(delimiter);
        builder.append(calendar.get(GregorianCalendar.MONTH) + 1);
        builder.append(delimiter);
        builder.append(calendar.get(GregorianCalendar.DAY_OF_MONTH));
        return builder.toString();
    }

    public static String getJalaliDate(Date date) {
        if (date == null)
            return "";
        com.casp.util.calendar.JalaliDate jalaliDate = new com.casp.util.calendar.CalendarUtil().getJalaliDate(date);
        return String.format("%4d/%02d/%02d", jalaliDate.getjYear(), jalaliDate.getjMonth(), jalaliDate.getjDay());
    }

    public static String getJalaliTime(Date date) {
        Calendar calendar = GregorianCalendar.getInstance();
        if (date != null) {
            calendar.setTime(date);
            return String.format("%02d", calendar.get(Calendar.HOUR_OF_DAY)) + ":" + String.format("%02d", calendar.get(Calendar.MINUTE)) + ":" + String.format("%02d", calendar.get(Calendar.SECOND));
        }
        return "";
    }

    public static String getTime(Date date) {
        Calendar calendar = GregorianCalendar.getInstance();
        if (date != null) {
            calendar.setTime(date);
            return String.format("%02d", calendar.get(Calendar.HOUR_OF_DAY)) + ":" + String.format("%02d", calendar.get(Calendar.MINUTE)) + ":" + String.format("%02d", calendar.get(Calendar.SECOND));
        }
        return "";
    }

    public static String getJalaliDateTime(Date date) {
        return DateUtils.getJalaliDate(date) + " " + DateUtils.getJalaliTime(date);
    }

    public static String getDateString(String languageCode, String criteriaItem) {
        String dateField = "";
        if (criteriaItem != null && criteriaItem.length() > 0) {
            if (languageCode.toLowerCase().equals("fa_ir")) {
                dateField = DateUtils.getJalaliDate(new Date(Long.parseLong(criteriaItem)));
            } else {
                Date date = new Date(Long.parseLong(criteriaItem));
                Calendar cal = new GregorianCalendar();
                cal.setTime(date);
                dateField = String.format("%4d/%02d/%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
            }
        }
        return dateField;
    }

    public static String getDateTimeString(String languageCode, String criteriaItem) {
        if (criteriaItem != null && criteriaItem.length() > 0) {
            String dateField;
            String timeField;
            if (languageCode.toLowerCase().equals("fa_ir")) {
                dateField = DateUtils.getJalaliDate(new Date(Long.parseLong(criteriaItem)));
                timeField = DateUtils.getJalaliTime(new Date(Long.parseLong(criteriaItem)));
            } else {
                Date date = new Date(Long.parseLong(criteriaItem));
                Calendar cal = new GregorianCalendar();
                cal.setTime(date);
                dateField = String.format("%4d/%02d/%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
                timeField = DateUtils.getJalaliTime(new Date(Long.parseLong(criteriaItem)));
            }
            return dateField + " " + timeField;
        }
        return "";
    }

    public static long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
        long diffInMillis = date2.getTime() - date1.getTime();
        return timeUnit.convert(diffInMillis, TimeUnit.MILLISECONDS);
    }

    public static Date getFromDate(Date fromDate) {
        return getTimeValue(fromDate, 0, 0, 0);
    }

    public static Date getToDate(Date toDate) {
        final Date dt = getTimeValue(toDate, 0, 0, 0);
        if (dt != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(dt);
            c.add(Calendar.DAY_OF_YEAR, 1);
            return c.getTime();
        }
        return null;
    }
}
