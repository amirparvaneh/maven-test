package com.caspian.ebanking.pars.api.base.exception;

import org.apache.http.HttpStatus;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 12:56 PM
 */
public class GatewayException extends RuntimeException {
    private static final long serialVersionUID = -2184035088835645583L;

    private int status;

    private GatewayException(int status, Throwable cause) {
        super(cause);
        this.status = status;
    }

    public GatewayException(Throwable cause) {
        this(HttpStatus.SC_BAD_REQUEST, cause);
    }

    public GatewayException() {
        this(HttpStatus.SC_BAD_REQUEST, null);
    }

    public int getStatus() {
        return status;
    }
}
