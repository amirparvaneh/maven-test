package com.caspian.ebanking.pars.api.base.utils;

import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import com.caspian.moderngateway.infrastructurespi.common.message.ChMessageHeader;

import java.util.HashMap;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/23/2020 12:14 AM
 */
public final class ChannelUtils {

    private ChannelUtils() {
    }

    public static ChMessageHeader convertClientDataControlToChMessageHeader(ClientDataControl dataControl) {
        HashMap<ChMessageHeader.UserAgent, String> userAgentInfo = new HashMap<>();
        HashMap<ChMessageHeader.HeaderContext, Object> userDataHeader = new HashMap<>();
        userAgentInfo.put(ChMessageHeader.UserAgent.IDENTIFICATION, dataControl.getClientIP());
        userAgentInfo.put(ChMessageHeader.UserAgent.USER_CLIENT_IP, dataControl.getClientIP());

        String os = "UNDEFINED";
        if (dataControl.getUserAgent().contains("(") && dataControl.getUserAgent().contains(")")) {
            os = dataControl.getUserAgent().substring(dataControl.getUserAgent().indexOf("(") + 1, dataControl.getUserAgent().indexOf(")"));
        }
        userAgentInfo.put(ChMessageHeader.UserAgent.OPERATION_SYSTEM, os);

        userAgentInfo.put(ChMessageHeader.UserAgent.USER_CLIENT_SPEC, dataControl.getFingerprint().length() < 255 ? dataControl.getFingerprint() : dataControl.getFingerprint().substring(0, 254));
        userDataHeader.put(ChMessageHeader.HeaderContext.USER_AGENT, userAgentInfo);
        return new ChMessageHeader(userDataHeader);
    }
}
