package com.caspian.ebanking.pars.api.base.persistence.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 11:26 AM
 */
@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
public class CaptchaManagement {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String uniqueId;
    private String captcha;
    private String type;
    private Date created;
}
