package com.caspian.ebanking.pars.api.base.security.dto;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/25/2020 12:00 AM
 */
@Data
public class Menu {
    private Long id;
    private Integer version;
    private String bankCode;
    private String channel;
    private List<MenuEntry> menuEntries = new ArrayList<>();
}
