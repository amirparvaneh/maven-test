package com.caspian.ebanking.pars.api.base.utils;

import java.math.BigDecimal;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/17/2020 10:56 PM
 */
public final class AsciiUtils {

    private AsciiUtils() {
    }

    /**
     * @param number the input persian number in string
     * @return english format number
     */
    public static String asciiPersianNumberToEnglish(String number) {
        if (number == null || number.isEmpty())
            return number;
        char[] chars = new char[number.length()];
        for (int i = 0; i < number.length(); i++) {
            char ch = number.charAt(i);
            if (ch >= 0x0660 && ch <= 0x0669)
                ch -= 0x0660 - '0';
            else if (ch >= 0x06f0 && ch <= 0x06F9)
                ch -= 0x06f0 - '0';
            chars[i] = ch;
        }
        return new String(chars);
    }

    /**
     * @param s : the number string input
     * @return same as {{{@link #asciiPersianNumberToEnglish(String)}}} converted to big decimal
     */
    public static BigDecimal convertAsciiPersianNumberToBigDecimal(String s) {
        return new BigDecimal(asciiPersianNumberToEnglish(s));
    }
}
