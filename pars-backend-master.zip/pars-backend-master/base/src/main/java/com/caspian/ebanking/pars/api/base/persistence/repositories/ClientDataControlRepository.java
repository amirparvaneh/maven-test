package com.caspian.ebanking.pars.api.base.persistence.repositories;


import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/22/2020 10:57 AM
 */
@Transactional
public interface ClientDataControlRepository extends JpaRepository<ClientDataControl, Long> {
    ClientDataControl findByCustomerCode(String customerCode);

    List<ClientDataControl> getAllByCustomerCode(String customerCode);

    ClientDataControl findFirstByCustomerCodeOrderByCreatedDesc(String customerCode);

    void deleteAllByCustomerCode(String customerCode);

    void deleteByLastActiveTimeLessThan(Date lastActiveTimeLessThan);
}