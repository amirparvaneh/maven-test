package com.caspian.ebanking.pars.api.base.security;

import com.caspian.ebanking.pars.api.base.persistence.entities.ClientDataControl;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 11:45 PM
 */
public interface CurrentUserService {
    String getChannelSessionId();

    String getUsername();

    String getCustomerCode();

    Long getTokenIssuedAt();

    ClientDataControl setCurrentOrganization(Long organizationId, String departmentId);

    Long getCurrentOrganizationId();

    String getCurrentDepartmentId();

    ClientDataControl getClientDataControl();

    ClientDataControl updateLastSuccessfulActive();

    void removeAllClientDataControlData();

    ClientDataControl incrementFailedRequestCount();

    default String getBriefInfo() {
        return "Customer Code: " + getCustomerCode() + ", Username: " + getUsername() + ", Token Issued at:" + getTokenIssuedAt() + ", Channel Session Id: " + getChannelSessionId();
    }
}
