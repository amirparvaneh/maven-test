package com.caspian.ebanking.pars.api.base.exception;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/31/2020 9:22 AM
 */
public class BadRequestException extends RuntimeException {

    private static final long serialVersionUID = 3094792376727854787L;

    public BadRequestException() {
    }

    public BadRequestException(String message) {
        super(message);
    }

    public BadRequestException(String message, Throwable cause) {
        super(message, cause);
    }

    public BadRequestException(Throwable cause) {
        super(cause);
    }

    public BadRequestException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
