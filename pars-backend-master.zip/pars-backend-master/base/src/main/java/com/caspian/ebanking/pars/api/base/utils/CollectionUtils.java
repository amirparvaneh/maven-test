package com.caspian.ebanking.pars.api.base.utils;

import java.util.Collection;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/22/2020 12:58 AM
 */
public final class CollectionUtils {

    private CollectionUtils() {
    }

    /**
     * checks if a collection is null or empty
     *
     * @param c input collection
     * @return true if the collection is null or empty
     */
    public static boolean isNullOrEmpty(Collection c) {
        return c == null || c.isEmpty();
    }

    /**
     * distinct a collection by a parameter
     *
     * @param keyExtractor parameter
     * @return result list
     */
    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }
}
