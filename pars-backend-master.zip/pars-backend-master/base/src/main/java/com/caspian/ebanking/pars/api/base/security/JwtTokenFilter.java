package com.caspian.ebanking.pars.api.base.security;

import com.caspian.ebanking.pars.api.base.utils.StringUtils;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.Optional;

/**
 * @author Amir Tajik
 * @version 1.0
 * @since 12/18/2020 11:40 PM
 */
@Component
public class JwtTokenFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtTokenFilter.class);

    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    public JwtTokenFilter(JwtTokenProvider jwtTokenProvider) {
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Override
    protected void doFilterInternal(@NotNull HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        logger.info("JWT Filter: " + httpServletRequest.getRequestURI());

        String token = jwtTokenProvider.resolveToken(httpServletRequest);

        if (!StringUtils.isNullOrEmpty(token)) {
            final Jws<Claims> claims = jwtTokenProvider.validateAndParseClaims(token);
            final Optional<Authentication> authentication = jwtTokenProvider.createAuthentication(claims);
            authentication.ifPresent(auth -> SecurityContextHolder.getContext().setAuthentication(auth));
        }

        filterChain.doFilter(httpServletRequest, httpServletResponse);
    }
}
