package com.caspco.cobalt.gateway.authorizationgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
