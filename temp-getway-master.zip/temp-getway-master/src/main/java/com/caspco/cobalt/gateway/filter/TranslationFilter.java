package com.caspco.cobalt.gateway.filter;

import static com.caspco.cobalt.gateway.config.ConstantsValue.APPLICATION_JSON;
import static com.caspco.cobalt.gateway.config.ConstantsValue.CONTENT_TYPE;
import static com.caspco.cobalt.gateway.config.ConstantsValue.LOG_MODEL;

import com.caspco.cobalt.gateway.exceptions.ApiManagerException;
import com.caspco.cobalt.gateway.exceptions.TranslatableException;
import com.caspco.cobalt.gateway.service.TranslatorService;
import com.caspco.cobalt.gateway.util.JwtService;
import com.caspco.cobalt.gateway.util.Util;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import org.apache.http.HttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;


@Component
public class TranslationFilter extends ZuulFilter {

  private static Logger LOGGER = LoggerFactory.getLogger(TranslationFilter.class);
  @Autowired
  private Util util;
  @Autowired
  private Environment env;
  @Autowired
  @Qualifier(value = "securedMapper")
  private ObjectMapper securedMapper;
  @Autowired
  private TranslatorService translatorService;
   @Autowired
   private JwtService jwtService;
   @Autowired
   private LoggerService loggerService;


  @Override
  public String filterType() {
    return "post";
  }

  @Override
  public int filterOrder() {
    return 1;
  }

  @Override
  public boolean shouldFilter() {
    RequestContext ctx = RequestContext.getCurrentContext();
    return (ctx.get(LOG_MODEL) == null);
  }

  @Override
  public Object run() throws ZuulException {
    final RequestContext ctx = RequestContext.getCurrentContext();
    LOGGER.info("Starting Translation filter run method { }");
    HttpResponse response = (HttpResponse) ctx.get("zuulResponse");
    HttpServletRequest request = ctx.getRequest();

    if (response.getHeaders(CONTENT_TYPE).length == 0 || !response.getHeaders(CONTENT_TYPE)[0]
        .getValue().contains(APPLICATION_JSON)) {

      String errorCause = response.getStatusLine().getReasonPhrase();
      int errorCode = response.getStatusLine().getStatusCode();
      String message = response.toString();

      throw new ApiManagerException(message, errorCode, errorCause);
    }

    try {
      loggerService.persistLogModel(request,ctx,null,false);
    } catch (IOException e) {
      throw new TranslatableException(e, -100, e.getClass().getName());
    }
    return null;
  }

}
