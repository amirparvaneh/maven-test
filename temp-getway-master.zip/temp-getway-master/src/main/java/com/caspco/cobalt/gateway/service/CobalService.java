package com.caspco.cobalt.gateway.service;


import com.caspco.cobalt.gateway.exceptions.JwtParsException;
import com.caspco.cobalt.gateway.exceptions.OauthApiException;
import com.caspco.cobalt.gateway.exceptions.TokenException;
import com.caspco.cobalt.gateway.util.JwtService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CobalService {

  private static Logger log = LoggerFactory.getLogger(CobalService.class);
  private static ObjectMapper mapper = new ObjectMapper();
  @Autowired
  private OauthService oauthService;
  @Autowired
  private JwtService jwtService;


  public Object createResponseObject(Class type)
      throws JwtParsException, OauthApiException, TokenException {

      Object tokenObjectFromOAuth = exchangeTokenWithOAuth();
      return mapper.convertValue(tokenObjectFromOAuth, type);

  }


  private Object exchangeTokenWithOAuth() throws OauthApiException, JwtParsException, TokenException {
      return
          oauthService
              .getTokenFromOauth();
  }

}

