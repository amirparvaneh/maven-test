package com.caspco.cobalt.gateway.service;


import com.caspco.cobalt.gateway.filter.LoggerService;
import com.caspco.cobalt.gateway.filter.TranslationFilter;
import com.caspco.cobalt.gateway.model.ExceptionModel;
import com.caspco.cobalt.gateway.exceptions.ApiManagerException;
import com.caspco.cobalt.gateway.exceptions.JwtParsException;
import com.caspco.cobalt.gateway.exceptions.TranslatableException;
import com.caspco.cobalt.gateway.util.JwtService;
import com.caspco.cobalt.gateway.util.Util;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.servlet.error.AbstractErrorController;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.lang.reflect.UndeclaredThrowableException;
import javax.servlet.http.HttpServletRequest;

@RestController
public class ZuulErrorController extends AbstractErrorController {


  @Value("${error.path:/error}")
  private String errorPath;
  @Autowired
  private Util util;
  @Autowired
  private TranslatorService translatorService;
  @Autowired
  @Qualifier(value = "securedMapper")
  private ObjectMapper securedMapper;
  @Autowired
  private JwtService jwtService;
  @Autowired
  LoggerService loggerService;
  private static Logger LOGGER = LoggerFactory.getLogger(TranslationFilter.class);


  public ZuulErrorController(ErrorAttributes errorAttributes) {
    super(errorAttributes);
  }

  @Override
  public String getErrorPath() {
    return errorPath;
  }

  @RequestMapping(value = "${error.path:/error}", produces = "application/json;charset=UTF-8")
  public ResponseEntity error(HttpServletRequest request) throws IOException, JwtParsException {

    final RequestContext ctx = RequestContext.getCurrentContext();

    LOGGER.info("Starting error method {}");

    /** create exceptionModel*/

    Exception exceptionType = getErrorCause(request);
    String errorMessage = getErrorMessage(request);
    HttpStatus status = getStatus(request);
    int actualStatusCode = status.value();
    if (exceptionType instanceof TranslatableException) {
      actualStatusCode = ((TranslatableException) exceptionType).nStatusCode;
    }
    ExceptionModel exceptionModel =
        translatorService
            .createTranslatedExceptionModel(errorMessage, actualStatusCode, exceptionType);

    /** create and fill a logModel */
    loggerService.persistLogModel(request, ctx, exceptionModel,true);

    return ResponseEntity.status(status).body(createExceptionResponseBody(exceptionType,actualStatusCode));
  }

  private ExceptionModel createExceptionResponseBody(Exception exceptionType,int statusCode){
    ExceptionModel model;
    if(exceptionType instanceof ApiManagerException){  //  answer is html and not json
      model=  translatorService
          .createTranslatedExceptionModel("", ((ApiManagerException) exceptionType).nStatusCode, exceptionType);
    }else if(exceptionType instanceof TranslatableException){
      model=  translatorService
          .createTranslatedExceptionModel(exceptionType.getMessage(), ((TranslatableException) exceptionType).nStatusCode, exceptionType);
    } else {
      model=  translatorService
          .createTranslatedExceptionModel(exceptionType.getMessage(), statusCode, exceptionType);

    }
    return  model;
  }

  private String getErrorMessage(HttpServletRequest request) {
    final ZuulException exc = (ZuulException) request.getAttribute("javax.servlet.error.exception");
    if(exc != null){
      if(exc.getCause() != null){
        if(exc.getCause() instanceof UndeclaredThrowableException)  {
          return exc.getCause().getCause().getMessage() ;
        }
        return exc.getCause().getMessage() ;  // handled exceptions .
      }
      return  exc.getMessage() ;  // unhandled exceptions which zuul handled.
    }
    return "Unexpected error occurred" ;
  }

  private Exception getErrorCause(HttpServletRequest request) {
    final ZuulException exc = (ZuulException) request.getAttribute("javax.servlet.error.exception");
    //TODO exc can be null when the request don't match any patterns
    if(exc.getCause() != null){
      if(exc.getCause() instanceof UndeclaredThrowableException)  {
        return (Exception) exc.getCause().getCause();
      }
    }
    return exc.getCause() != null ?  (Exception) exc.getCause() : exc;
  }

}
