package com.caspco.cobalt.gateway.logging;


import com.caspco.cobalt.gateway.model.LogModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.List;


@Service
public class LoggerProxy {
    private final List<AbstractLogger> loggers;
    StopWatch stopWatch = new StopWatch();

    @Autowired
    public LoggerProxy(final List<AbstractLogger> loggers) {
        this.loggers = loggers;
    }

    //@Async()
    public void log(final LogModel logRequest) {

        stopWatch.start();
        loggers.stream().forEach(logger -> {
            try {
                logger.log(logRequest);
            } catch (JsonProcessingException e) {
                System.err.println(e);
            } catch (Throwable e) {
                e.printStackTrace();
            }
        });
        stopWatch.stop();
        System.err.println("logger Time:" + stopWatch.getLastTaskTimeMillis() + " ms");
    }
}

