package com.caspco.cobalt.gateway.exceptions;


public class JwtParsException extends TranslatableException {

  public static final int N_STATUS_CODE =501;
  public static final String ERROR_CAUSE ="JwtParsException Exception !!!";

  public JwtParsException(String sMessage) {
    super(sMessage, N_STATUS_CODE, ERROR_CAUSE);
  }

  public JwtParsException(Throwable throwable) {
    super(throwable, N_STATUS_CODE, ERROR_CAUSE);
  }


  @Override
  public String toString() {
    return "JwtParsException{" +
        "nStatusCode=" + N_STATUS_CODE +
        ", errorCause='" + ERROR_CAUSE + '\'' +
        '}';
  }
}
