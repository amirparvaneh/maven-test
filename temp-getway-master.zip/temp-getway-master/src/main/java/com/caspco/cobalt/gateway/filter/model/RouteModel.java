package com.caspco.cobalt.gateway.filter.model;

import java.util.Set;


public class RouteModel {
  private String name;
  private String targetUrl;
  private Set<String> sensitiveHeaders;

  public RouteModel() {
  }

  public String getTargetUrl() {
    return targetUrl;
  }

  public void setTargetUrl(String targetUrl) {
    this.targetUrl = targetUrl;
  }

  public Set<String> getSensitiveHeaders() {
    return sensitiveHeaders;
  }

  public void setSensitiveHeaders(Set<String> sensitiveHeaders) {
    this.sensitiveHeaders = sensitiveHeaders;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}

