package com.caspco.cobalt.gateway.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class LogService {
  private static final org.slf4j.Logger mongoLogger= LoggerFactory.getLogger("mongoLogger");

  @Autowired
  @Qualifier(value = "securedMapper")
  private ObjectMapper securedMapper;


  public void persistLog(Object logObject) throws IOException {
    //mongoLogger.debug(securedMapper.writeValueAsString(logObject));
  }

}
