package com.caspco.cobalt.gateway.filter;//package com.caspco.cobalt.gateway.filter;
//
//import com.caspco.cobalt.gateway.thirdparty.config.ConstantsValue;
//import com.caspco.cobalt.gateway.thirdparty.exceptions.TranslatableException;
//import com.caspco.cobalt.gateway.thirdparty.logging.LoggerProxy;
//import com.caspco.cobalt.gateway.thirdparty.model.LogModel;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.netflix.zuul.ZuulFilter;
//import com.netflix.zuul.context.RequestContext;
//import com.netflix.zuul.exception.ZuulException;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.stereotype.Component;
//
////@Component
//public class LogFilter extends ZuulFilter {
//
//  @Autowired
//  @Qualifier(value = "securedMapper")
//  private ObjectMapper securedMapper;
//
//  private static final org.slf4j.Logger logger = LoggerFactory.getLogger(LogFilter.class);
//
//  @Autowired
//  private LoggerProxy loggerProxy;
//
//  @Override
//  public String filterType() {
//    return "post";
//  }
//
//  @Override
//  public int filterOrder() {
//
//    return 2;
//  }
//
//  @Override
//  public boolean shouldFilter() {
//    return false;
//  }
//
//  @Override
//  public Object run() throws ZuulException {
//    logger.info("Starting log filter ");
//
//    //get LogModel object from before filter
//    RequestContext ctx = RequestContext.getCurrentContext();
//    LogModel logModel = (LogModel) ctx.get(ConstantsValue.LOG_MODEL);
//    loggerProxy.log(logModel);
//    if(logModel.getHasException()){
//      try {
//        ctx.setResponseBody(securedMapper.writeValueAsString(logModel.getExceptionModel()));
//      } catch (JsonProcessingException e) {
//        throw new TranslatableException(e,e.getMessage(),-5,e.getOriginalMessage())  ;
//      }
//
//    }
//    return null;
//  }
//}
//
