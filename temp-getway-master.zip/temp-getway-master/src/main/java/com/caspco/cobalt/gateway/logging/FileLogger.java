package com.caspco.cobalt.gateway.logging;


import com.caspco.cobalt.gateway.model.LogModel;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.IOException;


@ConditionalOnProperty(name = "log.file.enable", havingValue = "true", matchIfMissing = false)
@Service
public class FileLogger implements AbstractLogger {
    private static final org.slf4j.Logger fileLogger = LoggerFactory.getLogger("fileLogger");

    @Override
    @Async
    public void log(final LogModel logRequest) throws IOException {
        fileLogger.debug(objectMapper.writeValueAsString(logRequest));
    }
}

