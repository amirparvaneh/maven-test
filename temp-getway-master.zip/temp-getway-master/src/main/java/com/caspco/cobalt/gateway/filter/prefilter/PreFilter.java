package com.caspco.cobalt.gateway.filter.prefilter;


import com.caspco.cobalt.gateway.exceptions.InvalidServiceException;
import com.caspco.cobalt.gateway.filter.model.PreProcessor;
import com.caspco.cobalt.gateway.filter.model.RouteModel;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import org.apache.commons.fileupload.util.Streams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.netflix.zuul.filters.ZuulProperties.ZuulRoute;
import org.springframework.cloud.netflix.zuul.filters.discovery.DiscoveryClientRouteLocator;
import org.springframework.context.ApplicationContext;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class PreFilter extends ZuulFilter {

  @Value("${spring.profiles.active:dev}")
  private String activeProfile;
  @Autowired
  DiscoveryClientRouteLocator routeLocator;
  private Map<String, PreProcessor> modelMap;
  @Autowired
  private ApplicationContext context;

  @PostConstruct
  public void init() throws IOException {
    final InputStream resource = "local".equals(activeProfile) ? this.getClass().getClassLoader()
                                                                   .getResourceAsStream("config.json")
      : new FileSystemResource("./config.json").getInputStream();
    assert resource != null;
    final String s = Streams.asString(Objects.<InputStream>requireNonNull(resource));

    modelMap = new ObjectMapper()
      .readValue(s, new TypeReference<Map<String, PreProcessor>>() {
      });
    if(modelMap != null && modelMap.size()>0){
      modelMap.forEach((k, v) -> {
        try {
          v.setPreProcessorBean(
              (HeaderPreProcessor) context.getBean(Class.forName(v.getPreProcessor())));
        } catch (ClassNotFoundException e) {
          throw new RuntimeException();
        }
        setRoute(v.getPath(), v.getRouteModel());
        //v.setPathRegex(convertToRegex(k));
      });
      System.err.println("Config file is loaded from " + ("dev".equals(activeProfile) ?
                                                              "classpath:config.json"
                                                              : new FileSystemResource("./config.json").getFile()
                                                                                                       .getAbsolutePath()));
    }

  }

  public void setRoute(String prefix, RouteModel routeModel) {
    ZuulRoute route = new ZuulRoute();
    route.setSensitiveHeaders(routeModel.getSensitiveHeaders());
    route.setStripPrefix(true);
    route.setUrl(routeModel.getTargetUrl());
    route.setPath(prefix);
    route.setId(routeModel.getName()) ;
         
    
    routeLocator.addRoute(route);
  }
  private String convertToRegex(final String k) {
    return "^" + k.replace("**", ".*") + "$";

  }

  @Override
  public String filterType() {
    return "pre";
  }

  @Override
  public int filterOrder() {
    return 1;
  }

  @Override
  public boolean shouldFilter() {
    return true;
  }

  @Override
  public Object run() throws ZuulException {
    RequestContext ctx = RequestContext.getCurrentContext();

    HttpServletRequest request = ctx.getRequest();
    Date startTime = new Date(System.currentTimeMillis());
    request.getSession().setAttribute("startTime", startTime);

    String uri = ctx.getRequest().getRequestURI();
    final PreProcessor model = findModel(modelMap, uri);




    if (model == null) {
      return null;
    }
    final String header = model.getPreProcessor();
    if (header != null) {
      model.getPreProcessorBean().process(ctx);
    }
    return null;
  }

  private PreProcessor findModel(final Map<String, PreProcessor> modelMap, final String uri) throws
                                                                                             InvalidServiceException {
    final Optional<PreProcessor> collect = modelMap.values().stream().filter(i -> {
      final Pattern compile = Pattern.compile(i.getPathRegex());
      return compile.matcher(uri).matches();
    }).findFirst();
    if (!collect.isPresent()) {
      throw new InvalidServiceException();
    }
    return collect.get();
  }
}

