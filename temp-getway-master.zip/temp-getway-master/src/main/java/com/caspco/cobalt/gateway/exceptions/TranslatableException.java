package com.caspco.cobalt.gateway.exceptions;

import com.netflix.zuul.exception.ZuulException;

public class TranslatableException extends ZuulException {

    public TranslatableException(Throwable throwable, String sMessage, int nStatusCode, String errorCause) {
        super(throwable, sMessage, nStatusCode, errorCause);
    }

    public TranslatableException(String sMessage, int nStatusCode, String errorCause) {
        super(sMessage, nStatusCode, errorCause);
    }

    public TranslatableException(Throwable throwable, int nStatusCode, String errorCause) {
        super(throwable, nStatusCode, errorCause);
    }
}
