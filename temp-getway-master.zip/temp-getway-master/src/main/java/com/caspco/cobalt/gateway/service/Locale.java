package com.caspco.cobalt.gateway.service;

public  enum  Locale{
    en_US,
    fa_IR
}
