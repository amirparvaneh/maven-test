package com.caspco.cobalt.gateway.service;


import com.caspco.cobalt.gateway.config.properties.OauthProperties;
import com.caspco.cobalt.gateway.exceptions.OauthApiException;
import com.caspco.cobalt.gateway.exceptions.TokenException;
import com.caspco.cobalt.gateway.model.dto.CobaltRequestBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class OauthService {
    private static Logger logger = LoggerFactory.getLogger(OauthService.class);
    @Autowired
    private CCToken ccToken;
    @Autowired
    private OauthProperties oauthProperties;


    public Object getTokenFromOauth() throws OauthApiException, TokenException {
        logger.info("Starting getTokenFromOauth method");


        ResponseEntity<Object> tokenDto =
            ccToken.getToken(new CobaltRequestBean("client_credentials", ""));
        return tokenDto.getBody();

    }


}
