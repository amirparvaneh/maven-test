package com.caspco.cobalt.gateway.filter.model;

import com.caspco.cobalt.gateway.filter.prefilter.HeaderPreProcessor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PreProcessor {
  private String path;
  private String preProcessor;
  private HeaderPreProcessor preProcessorBean;
  private RouteModel routeModel;
  private String pathRegex;


  public String getPreProcessor() {
    return preProcessor;
  }

  public void setPreProcessor(String preProcessor) {
    this.preProcessor = preProcessor;
  }

  public HeaderPreProcessor getPreProcessorBean() {
    return preProcessorBean;
  }

  public void setPreProcessorBean(HeaderPreProcessor preProcessorBean) {
    this.preProcessorBean = preProcessorBean;
  }

  public RouteModel getRouteModel() {
    return routeModel;
  }

  public void setRouteModel(RouteModel routeModel) {
    this.routeModel = routeModel;
  }

  public String getPathRegex() {
    return pathRegex;
  }

  public void setPathRegex(String pathRegex) {
    this.pathRegex = pathRegex;
  }

  public String getPath() {
    return path;
  }

  public void setPath(final String path) {
    this.path = path;
  }
}

