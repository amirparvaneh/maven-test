package com.caspco.cobalt.gateway.service;

import com.caspco.cobalt.gateway.model.ExceptionModel;
import com.caspco.cobalt.gateway.exceptions.TranslatableException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.PostConstruct;

@Service
public class TranslatorService {

  private static final Map<String, String> FA_TRANSLATIONS = new ConcurrentHashMap<>();
  private static final Map<String, String> EN_TRANSLATIONS = new ConcurrentHashMap<>();

  @Value("${fa.exception.translation.path}")
  String faTranslationPath;

  @Value("${en.exception.translation.path}")
  String enTranslationPath;



  @PostConstruct
  public void init() throws IOException {
    FA_TRANSLATIONS.putAll(extractTranslations(faTranslationPath));
    EN_TRANSLATIONS.putAll(extractTranslations(enTranslationPath));
  }

  public ExceptionModel createTranslatedExceptionModel(String message, int status, Exception exceptionType)
  {
    ExceptionModel exceptionModel = new ExceptionModel();
    exceptionModel.setDescription(translateException(exceptionType));
    exceptionModel.setTimestamp(new Date());
    exceptionModel.setCode(status);
    exceptionModel.setMessage(message);
    exceptionModel.setExceptionDetail(exceptionType.getClass().getName());
    return exceptionModel;
  }

  private Map translateException(Exception x) {
    Map<String, String> map = new HashMap<>();
    if (x instanceof TranslatableException) {
      String enTranslate = translate(Locale.en_US, x.getClass().getName());
      String faTranslate = translate(Locale.fa_IR, x.getClass().getName());
      map.put(Locale.en_US.name(), enTranslate);
      map.put(Locale.fa_IR.name(), faTranslate);
    }
    return map;
  }

  private Map<String, String> extractTranslations(String path) throws IOException {
    Map<String, String> tr = new HashMap<>();
    InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(path);
    Properties properties=new Properties();
    properties.load(new InputStreamReader(inputStream, Charset.forName("UTF-8")));
    for (Map.Entry<Object, Object> e : properties.entrySet()) {
      String key = String.valueOf(e.getKey());
      String value = String.valueOf(e.getValue());
      tr.put(key, value);
    }
    return tr;
  }

  private String translate(Locale locale, String key) {
    switch (locale) {
      case en_US:
        return EN_TRANSLATIONS.get(key);
      case fa_IR:
        return FA_TRANSLATIONS.get(key);
    }
    return null;
  }


}

