package com.caspco.cobalt.gateway.filter.exceptions;


public class PreProcessorNotFoundException extends RuntimeException {

  public PreProcessorNotFoundException() {
  }

  public PreProcessorNotFoundException(String message) {
    super(message);
  }

  public PreProcessorNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public PreProcessorNotFoundException(Throwable cause) {
    super(cause);
  }

  public PreProcessorNotFoundException(
      String message,
      Throwable cause,
      boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}

