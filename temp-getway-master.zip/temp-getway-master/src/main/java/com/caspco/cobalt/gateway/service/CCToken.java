package com.caspco.cobalt.gateway.service;


import com.caspco.cobalt.gateway.exceptions.OauthApiException;
import com.caspco.cobalt.gateway.exceptions.TokenException;
import com.caspco.cobalt.gateway.model.dto.CobaltRequestBean;
import org.springframework.http.ResponseEntity;

public interface CCToken {
    ResponseEntity<Object> getToken(CobaltRequestBean cobaltRequestbean) throws OauthApiException, TokenException;

}
