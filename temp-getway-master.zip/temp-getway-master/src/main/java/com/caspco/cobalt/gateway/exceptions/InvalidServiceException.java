package com.caspco.cobalt.gateway.exceptions;



public class InvalidServiceException extends TranslatableException {

    public static final int N_STATUS_CODE =504;
    public static final String ERROR_CAUSE ="invalid service Exception !!!";

    public InvalidServiceException() {
        super("", N_STATUS_CODE, ERROR_CAUSE);
    }

    public InvalidServiceException(Throwable throwable) {
        super(throwable, N_STATUS_CODE, ERROR_CAUSE);
    }

    @Override
    public String toString() {
        return "OauthApiException{" +
                "nStatusCode=" + N_STATUS_CODE +
                ", errorCause='" + ERROR_CAUSE + '\'' +
                '}';
    }
}
