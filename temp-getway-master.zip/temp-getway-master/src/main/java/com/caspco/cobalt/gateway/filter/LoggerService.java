package com.caspco.cobalt.gateway.filter;

import static com.caspco.cobalt.gateway.config.ConstantsValue.CLIENT_ID;
import static com.caspco.cobalt.gateway.config.ConstantsValue.CONTENT_ENCODING;
import com.caspco.cobalt.gateway.logging.LoggerProxy;
import com.caspco.cobalt.gateway.model.ExceptionModel;
import com.caspco.cobalt.gateway.config.ConstantsValue;
import com.caspco.cobalt.gateway.exceptions.JwtParsException;
import com.caspco.cobalt.gateway.model.LogModel;
import com.caspco.cobalt.gateway.service.TranslatorService;
import com.caspco.cobalt.gateway.util.JwtService;
import com.caspco.cobalt.gateway.util.Util;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.util.Pair;
import com.netflix.zuul.context.RequestContext;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.io.DataInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.zip.GZIPInputStream;
import javax.servlet.http.HttpServletRequest;

@Service
public class LoggerService {

  @Autowired
  private Util util;
  @Autowired
  private TranslatorService translatorService;
  @Autowired
  @Qualifier(value = "securedMapper")
  private ObjectMapper securedMapper;
  @Autowired
  private JwtService jwtService;
  @Autowired
  private Environment env;
  @Autowired
  private LoggerProxy loggerProxy;


  public void persistLogModel(
      final HttpServletRequest request,
      final RequestContext ctx,
      final ExceptionModel exceptionModel, final boolean hasException)
      throws  IOException {

      String responseBody;
      String requestBody;

      responseBody = extractResponseBody(ctx);
      if(responseBody != null){
        ctx.setResponseBody(new String(responseBody.getBytes(StandardCharsets.UTF_8),StandardCharsets.UTF_8));  ///////////ISO_8859_1
        ctx.getZuulResponseHeaders().add(new Pair<>("Content-Type","application/json;charset=utf-8")) ;

      }
      try {
        requestBody = util.convertListToString(
            IOUtils.readLines(new DataInputStream(request.getInputStream()), "utf-8"));
      } catch (NullPointerException | IOException e) {
        requestBody = null;
      }
      Date startTime = (Date) request.getSession().getAttribute("startTime");
      Date endTime = new Date();

      LogModel logModel = new LogModel();
      logModel.setLogDate(util.getFormattedDate(startTime));
      logModel.setExceptionModel(exceptionModel);
      logModel.setResponseHeaders(util.getResponseHeaders(ctx.getOriginResponseHeaders()));
      logModel.setRequestHeaders(util.getRequestHeaders(ctx.getRequest()));
      logModel.setRequestBody(requestBody);
      logModel.setResponseBody(responseBody);
      logModel.setStartTimestamp(startTime);
      logModel.setEndTimestamp(endTime);
      logModel.setDuration(endTime.getTime() - startTime.getTime());
      logModel.setMethod(request.getMethod());
      logModel.setUrl(request.getRequestURI());
      logModel.setStatus(ctx.getResponseStatusCode());
      logModel.setHasException(hasException);

      loggerProxy.log(logModel);
  }

  private String extractClientId(String token){
    String clientId=null;
    try{
        clientId= jwtService.extractJwtField(token,CLIENT_ID);
    }catch (IllegalArgumentException | JwtParsException e){     // i handled exception here because , this service just log and it's not part of project main stream.
      clientId= "fail to extract id" ;
    }
    return clientId;
  }

  private String extractResponseBody(RequestContext ctx) throws IOException {
    String responseBody;
    try {
      if(ctx.getResponseGZipped()){  // if contentType is gzip, remove it as zuul cannot handle it.
        responseBody = util.convertListToString(
            IOUtils.readLines(new GZIPInputStream(ctx.getResponseDataStream()), "utf-8"));

        ctx.getZuulResponseHeaders().stream().
            filter(pair->CONTENT_ENCODING.equals(pair.first())).peek(pair->pair.setSecond("")).findFirst();
      }
      else{
        responseBody=
            util.convertListToString(IOUtils.readLines(new DataInputStream(ctx.getResponseDataStream()), "utf-8")) ;
      }
    } catch (NullPointerException e) {
      responseBody = null;
    }
    return responseBody;
  }
}

