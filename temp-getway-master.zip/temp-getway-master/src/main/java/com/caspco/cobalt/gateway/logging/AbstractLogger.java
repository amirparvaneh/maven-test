package com.caspco.cobalt.gateway.logging;


import com.caspco.cobalt.gateway.mapper.SecuredMapper;
import com.caspco.cobalt.gateway.model.LogModel;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

public interface AbstractLogger {


    ObjectMapper objectMapper = new SecuredMapper();

    void log(final LogModel logRequest) throws IOException;

}
