package com.caspco.cobalt.gateway.model;

import java.util.Date;
import java.util.Map;


public final class LogModel {
    private String logDate;
    private Object requestBody;
    private Object responseBody;
    private Date startTimestamp;
    private Date endTimestamp;
    private Long duration;
    private String url;
    private String endpoint;
    private String method;
    private Map<String, ?> requestHeaders;
    private Map<String, ?> responseHeaders;
    private int status;
    private ExceptionModel exceptionModel;
    private Boolean hasException;



    public LogModel() {
    }

  public String getLogDate() {
    return logDate;
  }

  public void setLogDate(String logDate) {
    this.logDate = logDate;
  }

  public Object getRequestBody() {
        return requestBody;
    }

    public void setRequestBody(final Object requestBody) {
        this.requestBody = requestBody;
    }

    public Object getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(final Object responseBody) {
        this.responseBody = responseBody;
    }

    public Date getStartTimestamp() {
        return startTimestamp;
    }

    public void setStartTimestamp(final Date startTimestamp) {
        this.startTimestamp = startTimestamp;
    }

    public Date getEndTimestamp() {
        return endTimestamp;
    }

    public void setEndTimestamp(final Date endTimestamp) {
        this.endTimestamp = endTimestamp;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(final Long duration) {
        this.duration = duration;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(final String url) {
        this.url = url;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(final String endpoint) {
        this.endpoint = endpoint;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(final String method) {
        this.method = method;
    }

    public Map<String, ?> getRequestHeaders() {
        return requestHeaders;
    }

    public void setRequestHeaders(final Map<String, ?> requestHeaders) {
        this.requestHeaders = requestHeaders;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(final int status) {
        this.status = status;
    }

    public ExceptionModel getExceptionModel() {
        return exceptionModel;
    }

    public void setExceptionModel(final ExceptionModel exceptionModel) {
        this.exceptionModel = exceptionModel;
    }

    public Boolean getHasException() {
        return hasException;
    }

    public void setHasException(final Boolean hasException) {
        this.hasException = hasException;
    }

    public Map<String, ?> getResponseHeaders() {
        return responseHeaders;
    }

    public void setResponseHeaders(final Map<String, ?> responseHeaders) {
        this.responseHeaders = responseHeaders;
    }
}

