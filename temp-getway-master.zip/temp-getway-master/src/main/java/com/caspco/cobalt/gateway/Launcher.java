package com.caspco.cobalt.gateway;

import com.caspco.cobalt.gateway.config.SslCheck;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.ApplicationPidFileWriter;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.PropertySource;

import javax.annotation.PostConstruct;

@SpringBootApplication
@EnableZuulProxy
@RefreshScope
@EnableFeignClients
@PropertySource(value = "./override.properties", ignoreResourceNotFound = true)
@EnableCaching
public class Launcher {

  public static void main(String[] args) {
    SpringApplication springApplication = new SpringApplication(Launcher.class);
    springApplication.addListeners(new ApplicationPidFileWriter());
    springApplication.run(args);
  }

  @PostConstruct
  public void activeSSl() throws Exception {
    SslCheck check = new SslCheck();
    check.runssl();
  }

}
