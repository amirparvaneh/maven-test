package com.caspco.cobalt.gateway.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.boot.env.PropertiesPropertySourceLoader;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author : Pooya. h
 * Email : husseini@caspco.ir
 * Date: 11/29/17
 * Time: 3:41 PM
 */
public class EnvironmentPostProcessorExample implements EnvironmentPostProcessor {
  private static final Logger log = LoggerFactory.getLogger(EnvironmentPostProcessorExample.class);

  YamlPropertySourceLoader yamlLoader = new YamlPropertySourceLoader();
  private final PropertiesPropertySourceLoader loader = new PropertiesPropertySourceLoader();


  @Override
  public void postProcessEnvironment(
    ConfigurableEnvironment environment,
    SpringApplication application) {
    Resource pathYamls = new FileSystemResource("./override.yml");
    Resource pathProps = new FileSystemResource("./override.properties");

    if (!pathYamls.exists() && !pathProps.exists()) {
      printEnvironmentVariables(environment);
      return;
    }
    try {
      if (pathProps.exists()) {
        applyProperties(environment, loader.load("override", pathProps), pathProps);
      }
      if (pathYamls.exists()) {
        applyProperties(environment, yamlLoader.load("override", pathYamls), pathYamls);
      }
      printEnvironmentVariables(environment);
    } catch (IOException e) {
      throw new IllegalStateException("Failed to load props configuration.\n"+e.getMessage() , e);
    }
  }

  private void applyProperties(
    final ConfigurableEnvironment environment,
    final List<PropertySource<?>> propertySource, final Resource path) throws IOException {
    Properties properties = new Properties();
    properties.load(path.getInputStream());
    path.getInputStream().close();
    properties.forEach((key, value) -> System.setProperty(String.valueOf(key), String.valueOf(value)));
    propertySource.forEach(propertySource1 -> environment.getPropertySources().addFirst(propertySource1));
  }

  private void printEnvironmentVariables(Environment environment) {
    ResourcePatternResolver patternResolver = new PathMatchingResourcePatternResolver();
    StringBuilder stringBuilder = new StringBuilder(
      "\n-------------------------------------- START OF ENVIRONMENT VARIABLES --------------------------------------\n");
    Set<String> keys = new HashSet<>();
    try {
      Resource[] mappingLocationsProps = patternResolver.getResources("classpath:*.yml");
      Resource[] mappingLocationsYmls = patternResolver.getResources("classpath:*.properties");
      final Set<String> finalKeys = keys;
      Stream.of(mappingLocationsProps, mappingLocationsYmls)
            .flatMap(Arrays::stream)
            .filter(Objects::nonNull)
            .forEach(resource -> {
        try {
          Properties properties = new Properties();
          properties.load(resource.getInputStream());
          finalKeys.addAll(properties.stringPropertyNames());
        } catch (IOException e) {
          // ignore
        }
      });
    } catch (IOException e) {
      //ignore
    }
    final int[] maxLen = {1};
    stringBuilder.append(Arrays.toString(keys.stream()
                                             .filter(s -> environment.getProperty(s) != null)
                                             .peek(s -> {
                                               if (maxLen[0] < s.length()) {
                                                 maxLen[0] = s.length();
                                               }
                                             })
                                             .collect(Collectors.toList())
                                             .stream()
                                             .collect(Collectors.toMap(
                                               o -> String.format("%-" + maxLen[0] + "s", o) + "\t",
                                               o -> o.toLowerCase()
                                                     .contains("pass") ? "******" : environment.getProperty(
                                                 o)))
                                             .entrySet()
                                             .stream()
                                             .sorted(Comparator.comparing(Map.Entry::getKey))
                                             .toArray())
                               .replace(", ", ", \n")
                               .replace("[", "[\n")
                               .replace("]", "\n]")
                               .replace("=", "=\t"));
    stringBuilder.append(
      "\n-------------------------------------- END OF ENVIRONMENT VARIABLES --------------------------------------\n");
    log.error(stringBuilder.toString());
    System.err.println(stringBuilder.toString());
  }
}
