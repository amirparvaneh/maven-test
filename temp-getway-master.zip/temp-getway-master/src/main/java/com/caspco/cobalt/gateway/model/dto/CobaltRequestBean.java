package com.caspco.cobalt.gateway.model.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlRootElement;


@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CobaltRequestBean {

  @JsonProperty("grant_type")
  private String grantType;
  @JsonProperty("scope")
  private String scope;


  public CobaltRequestBean() {
  }


  public CobaltRequestBean(final String grantType, final String scope) {
    this.grantType = grantType;
    this.scope = scope;
  }

  public String getGrantType() {
    return grantType;
  }

  public void setGrantType(final String grantType) {
    this.grantType = grantType;
  }

  public String getScope() {
    return scope;
  }

  public void setScope(final String scope) {
    this.scope = scope;
  }
}
