package com.caspco.cobalt.gateway.model;



import java.util.Date;
import java.util.Map;


public final class ExceptionModel {

  private Date timestamp;
  private Integer code;
  private String message;
  private Map<String,String> description;
  private String exceptionDetail;

  public ExceptionModel(
      final Date timestamp,
      final Integer code,
      final String message,
      final Map<String, String> description, final String exceptionDetail) {
    this.timestamp = timestamp;
    this.code = code;
    this.message = message;
    this.description = description;
    this.exceptionDetail = exceptionDetail;
  }

  public ExceptionModel() { }

  public Date getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(final Date timestamp) {
    this.timestamp = timestamp;
  }

  public Integer getCode() {
    return code;
  }

  public void setCode(final Integer code) {
    this.code = code;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(final String message) {
    this.message = message;
  }

  public Map<String, String> getDescription() {
    return description;
  }

  public void setDescription(final Map<String, String> description) {
    this.description = description;
  }

  public String getExceptionDetail() {
    return exceptionDetail;
  }

  public void setExceptionDetail(final String exceptionDetail) {
    this.exceptionDetail = exceptionDetail;
  }
}

