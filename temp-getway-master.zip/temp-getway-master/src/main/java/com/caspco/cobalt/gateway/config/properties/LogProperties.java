package com.caspco.cobalt.gateway.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("log")
public class LogProperties {

    private boolean fileEnable;

    public boolean isFileEnable() {
        return fileEnable;
    }

    public void setFileEnable(boolean fileEnable) {
        this.fileEnable = fileEnable;
    }

    @Override
    public String toString() {
        return "LogProperties{" +
                "fileEnable=" + fileEnable +
                '}';
    }
}
