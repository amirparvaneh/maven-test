package com.caspco.cobalt.gateway.filter.prefilter;

import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

public interface  HeaderPreProcessor {

void process(RequestContext ctx) throws ZuulException;

}
