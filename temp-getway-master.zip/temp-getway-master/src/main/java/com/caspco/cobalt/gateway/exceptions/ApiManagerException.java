package com.caspco.cobalt.gateway.exceptions;

public  class ApiManagerException extends TranslatableException {


  public ApiManagerException(
      final Throwable throwable,
      final String sMessage,
      final int nStatusCode,
      final String errorCause) {
    super(throwable, sMessage, nStatusCode, errorCause);
  }

  public ApiManagerException(final String sMessage, final int nStatusCode, final String errorCause) {
    super(sMessage, nStatusCode, errorCause);
  }

  public ApiManagerException(final Throwable throwable, final int nStatusCode, final String errorCause) {
    super(throwable, nStatusCode, errorCause);
  }
}

