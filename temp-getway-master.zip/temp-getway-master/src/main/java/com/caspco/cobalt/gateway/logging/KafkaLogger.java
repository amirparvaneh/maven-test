package com.caspco.cobalt.gateway.logging;


import com.caspco.cobalt.gateway.config.properties.KafkaProperties;
import com.caspco.cobalt.gateway.model.LogModel;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.io.IOException;


@ConditionalOnProperty(name = "kafka.enable", havingValue = "true", matchIfMissing = true)
@Service
public class KafkaLogger implements AbstractLogger {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(KafkaLogger.class);

    @Autowired
    private KafkaProperties kafkaProperties;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;


    @Async
    public void log(LogModel logRequest) throws IOException {
        final String value = objectMapper.writeValueAsString(logRequest);

        ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send(kafkaProperties.getTopicName(), value);
        future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

            @Override
            public void onSuccess(final SendResult<String, String> message) {
                LOGGER.info("sent message= " + message + " with offset= " + message.getRecordMetadata().offset());
            }

            @Override
            public void onFailure(final Throwable throwable) {
                LOGGER.error("unable to send message= " + logRequest.getUrl(), throwable);
            }
        });
    }
}

