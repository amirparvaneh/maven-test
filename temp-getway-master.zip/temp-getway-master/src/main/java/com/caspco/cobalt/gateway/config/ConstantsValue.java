package com.caspco.cobalt.gateway.config;

public class ConstantsValue {

  public final static String BEARER = "Bearer ";
  public final static String AUTHORIZATION = "Authorization";
  public final static String DEVICEID = "Device-Id";
  public final static String APPKEY = "App-Key";
  public final static String TOKENID = "Token-Id";
  public final static String ROUTE_HOST = "routeHost";
  public final static String LOG_MODEL = "logModel";
  public final static String CONTENT_TYPE = "Content-Type";
  public final static String APPLICATION_JSON = "application/json";
  public final static String FARABOOM = "FARABOOM";
  public final static String FINNOTECH = "FINOTECH";
  public final static String CUSTOMER_NO = "customerNo";
  public final static String CLIENT_ID = "client_id";
  public final static String REFRESH_TOKEN = "refresh_token";
  public final static String CLIENT_SECRET = "client_secret";
  public final static String GRANT_TYPE = "grant_type";
  public final static String PASSWORD = "password";
  public final static String USERNAME = "username";
  public final static String CONTENT_ENCODING = "Content-Encoding";
  public final static String VENESH = "venesh";
  public final static String SHAHRDARI = "shahrdari";
  public final static String TOLL = "toll";






}
