package com.caspco.cobalt.gateway.service;

import com.caspco.cobalt.gateway.exceptions.OauthApiException;
import com.caspco.cobalt.gateway.exceptions.TokenException;
import com.caspco.cobalt.gateway.model.dto.CobaltRequestBean;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ServerErrorException;

import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.Map;
import javax.annotation.PostConstruct;


@Service
public class CCTokenImpl implements CCToken {
  private RestTemplate restTemplate = new RestTemplate();

  @Autowired
  private ObjectMapper mapper;

  @Value("${oauth.base-url}")
  private String url;

  @Value("${oauth.client-id}")
  private String clientId;

  @Value("${oauth.client-secret}")
  private String clientSecret;
  private String basic;


  @PostConstruct
  public void init() throws UnsupportedEncodingException {
    restTemplate.getMessageConverters().add(getMappingJackson2HttpMessageConverter());
    this.basic = java.util.Base64.getEncoder().encodeToString((clientId + ":" + clientSecret).getBytes("utf-8"));
  }
  public MappingJackson2HttpMessageConverter getMappingJackson2HttpMessageConverter() {
    MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter();
    mappingJackson2HttpMessageConverter.setSupportedMediaTypes(Collections.singletonList(MediaType.APPLICATION_FORM_URLENCODED));
    return mappingJackson2HttpMessageConverter;
  }
  @Override public ResponseEntity<Object> getToken( final CobaltRequestBean cobaltRequestbean) throws
                                                                                               OauthApiException,
                                                                                               TokenException {
    HttpHeaders headers=new HttpHeaders();
    headers.add("Authorization","Basic " +basic);
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
    map.add("grant_type","client_credentials");
    map.add("scope","");

    HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map,headers);
    try {
      final Map body = restTemplate.postForObject(url, request, Map.class);
      return ResponseEntity.ok().body(body);
    } catch (HttpClientErrorException |ServerErrorException e) {
      throw new OauthApiException(e.getMessage());
    }
  }
}

