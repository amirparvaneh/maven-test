package com.caspco.cobalt.gateway.exceptions;

public class TokenException extends TranslatableException {

    public static final int N_STATUS_CODE = 503;
    public static final String ERROR_CAUSE = "Oauth could not found token !!!";

    public TokenException(String sMessage) {
        super(sMessage, N_STATUS_CODE, ERROR_CAUSE);
    }
  public TokenException(String sMessage, int nStatusCode) {
    super(sMessage, nStatusCode, ERROR_CAUSE);
  }

    public TokenException(Throwable throwable) {
        super(throwable, N_STATUS_CODE, ERROR_CAUSE);
    }

    @Override
    public String toString() {
        return "TokenException{" +
                "nStatusCode=" + N_STATUS_CODE +
                ", errorCause='" + ERROR_CAUSE + '\'' +
                '}';
    }
}
