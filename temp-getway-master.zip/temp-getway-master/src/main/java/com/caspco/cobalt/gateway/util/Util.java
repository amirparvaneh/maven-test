package com.caspco.cobalt.gateway.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.util.Pair;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;


@Service
public class Util {

    @Autowired
    @Qualifier(value = "securedMapper")
    ObjectMapper mapper;

    public Map<String, Object> getRequestHeaders(HttpServletRequest request) {
        Map<String, Object> headerMap = new HashMap<>();

        Enumeration<String> headers = request.getHeaderNames();
        while (headers.hasMoreElements()) {
            String key = headers.nextElement();
            if(!key.equals("authorization")){
              headerMap.put(key, request.getHeader(key));
          } 
        }
        return headerMap;
    }
 

    public Map<String, Object> getResponseHeaders(List<Pair<String, String>> responseHeaders) {
        Map<String, Object> result = new HashMap<>();
        responseHeaders.stream().forEach(a ->
                result.put(a.first(), a.second())
        );
        return result;
    }


    public String convertListToString(List tempList)  {
        StringBuilder result = new StringBuilder();
            if (tempList.size() == 0) {
                return null;
            } else {
                if(tempList.size()>= 255){
                    for(int i=0; i< 255; i++){
                        result.append(tempList.get(i));
                    }
                } else{
                    return result.append(tempList).toString();
                }
            }
              return null;
    }
    public String getFormattedDate(Date d){
      DateFormat pattern= new SimpleDateFormat("yyyy:MM:dd-hh:mm:ss a");
      return pattern.format(d);
    }

    public String convertListToString(InputStream inputStream) throws IOException {
        StringBuilder result = new StringBuilder();
        List<String> tempList;
            try {
                tempList = IOUtils.readLines(new DataInputStream(inputStream), "UTF-8");
            }catch (NullPointerException e){
                return null;
            }
        if (tempList.size() == 0) {
            return null;
        } else {
            if(tempList.size()>= 255){
                for(int i=0; i< 255; i++){
                    result.append(tempList.get(i));
                }
            }

            return result.toString();
        }

    }



    public Map stringToMap(String body) throws IOException {
        if (body == null || body.equals("")) {
            return null;
        }
        return mapper.readValue(body, Map.class);
    }
}

