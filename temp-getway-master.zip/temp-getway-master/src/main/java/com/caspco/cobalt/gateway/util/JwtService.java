package com.caspco.cobalt.gateway.util;

import com.caspco.cobalt.gateway.model.JwtEncryptionDto;
import com.caspco.cobalt.gateway.exceptions.JwtParsException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.RsaVerifier;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Jafar Mirzaei (jm.csh2009@gmail.com)
 * @version 1.0 2018.0512
 * @since 1.0
 */
@Service
public class JwtService {

  private static String JWT_JTI = "jti";


  @Value("${token.server.public-key}")
  private String publicKey;

  @Value("${oauth2.jwt.encrypt.key}")
  private String oauthJwtEncryptKey;

  public String extractJwtField(
      String token,
      String jwtAppFiledName) throws JwtParsException {
    if (StringUtils.isEmpty(token)) {
      return null;
    }
    Jwt decode = JwtHelper.decode(token.indexOf(' ') > -1 ? token.split(" ")[1] : token);

    decode.verifySignature(new RsaVerifier(publicKey));
    ObjectMapper objectMapper = new ObjectMapper();
    Map map = null;
    try {
      map = objectMapper.readValue(decode.getClaims(), Map.class);
    } catch (IOException e) {
      throw new JwtParsException(e);
    }
    if (map.containsKey(jwtAppFiledName)) {
      return map.get(jwtAppFiledName).toString();
    }
    return null;
//    return /*(String) */ map.get(jwtAppFiledName).toString();
  }

  public Map<String, Object> extractJwtFields(
      String token,
      List<String> jwtAppFiledNames) throws JwtParsException {
    if (StringUtils.isEmpty(token)) {
      return null;
    }
    Jwt decode = JwtHelper.decode(token.indexOf(' ') > -1 ? token.split(" ")[1] : token);
    decode.verifySignature(new RsaVerifier(publicKey));
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      final Map map = objectMapper.readValue(decode.getClaims(), Map.class);
      return jwtAppFiledNames.stream()
          .collect(Collectors.toMap(s -> s, s -> map.get(s)));
    } catch (IOException e) {
      throw new JwtParsException( e);
    }
  }

  public JwtEncryptionDto extractJwtEncryptionDetail(String token) throws JwtParsException {
    if (StringUtils.isEmpty(token)) {
      return null;
    }
    Jwt decode = JwtHelper.decode(token.indexOf(' ') > -1 ? token.split(" ")[1] : token);
    decode.verifySignature(new RsaVerifier(publicKey));
    Map map = null;
    ObjectMapper objectMapper = new ObjectMapper();
    JwtEncryptionDto encryptionDto = new JwtEncryptionDto();
    try {
      map = objectMapper.readValue(decode.getClaims(), Map.class);
    } catch (IOException e) {
      throw new JwtParsException(e);
    }
    String jwtJti = (String) map.get(JWT_JTI);
    String nonce = jwtJti.replaceAll("-", "");

    encryptionDto.setNonce(nonce);
    encryptionDto.setKey(oauthJwtEncryptKey);

    return encryptionDto;

  }


}

