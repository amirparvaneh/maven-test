package com.caspco.cobalt.gateway.exceptions;



public class OauthApiException extends TranslatableException {

    public static final int N_STATUS_CODE =502;
    public static final String ERROR_CAUSE ="OauthAPi Exception !!!";

    public OauthApiException(String sMessage) {
        super(sMessage, N_STATUS_CODE, ERROR_CAUSE);
    }

    public OauthApiException(Throwable throwable) {
        super(throwable, N_STATUS_CODE, ERROR_CAUSE);
    }


    @Override
    public String toString() {
        return "OauthApiException{" +
                "nStatusCode=" + N_STATUS_CODE +
                ", errorCause='" + ERROR_CAUSE + '\'' +
                '}';
    }
}
