package com.caspco.cobalt.gateway.filter.prefilter;

import static com.caspco.cobalt.gateway.config.ConstantsValue.AUTHORIZATION;
import static com.caspco.cobalt.gateway.config.ConstantsValue.BEARER;


import com.caspco.cobalt.gateway.exceptions.JwtParsException;
import com.caspco.cobalt.gateway.exceptions.OauthApiException;
import com.caspco.cobalt.gateway.exceptions.TokenException;
import com.caspco.cobalt.gateway.model.dto.CobaltResponseBean;
import com.caspco.cobalt.gateway.service.CobalService;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;
import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;


@Component
public class CobaltHeaderPreProcessor implements HeaderPreProcessor {
  private static Logger log = LoggerFactory.getLogger(CobaltHeaderPreProcessor.class);
  private Cache<String, String> tokenAccessMap;
  private final static String TOKEN = "token";
  @Value("${oauth.token.expire.time}")
  private int tokenExpireTime;

  @PostConstruct
  public void init() {
    tokenAccessMap = CacheBuilder.newBuilder()
                                 .expireAfterWrite(tokenExpireTime, TimeUnit.MINUTES).build();
  }
  @Autowired
  private CobalService cobaltService;

  @Override
  public void process(RequestContext ctx) throws ZuulException {
    HttpServletRequest request=ctx.getRequest();
    String token = getToken();

    if (token != null ) {
      ctx.addZuulRequestHeader(AUTHORIZATION, BEARER + token);
    } else {
      log.error("Exception happened during oauth could not found token !!!");
      throw new TokenException("Oauth could not found token !!!");
    }
    log.info(String.format("%s request to %s", request.getMethod(), request.getRequestURL().toString()));
  }

  private String getToken() throws JwtParsException, OauthApiException, TokenException {

    if (this.tokenAccessMap.getIfPresent(TOKEN) != null) {
      return tokenAccessMap.getIfPresent(TOKEN);
    }

    final CobaltResponseBean object = (CobaltResponseBean) cobaltService
        .createResponseObject(CobaltResponseBean.class);

    tokenAccessMap.put(TOKEN, object.getAccessToken());
    return object.getAccessToken();
  }

}

