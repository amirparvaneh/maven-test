package com.caspco.cobalt.gateway.model;

public class JwtEncryptionDto {
    private String nonce;
    private String key;

    public String getNonce() {
        return nonce;
    }

    public void setNonce(String nonce) {
        this.nonce = nonce;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
